<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Quienes Somos || Majock Consulting</title> 

    <!-- mobile responsive meta -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">


    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/responsive.css">
    
    <link rel="apple-touch-icon" sizes="180x180" href="images/favicons/apple-touch-icon.png">
    <link rel="icon" type="image/png" href="images/favicons/favicon-32x32.png" sizes="32x32">
    <link rel="icon" type="image/png" href="images/favicons/favicon-16x16.png" sizes="16x16">

</head>
<body>

<div class="boxed_wrapper">


 
    

<?php include('header.php'); ?>

 


 


<div class="inner-banner has-base-color-overlay text-center" style="background: url(images/background/1.jpg);">
    <div class="container">
        <div class="box">
            <h3>Quienes Somos</h3>
        </div>
    </div>
    <div class="breadcumb-wrapper">
        <div class="container">
            <div class="pull-left">
                <ul class="list-inline link-list">
                    <li>
                        <a href="index.php">Inicio</a>
                    </li>
                    <li>
                        Quienes Somos
                    </li>
                </ul>
            </div>
            <div class="pull-right">
                <a href="#" class="get-qoute"><i class="fa fa-share-alt"></i>share</a>
            </div>
        </div>
    </div>
</div>



<section class="about-faq sec-padd">
    <div class="container">
        <div class="row">
            <div class="col-md-6 col-sm-12 col-xs-12">
                <figure class="img-box">
                    <a href="#"><img src="images/resource/7.jpg" alt=""></a>
                </figure>
            </div>
            <div class="col-md-6 col-sm-12 col-xs-12">
                <div class="about-info">
                    <h4>Acerca de nosotros</h4>
                    <div class="text">
                        <p>Majock Consultores & Asociados SAC es una empresa que apunta a ser líder en consultoría y asesoría en la industria del turismo con especial énfasis en la hostelería y la restauración.</p>

                        <p>Proponemos optimizar procesos, gracias a nuestras diferentes soluciones tecnológicas que se adaptan a la realidad de cada sector, integrando la infraestructura informática especializada con la asesoría en gestión propia del negocio.</p>

                        <p>Nuestros sistemas tienen sólida presencia, hace más de 20 años, en el mercado Americano y Europeo, así mismo la vasta experiencia de nuestros consultores son la garantía para el éxito de su negocio.</p>

                        <p>Ponemos a su disposición nuestros servicios desde la parametrización, capacitación y puesta en marcha, hasta el servicio post venta, convirtiéndonos en su socio estratégico con la dedicación debida para ayudarlo en su crecimiento, alcanzando una excelente calidad de servicio.</p>
                    </div>

                    <!--<div class="link_btn">
                        <a href="#" class="thm-btn">know more</a>
                        <div class="sign"><img src="images/resource/sign.jpg" alt=""></div>
                    </div>-->
                </div>
            </div>
            
            
        </div>
    </div>
</section>

<div class="container">
    <div class="border-bottom"></div>
</div>


<section class="four-column sec-padd-top">
    <div class="container">
        <div class="row">
            <div class="col-md-4 col-sm-6 col-xs-12">
                <div class="item center">
                    <figure class="img-box">
                        <a href="#"><img src="images/resource/10.jpg" alt=""></a>
                    </figure>
                    <div class="content">
                        <h4>Misión</h4>
                        <p>Brindar las herramientas necesarias a nuestros clientes para que puedan mejorar sus procesos operativos haciéndolos eficientes y eficaces, comprometiéndonos con los requerimientos y necesidades de cada cliente.</p>
                    </div>
                        
                </div>
            </div>
            <div class="col-md-4 col-sm-6 col-xs-12">
                <div class="item center">
                    <figure class="img-box">
                        <a href="#"><img src="images/resource/8.jpg" alt=""></a>
                    </figure>
                    <div class="content">
                        <h4>Visión</h4>
                        <p>Consolidarnos como la empresa líder en su segmento a nivel nacional e internacional, brindando un servicio de calidad superior y atención personalizada.</p>
                    </div>
                        
                </div>
            </div>
            <div class="col-md-4 col-sm-6 col-xs-12">
                <div class="item center">
                    <figure class="img-box">
                        <a href="#"><img src="images/resource/9.jpg" alt=""></a>
                    </figure>
                    <div class="content">
                        <h4>Servicio al cliente</h4>
                        <p>En MAJOCK estamos constantemente esforzándonos en brindarles un servicio con altos estándares de calidad.</p>
                    </div>
                        
                </div>
            </div>
            <!--<div class="col-md-3 col-sm-6 col-xs-12">
                <div class="item center">
                    <figure class="img-box">
                        <a href="#"><img src="images/resource/10.jpg" alt=""></a>
                    </figure>
                    <div class="content">
                        <h4>Be the Brand</h4>
                        <p>Declares our purpose as a company  <br>and serves as standard against which <br> we weigh actions decisions.</p>
                    </div>
                        
                </div>
            </div>-->

        </div>
    </div>
</section>


<!--<div class="our-history sec-padd-top">
    <div class="container">
        <div class="section-title">
            <h2>History In Words</h2>
        </div>
        <div class="row">
            <div class="col-md-1 col-sm-1 col-xs-1">
                <div class="slider-pager">
                    
                    <ul class="list-inline thumb-box">

                        <li>
                            <a class="active" data-slide-index="0" href="#">1975</a>
                        </li>
                        <li>
                            <a data-slide-index="1" href="#">1978</a>
                        </li>
                        <li>
                            <a data-slide-index="2" href="#">1984</a>
                        </li>
                        <li>
                            <a data-slide-index="3" href="#">1985</a>
                        </li>
                        <li>
                            <a data-slide-index="4" href="#">1988</a>
                        </li>

                    </ul>


                    
                </div>
            </div>
            <div class="col-md-11 col-sm-11 col-xs-11">
                <ul class="bxslider ">
                    <li>
                        <div class="clearfix">
                            <figure class="img-box pull-left">
                                <a href="#"><img src="images/resource/history.jpg" alt=""></a>
                            </figure>
                            <div class="content">
                                <h4>Starts at California City</h4>
                                <p class="theme-color">21st January 1975</p>
                                <div class="text">
                                    <p>Universal story stretches back more than 125 years & encompases several predecessor companies sed and the inspiring work of tens and thousands of people. But our core mission and values rise in the costof materials.</p>
                                    <p>Competition and a sudden sharp rise in the cost of raw materials leads many to set up associations, promoting their interets & defending seds themselves against supplier monopolies, all around the world.</p>
                                </div>
                            </div>
                        </div>
                    </li>
                    <li>
                        <div class="clearfix">
                            <figure class="img-box pull-left">
                                <a href="#"><img src="images/resource/history2.jpg" alt=""></a>
                            </figure>
                            <div class="content">
                                <h4>Starts at California City</h4>
                                <p class="theme-color">21st January 1978</p>
                                <div class="text">
                                    <p>Universal story stretches back more than 125 years & encompases several predecessor companies sed and the inspiring work of tens and thousands of people. But our core mission and values rise in the costof materials.</p>
                                    <p>Competition and a sudden sharp rise in the cost of raw materials leads many to set up associations, promoting their interets & defending seds themselves against supplier monopolies, all around the world.</p>
                                </div>
                            </div>
                        </div>
                    </li>
                    <li>
                        <div class="clearfix">
                            <figure class="img-box pull-left">
                                <a href="#"><img src="images/resource/history3.jpg" alt=""></a>
                            </figure>
                            <div class="content">
                                <h4>Starts at California City</h4>
                                <p class="theme-color">21st January 1984</p>
                                <div class="text">
                                    <p>Universal story stretches back more than 125 years & encompases several predecessor companies sed and the inspiring work of tens and thousands of people. But our core mission and values rise in the costof materials.</p>
                                    <p>Competition and a sudden sharp rise in the cost of raw materials leads many to set up associations, promoting their interets & defending seds themselves against supplier monopolies, all around the world.</p>
                                </div>
                            </div>
                        </div>
                    </li>
                    <li>
                        <div class="clearfix">
                            <figure class="img-box pull-left">
                                <a href="#"><img src="images/resource/history4.jpg" alt=""></a>
                            </figure>
                            <div class="content ">
                                <h4>Starts at California City</h4>
                                <p class="theme-color">21st January 1985</p>
                                <div class="text">
                                    <p>Universal story stretches back more than 125 years & encompases several predecessor companies sed and the inspiring work of tens and thousands of people. But our core mission and values rise in the costof materials.</p>
                                    <p>Competition and a sudden sharp rise in the cost of raw materials leads many to set up associations, promoting their interets & defending seds themselves against supplier monopolies, all around the world.</p>
                                </div>
                            </div>
                        </div>
                    </li>
                    <li>
                        <div class="clearfix">
                            <figure class="img-box pull-left">
                                <a href="#"><img src="images/resource/history5.jpg" alt=""></a>
                            </figure>
                            <div class="content">
                                <h4>Starts at California City</h4>
                                <p class="theme-color">21st January 1988</p>
                                <div class="text">
                                    <p>Universal story stretches back more than 125 years & encompases several predecessor companies sed and the inspiring work of tens and thousands of people. But our core mission and values rise in the costof materials.</p>
                                    <p>Competition and a sudden sharp rise in the cost of raw materials leads many to set up associations, promoting their interets & defending seds themselves against supplier monopolies, all around the world.</p>
                                </div>
                            </div>
                        </div>
                    </li>

                    
                </ul>
                <div class="slider-pager">
                    <div class="center">
                        <ul class="nav-link list-inline">
                            <li id="slider-prev"></li>
                            <li id="slider-next"></li>
                        </ul>  
                    </div>
                    
                </div>
            </div>
                
        </div>
    </div>
</div>-->



<section class="our-team">
    <div class="container">
        <div class="section-title center">
            <h2>Nuestro equipo</h2>
        </div>  
        <div class="row">
            <div class="col-md-3 col-sm-6 col-xs-12">
                <div class="single-team-member">
                    <figure class="img-box">
                        <a href="#"><img src="images/team/1.jpg" alt=""></a>
                        <div class="overlay">
                            <div class="inner-box">
                                <ul class="link">
                                    <li><a href="#" class="thm-btn">La creatividad es nuestra mejor Imagen</a></li>
                                </ul>
                            </div>
                                
                        </div>
                    </figure>
                    <div class="author-info text-center">
                        <h4>John Cardenas</h4>
                        <a href="#"><p class="position">Gerente de marketing</p></a>
                    </div>
                    <div class="text center">
                        <!--<p>Pursue pleasure rationally encounter <br>consequences that  extremely. </p>-->
                    </div>
                    <!--<ul class="social center">
                        <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                        <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                        <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                        <li><a href="#"><i class="fa fa-vimeo"></i></a></li>
                    </ul>-->
                        
                </div>
            </div>
            <div class="col-md-3 col-sm-6 col-xs-12">
                <div class="single-team-member">
                    <figure class="img-box">
                        <a href="#"><img src="images/team/2.jpg" alt=""></a>
                        <div class="overlay">
                            <div class="inner-box">
                                <ul class="link">
                                    <li<a href="#" class="thm-btn">"Un líder es alguien que no solo conoce el camino, sino que anda en el y muestra el camino"</a></li>
                                </ul>
                            </div>
                                
                        </div>
                    </figure>
                    <div class="author-info text-center">
                        <h4>Juan Blácido</h4>
                        <a href="#"><p class="position">Gerente de Operaciones</p></a>
                    </div>
                    <div class="text center">
                        <!--<p>Pursue pleasure rationally encounter <br>consequences that  extremely. </p>-->
                    </div>
                    <!--<ul class="social center">
                        <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                        <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                        <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                        <li><a href="#"><i class="fa fa-vimeo"></i></a></li>
                    </ul>-->
                        
                </div>
            </div>
            <div class="col-md-3 col-sm-6 col-xs-12">
                <div class="single-team-member">
                    <figure class="img-box">
                        <a href="#"><img src="images/team/3.jpg" alt=""></a>
                        <div class="overlay">
                            <div class="inner-box">
                                <ul class="link">
                                    <li><a href="#" class="thm-btn">La calidad es un gran plan de negocios</a></li>
                                </ul>
                            </div>
                                
                        </div>
                    </figure>
                    <div class="author-info text-center">
                        <h4>Katia Palomino</h4>
                        <a href="#"><p class="position">Gerennte de Ventas</p></a>
                    </div>
                    <div class="text center">
                        <!--<p>Pursue pleasure rationally encounter <br>consequences that  extremely. </p>-->
                    </div>
                    <!--<ul class="social center">
                        <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                        <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                        <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                        <li><a href="#"><i class="fa fa-vimeo"></i></a></li>
                    </ul>-->
                        
                </div>
            </div>
            <div class="col-md-3 col-sm-6 col-xs-12">
                <div class="single-team-member">
                    <figure class="img-box">
                        <a href="#"><img src="images/team/4.jpg" alt=""></a>
                        <div class="overlay">
                            <div class="inner-box">
                                <ul class="link">
                                    <li><a href="#" class="thm-btn">Las ideas se roban, el talento JAMAS</a></li>
                                </ul>
                            </div>
                                
                        </div>
                    </figure>
                    <div class="author-info text-center">
                        <h4>Noelia Aquino</h4>
                        <a href="#"><p class="position">Recursos Humanos</p></a>
                    </div>
                    <div class="text center">
                        <!--<p>Pursue pleasure rationally encounter <br>consequences that  extremely. </p>-->
                    </div>
                    <!--<ul class="social center">
                        <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                        <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                        <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                        <li><a href="#"><i class="fa fa-vimeo"></i></a></li>
                    </ul>-->
                        
                </div>
            </div>
            <div class="col-md-3 col-sm-6 col-xs-12">
                <div class="single-team-member">
                    <figure class="img-box">
                        <a href="#"><img src="images/team/5.jpg" alt=""></a>
                        <div class="overlay">
                            <div class="inner-box">
                                <ul class="link">
                                    <li><a href="#" class="thm-btn">Las mejores decisiones de una empresa llevan al éxito</a></li>
                                </ul>
                            </div>
                                
                        </div>
                    </figure>
                    <div class="author-info text-center">
                        <h4>Rosmery Vásquez </h4>
                        <a href="#"><p class="position">Contador General</p></a>
                    </div>
                    <div class="text center">
                        <!--<p>Pursue pleasure rationally encounter <br>consequences that  extremely. </p>-->
                    </div>
                    <!--<ul class="social center">
                        <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                        <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                        <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                        <li><a href="#"><i class="fa fa-vimeo"></i></a></li>
                    </ul>-->
                        
                </div>
            </div>
            <div class="col-md-3 col-sm-6 col-xs-12">
                <div class="single-team-member">
                    <figure class="img-box">
                        <a href="#"><img src="images/team/6.jpg" alt=""></a>
                        <div class="overlay">
                            <div class="inner-box">
                                <ul class="link">
                                    <li><a href="#" class="thm-btn">Emprender no es solo empezar, es ALCANZAR</a></li>
                                </ul>
                            </div>
                                
                        </div>
                    </figure>
                    <div class="author-info text-center">
                        <h4>Máximo Soldevilla</h4>
                        <a href="#"><p class="position">CEO & COFUNDER</p></a>
                    </div>
                    <div class="text center">
                        <!--<p>Pursue pleasure rationally encounter <br>consequences that  extremely. </p>-->
                    </div>
                    <!--<ul class="social center">
                        <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                        <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                        <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                        <li><a href="#"><i class="fa fa-vimeo"></i></a></li>
                    </ul>-->
                        
                </div>
            </div>
            <div class="col-md-3 col-sm-6 col-xs-12">
                <div class="single-team-member">
                    <figure class="img-box">
                        <a href="#"><img src="images/team/7.jpg" alt=""></a>
                        <div class="overlay">
                            <div class="inner-box">
                                <ul class="link">
                                    <li><a href="#" class="thm-btn"><?php echo 'no soy perfecto mi código si' ?></a></li>
                                </ul>
                            </div>
                                
                        </div>
                    </figure>
                    <div class="author-info text-center">
                        <h4>Diego Bardalez</h4>
                        <a href="#"><p class="position">Web Developer</p></a>
                    </div>
                    <div class="text center">
                        <!--<p>Pursue pleasure rationally encounter <br>consequences that  extremely. </p>-->
                    </div>
                    <!--<ul class="social center">
                        <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                        <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                        <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                        <li><a href="#"><i class="fa fa-vimeo"></i></a></li>
                    </ul>-->
                        
                </div>
            </div>

               
                
        </div>
    </div>

</section>


<section class="subscribe center sec-padd" style="background-image: url(images/background/2.jpg);">
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2 col-sm-12 col-xs-12">
                <h2>Suscribete a nuestro newsletter</h2>
                <!--<p>Idea of denouncing pleasure praising pain was born and I will give you a complete account <br> ofsystem, expound the great explorer.</p>-->
                <form class="subscribe-form">
                    <input type="email" placeholder="Email"><span class="fa fa-envelope"></span>
                    <button type="submit" class="thm-btn">suscribirse!</button>
                </form>
            </div>
        </div>
                
    </div>
</section>

<!--<section class="achive sec-padd">
    <div class="container">
        <div class="section-title center">
            <h2>Our Achivement</h2>
        </div>
        <div class="achive-carousel">
            <figure class="item">
                <a href="#"><img src="images/resource/achive1.jpg" alt=""></a>
            </figure>
            <figure class="item">
                <a href="#"><img src="images/resource/achive2.jpg" alt=""></a>
            </figure>
            <figure class="item">
                <a href="#"><img src="images/resource/achive3.jpg" alt=""></a>
            </figure>
            <figure class="item">
                <a href="#"><img src="images/resource/achive4.jpg" alt=""></a>
            </figure>
            <figure class="item">
                <a href="#"><img src="images/resource/achive1.jpg" alt=""></a>
            </figure>
            <figure class="item">
                <a href="#"><img src="images/resource/achive2.jpg" alt=""></a>
            </figure>
            <figure class="item">
                <a href="#"><img src="images/resource/achive3.jpg" alt=""></a>
            </figure>
            <figure class="item">
                <a href="#"><img src="images/resource/achive4.jpg" alt=""></a>
            </figure>
            <figure class="item">
                <a href="#"><img src="images/resource/achive1.jpg" alt=""></a>
            </figure>
            <figure class="item">
                <a href="#"><img src="images/resource/achive2.jpg" alt=""></a>
            </figure>
            <figure class="item">
                <a href="#"><img src="images/resource/achive3.jpg" alt=""></a>
            </figure>
            <figure class="item">
                <a href="#"><img src="images/resource/achive4.jpg" alt=""></a>
            </figure>


        </div>
    </div>
</section>-->


<div class="call-out style-2">
    <div class="container">
        <div class="float_left">
            <h4>Ponte en contacto con nosotros</h4>
        </div>
        <div class="float_right">
            <a href="contacto.php#contacto" class="thm-btn">Mas información</a>
        </div>
    </div>
</div>

<?php include('footer.php'); ?>

</div>
    
</body>
</html>