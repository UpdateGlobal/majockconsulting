<?php

?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Majock Consulting</title> 

	<!-- mobile responsive meta -->
	<meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">


	<link rel="stylesheet" href="css/style.css">
	<link rel="stylesheet" href="css/responsive.css">
    
    <link rel="apple-touch-icon" sizes="180x180" href="images/favicons/apple-touch-icon.png">
    <link rel="icon" type="image/png" href="images/favicons/favicon-32x32.png" sizes="32x32">
    <link rel="icon" type="image/png" href="images/favicons/favicon-16x16.png" sizes="16x16">

</head>
<body>

<div class="boxed_wrapper">

    

<?php include('header.php'); ?>


<!--Start rev slider wrapper-->     
<section class="rev_slider_wrapper">
    <div id="slider1" class="rev_slider"  data-version="5.0">
        <ul>
            <li data-transition="fade">
                <img src="images/bannerprincipal/soluciones.png"  alt="" width="1920" height="580" data-bgposition="top center" data-bgfit="cover" data-bgrepeat="no-repeat" data-bgparallax="1" >
                
                <div class="tp-caption tp-resizeme"
                    data-x="right" data-hoffset="15" 
                    data-y="center" data-voffset="-4" 
                    data-transform_idle="o:1;"         
                    data-transform_in="x:[-175%];y:0px;z:0;rX:0;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0.01;s:3000;e:Power3.easeOut;" 
                    data-transform_out="s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;" 
                    data-mask_in="x:[100%];y:0;s:inherit;e:inherit;" 
                    data-splitin="none" 
                    data-splitout="none"  
                    data-responsive_offset="on"
                    data-start="500">
                    <div class="slide-content-box">
                        <!--<h3>The Sucessfull Business</h3>-->
                        <p style="font-size:35px">Soluciones personalizadas para su negocio</p>
                        <!--<p>Universal business theme continues to grow ever day thanks to the <br>confidence our clients have in US.</p>-->
                    </div>
                </div>
                <!--<div class="tp-caption tp-resizeme" 
                    data-x="left" data-hoffset="580" 
                    data-y="center" data-voffset="140" 
                    data-transform_idle="o:1;"                         
                    data-transform_in="y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;s:2000;e:Power4.easeInOut;" 
                    data-transform_out="s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;"                     
                    data-splitin="none" 
                    data-splitout="none" 
                    data-responsive_offset="on"
                    data-start="2300">
                    <div class="slide-content-box">
                        <div class="button">
                            <a class="thm-btn yellow-bg" href="">OUR COMPANY</a>     
                        </div>
                    </div>
                </div>
                <div class="tp-caption tp-resizeme" 
                    data-x="left" data-hoffset="755" 
                    data-y="center" data-voffset="140" 
                    data-transform_idle="o:1;"                         
                    data-transform_in="y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;s:2000;e:Power4.easeInOut;" 
                    data-transform_out="s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;"                     
                    data-splitin="none" 
                    data-splitout="none" 
                    data-responsive_offset="on"
                    data-start="2600">
                    <div class="slide-content-box">
                        <div class="button">
                            <a class="thm-btn our-solution" href="">contact us</a>     
                        </div>
                    </div>
                </div>-->
            </li>
            <li data-transition="fade">
                <img src="images/bannerprincipal/seamas.jpg"  alt="" width="1920" height="550" data-bgposition="top center" data-bgfit="cover" data-bgrepeat="no-repeat" data-bgparallax="1" >
                
                <div class="tp-caption  tp-resizeme" 
                    data-x="left" data-hoffset="15" 
                    data-y="top" data-voffset="230" 
                    data-transform_idle="o:1;"         
                    data-transform_in="x:[-175%];y:0px;z:0;rX:0;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0.01;s:3000;e:Power3.easeOut;" 
                    data-transform_out="s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;" 
                    data-mask_in="x:[100%];y:0;s:inherit;e:inherit;" 
                    data-splitin="none" 
                    data-splitout="none"
                    data-responsive_offset="on"
                    data-start="700">
                    <div class="slide-content-box">
                        <!--<h3>Universal Finds Right</h3>-->
                        <p style="font-size:35px">Sea más eficiente y eficaz en la toma de decisiones.<br>Tenemos lo que busca!</p>
                        <!--<p>Universal business theme continues to grow ever day thanks to the <br>confidence our clients have in US.</p>-->
                    </div>
                </div>
                <!--<div class="tp-caption tp-resizeme" 
                    data-x="left" data-hoffset="15" 
                    data-y="top" data-voffset="440" 
                    data-transform_idle="o:1;"                         
                    data-transform_in="y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;s:2000;e:Power4.easeInOut;" 
                    data-transform_out="s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;"                     
                    data-splitin="none" 
                    data-splitout="none" 
                    data-responsive_offset="on"
                    data-start="2300">
                    <div class="slide-content-box">
                        <div class="button">
                            <a class="thm-btn yellow-bg" href="">OUR COMPANY</a>     
                        </div>
                    </div>
                </div>
                <div class="tp-caption tp-resizeme" 
                    data-x="left" data-hoffset="190" 
                    data-y="top" data-voffset="440" 
                    data-transform_idle="o:1;"                         
                    data-transform_in="y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;s:2000;e:Power4.easeInOut;" 
                    data-transform_out="s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;"                     
                    data-splitin="none" 
                    data-splitout="none" 
                    data-responsive_offset="on"
                    data-start="2600">
                    <div class="slide-content-box">
                        <div class="button">
                            <a class="thm-btn our-solution" href="">contact us</a>     
                        </div>
                    </div>
                </div>-->
            </li>
            <li data-transition="fade">
                <img src="images/bannerprincipal/marquela.jpg"  alt="" width="1920" height="580" data-bgposition="top center" data-bgfit="cover" data-bgrepeat="no-repeat" data-bgparallax="1" >
                
                <div class="tp-caption tp-resizeme"
                    data-x="right" data-hoffset="15" 
                    data-y="center" data-voffset="-4" 
                    data-transform_idle="o:1;"         
                    data-transform_in="x:[-175%];y:0px;z:0;rX:0;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0.01;s:3000;e:Power3.easeOut;" 
                    data-transform_out="s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;" 
                    data-mask_in="x:[100%];y:0;s:inherit;e:inherit;" 
                    data-splitin="none" 
                    data-splitout="none"  
                    data-responsive_offset="on"
                    data-start="500">
                    <div class="slide-content-box">
                        <!--<h3>Feel good to with</h3>-->
                        <p style="font-size:35px">Marque la diferencia ante sus competidores</p>
                        <!--<p>Universal business theme continues to grow ever day thanks to <br>the confidence our clients have in US. </p>-->
                    </div>
                </div>
                <!--<div class="tp-caption tp-resizeme" 
                    data-x="left" data-hoffset="600" 
                    data-y="center" data-voffset="140" 
                    data-transform_idle="o:1;"                         
                    data-transform_in="y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;s:2000;e:Power4.easeInOut;" 
                    data-transform_out="s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;"                     
                    data-splitin="none" 
                    data-splitout="none" 
                    data-responsive_offset="on"
                    data-start="2300">
                    <div class="slide-content-box">
                        <div class="button">
                            <a class="thm-btn yellow-bg" href="">OUR COMPANY</a>     
                        </div>
                    </div>
                </div>
                <div class="tp-caption tp-resizeme" 
                    data-x="left" data-hoffset="775" 
                    data-y="center" data-voffset="140" 
                    data-transform_idle="o:1;"                         
                    data-transform_in="y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;s:2000;e:Power4.easeInOut;" 
                    data-transform_out="s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;"                     
                    data-splitin="none" 
                    data-splitout="none" 
                    data-responsive_offset="on"
                    data-start="2600">
                    <div class="slide-content-box">
                        <div class="button">
                            <a class="thm-btn our-solution" href="">contact us</a>     
                        </div>
                    </div>
                </div>-->
            </li>
        </ul>
    </div>
</section>
<!--End rev slider wrapper--> 



<section class="service sec-padd-top">
    <div class="container">
        <div class="section-title center">
            <h2>Porque Elegir MaJock </h2>
        </div>
        <div class="row">
            <div class="col-md-4 col-sm-6 col-xs-12">
                <div class="item">
                    <figure class="img-box">
                        <a href="#"><img src="images/porqueelegir/crecimiento.jpg" alt=""></a>
                        <div class="bottom-content">
                            <div class="clearfix">
                                <div class="icon_box">
                                    <span class="icon-arrow"></span>
                                </div>
                                <h4>Crecimiento</h4>
                            </div>
                                
                        </div>
                        <div class="overlay-box">
                            <div class="inner-box">
                                <div class="clearfix">
                                    <div class="icon_box">
                                        <span class="icon-arrow"></span>
                                    </div>
                                    <h4>Crecimiento</h4>
                                </div>
                                    
                                <div class="text">
                                    <p>Creemos en el potencial de cada cliente, es por ello <br>que lo acompañamos en todo el proceso de posicionamiento.</p>
                                </div>
                                <div class="link">
                                    <!--<a href="#" class="default_link">READ MORE <i class="fa fa-angle-right"></i></a>-->
                                </div>
                            </div>
                                
                        </div>
                        
                    </figure>  
                </div>
            </div>
            <div class="col-md-4 col-sm-6 col-xs-12">
                <div class="item">
                    <figure class="img-box">
                        <a href="#"><img src="images/porqueelegir/Inovacion.jpg" alt=""></a>
                        <div class="bottom-content">
                            <div class="clearfix">
                                <div class="icon_box">
                                    <span class="icon-travel"></span>
                                </div>
                                <h4>Innovación</h4>
                            </div>
                                
                        </div>
                        <div class="overlay-box">
                            <div class="inner-box">
                                <div class="clearfix">
                                    <div class="icon_box">
                                        <span class="icon-travel"></span>
                                    </div>
                                    <h4>Innovación</h4>
                                </div>
                                    
                                <div class="text">
                                    <p>La tecnología está siempre innovando y los procesos de una empresa tiene que ir de la mano.</p>
                                </div>
                                <div class="link">
                                    <!--<a href="#" class="default_link">READ MORE <i class="fa fa-angle-right"></i></a>-->
                                </div>
                            </div>
                                
                        </div>
                    </figure>  
                </div>
            </div>
            <div class="col-md-4 col-sm-6 col-xs-12">
                <div class="item">
                    <figure class="img-box">
                        <a href="#"><img src="images/porqueelegir/Puntualidad.jpg" alt=""></a>
                        <div class="bottom-content">
                            <div class="clearfix">
                                <div class="icon_box">
                                    <span class="icon-search"></span>
                                </div>
                                <h4>Puntualidad</h4>
                            </div>
                                
                        </div>
                        <div class="overlay-box">
                            <div class="inner-box">
                                <div class="clearfix">
                                    <div class="icon_box">
                                        <span class="icon-search"></span>
                                    </div>
                                    <h4>Puntualidad</h4>
                                </div>
                                    
                                <div class="text">
                                    <p>Es nuestro  principal  valor  como empresa, es por ello nuestro compromiso con ustedes.</p>
                                </div>
                                <div class="link">
                                    <!--<a href="#" class="default_link">READ MORE <i class="fa fa-angle-right"></i></a>-->
                                </div>
                            </div>
                                
                        </div>
                    </figure>  
                </div>
            </div>

        </div>
    </div>
</section>

<!--<section class="about-us sec-padd">
    <div class="container">
        <div class="row">
            <div class="col-md-6 col-sm-12">
                <div class="section-title">
                    <h2>About Universal</h2>
                </div>
                <div class="text">
                    <p>We have built an enviable reputation in the consumer goods, heavy industry, high-tech, manufacturing, medical, recreational vehicle, and transportation sectors. multidisciplinary team of engineering experts.</p>
                    <br>
                    <p>Who loves or pursues or desires to obtain pain of itself, because it is pain, but because occasionally circumstances occur in which toil and pain.</p>
                    <br>
                    <p>Denouncing pleasure and praising pain was born and I will give you a complete account of the system, expound the actual teachings.</p><br><br>
                    <div class="link"><a href="#" class="thm-btn">know more</a></div>
                </div>
            </div>
            <div class="col-md-6 col-sm-12">
                <div class="img-box">
                    <img src="images/resource/graph.jpg" alt="">
                </div>
            </div>
        </div>
    </div>
</section>-->


<!--Fact Counter-->
<section class="fact-counter sec-padd">
    <div class="container">
        <div class="title center">
            <h2>Tenemos  más de 30 Años  de experiencia</h2>
            <p>Somos el proveedor líder de soluciones tecnológicas con más de 30 años de experiencia ayudando a las empresas a encontrar soluciones y aportando un alto crecimiento para su negocio.</p>
        </div>
        <div class="row clearfix">
            <div class="counter-outer clearfix">
                <!--Column-->
                <article class="column counter-column col-md-3 col-sm-6 col-xs-12 wow fadeIn" data-wow-duration="0ms">
                    <div class="item">
                        <div class="count-outer"><span class="count-text" data-speed="3000" data-stop="2880">0</span></div>
                        <h4 class="counter-title">Horas de trabajo</h4>
                    </div>
                        
                </article>
                
                <!--Column-->
                <article class="column counter-column col-md-3 col-sm-6 col-xs-12 wow fadeIn" data-wow-duration="0ms">
                    <div class="item">
                        <div class="count-outer"><span class="count-text" data-speed="3000" data-stop="40">0</span>+</div>
                        <h4 class="counter-title">Implementaciones</h4>
                    </div>
                </article>
                
                <!--Column-->
                <article class="column counter-column col-md-3 col-sm-6 col-xs-12 wow fadeIn" data-wow-duration="0ms">
                    <div class="item">
                        <div class="count-outer"><span class="count-text" data-speed="3000" data-stop="430">0</span>+</div>
                        <h4 class="counter-title">Tazas de café</h4>
                    </div>
                </article>
                
                <!--Column-->
                <article class="column counter-column col-md-3 col-sm-6 col-xs-12 wow fadeIn" data-wow-duration="0ms">
                    <div class="item">
                        <div class="count-outer"><span class="count-text" data-speed="3000" data-stop="2300">0</span></div>
                        <h4 class="counter-title">Visitas web</h4>
                    </div>
                </article>
            </div>
        </div>
    </div>
</section>




<div class="growth-service style-2 sec-padd" style="background-image: url(images/background/6.jpg);">
    <div class="container">
        <div class="three-column-carousel">
            <div class="item center">
                <div class="icon_box">
                    <span class="fa fa-bed"></span>
                </div>
                <div class="content">
                    <h4>Hotel</h4>
                    <p>Sistema completamente integrado que le va a permitir obtener una mejor gestión de su establecimiento.</p>
                </div>
            </div>
            <div class="item center">
                <div class="icon_box">
                    <span class="fa fa-cutlery"></span>
                </div>
                <div class="content">
                    <h4>Restaurant</h4>
                    <p>Rápido simple  y fácil de utilizar.</p>
                </div>
            </div>
            <div class="item center">
                <div class="icon_box">
                    <span class="fa fa-plane"></span>
                </div>
                <div class="content">
                    <h4>Agencia de viajes</h4>
                    <p>Dinamice y distribuya  sus ventas con nuestro sistema.</p>
                </div>
            </div>
            <div class="item center">
                <div class="icon_box">
                    <span class="fa fa-globe"></span>
                </div>
                <div class="content">
                    <h4>Tour Operador</h4>
                    <p>Maximice la gestión de sus procesos de producción y asócielo a cada paquete turístico de forma simple y rápida.</p>
                </div>
            </div>
            <div class="item center">
                <div class="icon_box">
                    <span class="fa fa-cart-plus"></span>
                </div>
                <div class="content">
                    <h4>Retail</h4>
                    <p>Aumente sus ventas y tenga un mejor  control de su stock.</p>
                </div>
            </div>
            <div class="item center">
                <div class="icon_box">
                    <span class="fa fa-users"></span>
                </div>
                <div class="content">
                    <h4>Consultoría</h4>
                    <p>Ayudamos a mejorar todos sus procesos internos y externos para el éxito de su empresa.</p>
                </div>
            </div>
            
        </div>
    </div>
</div>

<section class="testimonials-section sec-padd">
    <div class="container">
    
        <!--Slider-->      
        <div class="testimonials-slider">
            
            <!--Slide-->
            <article class="slide-item center">
                <div class="img-box">
                    <a href="#"><img src="images/clientes/1.jpg" alt="" class="img-circle"></a>
                </div>
                
                <div class="slide-text">
                    <p>Son una empresa joven, dinámica y el servicio queme brindaron fue muy personalizado. <br>No dudaría en recomendarlos. Gracias por todo.<br>
                </div>
                <div class="author">
                    <h4>Manager - Customer Service At MISTERBANDB</h4>
                    <!--<p>21st Aug 2016</p>-->
                </div>
            </article>
            <article class="slide-item center">
                <div class="img-box">
                    <a href="#"><img src="images/clientes/2.jpg" alt="" class="img-circle"></a>
                </div>
                
                <div class="slide-text">
                    <p>Empresa con personal enfocado en su misión y visión. Ademas, muy comprometidos con sus clientes.</p><br>
                </div>
                <div class="author">
                    <h4>Ruben Asmat - Asistente de Gerencia Mega Hoteles</h4>
                    <!--<p>21st Aug 2016</p>-->
                </div>
            </article>


        </div>
        
    </div>    
</section>

<section class="clients-section sec-padd">
    <div class="container">
        <div class="section-title">
            <h2>Estamos Conectados</h2>
        </div>
        <div class="client-carousel owl-carousel owl-theme">

            <div class="item tool_tip" title="media partner">
                <img src="images/EstamosConectados/1.png" alt="Awesome Image">
            </div>
            <div class="item tool_tip" title="media partner">
                <img src="images/EstamosConectados/2.png" alt="Awesome Image">
            </div>
            <div class="item tool_tip" title="media partner">
                <img src="images/EstamosConectados/3.png" alt="Awesome Image">
            </div>
            <div class="item tool_tip" title="media partner">
                <img src="images/EstamosConectados/4.png" alt="Awesome Image">
            </div>
            <div class="item tool_tip" title="media partner">
                <img src="images/EstamosConectados/5.png" alt="Awesome Image">
            </div>
            <div class="item tool_tip" title="media partner">
                <img src="images/EstamosConectados/6.png" alt="Awesome Image">
            </div>
            <div class="item tool_tip" title="media partner">
                <img src="images/EstamosConectados/7.png" alt="Awesome Image">
            </div>
            <div class="item tool_tip" title="media partner">
                <img src="images/EstamosConectados/8.png" alt="Awesome Image">
            </div>
            <div class="item tool_tip" title="media partner">
                <img src="images/EstamosConectados/9.png" alt="Awesome Image">
            </div>
            <div class="item tool_tip" title="media partner">
                <img src="images/EstamosConectados/10.png" alt="Awesome Image">
            </div>
            <div class="item tool_tip" title="media partner">
                <img src="images/EstamosConectados/11.png" alt="Awesome Image">
            </div>
            <div class="item tool_tip" title="media partner">
                <img src="images/EstamosConectados/12.png" alt="Awesome Image">
            </div>
            <div class="item tool_tip" title="media partner">
                <img src="images/EstamosConectados/13.png" alt="Awesome Image">
            </div>
            <div class="item tool_tip" title="media partner">
                <img src="images/EstamosConectados/14.png" alt="Awesome Image">
            </div>
            <div class="item tool_tip" title="media partner">
                <img src="images/EstamosConectados/15.png" alt="Awesome Image">
            </div>
            <div class="item tool_tip" title="media partner">
                <img src="images/EstamosConectados/16.png" alt="Awesome Image">
            </div>

        </div>
    </div>  
</section>



<!--<section class="blog-section sec-padd-top">
    <div class="container">
        <div class="section-title center">
            <h2>latest news</h2>
        </div>
        <div class="row">
            <div class="col-md-4 col-sm-6 col-xs-12">
                <div class="default-blog-news wow fadeInUp animated" style="visibility: visible; animation-name: fadeInUp;">
                    <div class="img-box">
                        <a href="blog-details.html"><img src="images/blog/1.jpg" alt="News"></a>
                    </div>
                    <div class="lower-content">
                        <div class="date center">21 <br> Aug</div>
                        <div class="text">
                            <h4><a href="blog-details.html">Retail banks wake up to digital</a></h4>
                            <p>Know how to pursue pleasure rationally seds our encounter consequences complete account of the system and expound works.</p>                            
                        </div>
                        <div class="post-meta"><a href="#" class="link_btn">Read More</a><span><i class="fa fa-user"></i>By Antony</span><span><i class="fa fa-comments"></i>22 Comments</span></div>
                        
                    </div>
                </div>
                
            </div>
            <div class="col-md-4 col-sm-6 col-xs-12">
                <div class="default-blog-news wow fadeInUp animated" style="visibility: visible; animation-name: fadeInUp;">
                    <div class="img-box">
                        <a href="blog-details.html"><img src="images/blog/2.jpg" alt="News"></a>
                    </div>
                    <div class="lower-content">
                        <div class="date center">17 <br> May</div>
                        <div class="text">
                            <h4><a href="blog-details.html">Create great WordPress theme</a></h4>
                            <p>Which toil and pain can procure him some greater pleasure. To taken a trivial examples, which of us ever undertakes laborious.</p>                            
                        </div>
                        <div class="post-meta"><a href="#" class="link_btn">Read More</a><span><i class="fa fa-user"></i>By Antony</span><span><i class="fa fa-comments"></i>22 Comments</span></div>
                        
                    </div>
                </div>
                
            </div>
            <div class="col-md-4 col-sm-6 col-xs-12">
                <div class="default-blog-news wow fadeInUp animated" style="visibility: visible; animation-name: fadeInUp;">
                    <div class="img-box">
                        <a href="blog-details.html"><img src="images/blog/3.jpg" alt="News"></a>
                    </div>
                    <div class="lower-content">
                        <div class="date center">24 <br> Apr</div>
                        <div class="text">
                            <h4><a href="blog-details.html">How to improve employees skills</a></h4>
                            <p>Expound the actual teachings of the great explorer of the truth, the master-builder rejects, dislikes, or pleasure of human happiness.</p>                            
                        </div>
                        <div class="post-meta"><a href="#" class="link_btn">Read More</a><span><i class="fa fa-user"></i>By Antony</span><span><i class="fa fa-comments"></i>22 Comments</span></div>
                        
                    </div>
                </div>
                
            </div>
            
        </div>
    </div>
</section>-->

<section class="consultations sec-padd-top"> 
    <div class="container">
        <div class="row">
            <div class="col-md-6 col-sm-12">
                <div class="section-title">
                    <h2>Contactenos</h2>
                </div>
                <div class="text">
                    <p>¿Desea que uno de nuestros asesores de negocios se comunique con usted?</p>
                    <p>Envíe sus datos en el campo dado y uno de nuestros agentes se pondrá en contacto con usted lo más antes posible.</p>
                </div>
            </div>
            <div class="col-md-5 col-md-offset-1 col-sm-12">
                <div class="default-form-area">
                    <form id="contact_form" name="contact_form" class="default-form" action="inc/sendmail.php" method="post">
                        <div class="row clearfix">
                            <div class="col-md-12 col-sm-12 col-xs-12">
                                <h5>Formulario de contacto </h5>
                                <div class="form-group">
                                    <select class="text-capitalize selectpicker" name="form_subject" class="form-control required" data-style="g-select" data-width="100%">
                                        <option value="0" selected="">Software para hotel</option>
                                        <option value="1">Restaurant</option>
                                        <option value="2">Agencia de viaje</option>
                                        <option value="3">Tour operador</option>
                                        <option value="4">Retail</option>
                                        <option value="5">Hardware</option>
                                        <option value="6">Webs</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                
                                <div class="form-group">
                                    <input type="text" name="form_name" class="form-control" value="" placeholder="Nombre " required="">
                                </div>
                            </div>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <div class="form-group">
                                    <input type="text" name="form_phone" class="form-control" value="" placeholder="Teléfono">
                                </div>
                            </div>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <div class="form-group">
                                    <input type="text" name="form_email" class="form-control" value="" placeholder="Email">
                                </div>
                            </div>
                            <div class="col-md-12 col-sm-12 col-xs-12">
                                <div class="form-group">
                                    <textarea name="form_comentarios" class="form-control" placeholder="Comentarios"></textarea>
                                </div>
                            </div>
                            
                            <div class="col-md-12 col-sm-12 col-xs-12">
                                <div class="form-group">
                                    <input id="form_botcheck" name="form_botcheck" class="form-control" type="hidden" value="">
                                    <button class="thm-btn thm-color" type="submit" data-loading-text="Please wait...">Enviar</button>
                                </div>
                            </div>   

                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>







<?php include('footer.php'); ?>

</div>
	
</body>
</html>