<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Productos || Majock Consulting</title> 

    <!-- mobile responsive meta -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">


    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/responsive.css">
    
    <link rel="apple-touch-icon" sizes="180x180" href="images/favicons/apple-touch-icon.png">
    <link rel="icon" type="image/png" href="images/favicons/favicon-32x32.png" sizes="32x32">
    <link rel="icon" type="image/png" href="images/favicons/favicon-16x16.png" sizes="16x16">

</head>
<body>

<div class="boxed_wrapper">



    

<?php include('header.php'); ?>

 


 


<div class="inner-banner has-base-color-overlay text-center" style="background: url(images/background/1.jpg);">
    <div class="container">
        <div class="box">
            <h3>Productos </h3>
        </div>
    </div>
    <div class="breadcumb-wrapper">
        <div class="container">
            <div class="pull-left">
                <ul class="list-inline link-list">
                    <li>
                        <a href="index.php">Inicio</a>
                    </li>
                    <li>
                        Productos
                    </li>
                </ul>
            </div>
            <div class="pull-right">
                <a href="#" class="get-qoute"><i class="fa fa-share-alt"></i>share</a>
            </div>
        </div>
    </div>
</div>




<section class="service-single sec-padd">
    <div class="container">
        <div class="row">     
            <div class="col-md-3">
            
                <div class="service-sidebar">
                    <ul class="service-catergory">
                        <!--<li class="active"><a href="/productos.php?a=hoteles">Software para Hoteles</a></li>-->
                        <li><a href="/productos.php?a=hoteles">Software para Hoteles</a></li>
                        <li><a href="/productos.php?a=restaurantes">Software para Bares, Casinos y Restaurante</a></li>
                        <li><a href="/productos.php?a=agenciadeviajes">Software para Agencia de Viajes</a></li>
                        <li><a href="/productos.php?a=touroperador">Software para Tour Operador</a></li>
                        <li><a href="/productos.php?a=retail">Software para Retail</a></li>

                    </ul>
                        
                    <br><br>
                    <!--<div class="brochures"> 
                        <h4>Our Brochures</h4>
                        <p>Download our comapny profile & 2016 financial brochure.</p>

                        <ul class="brochures-lists">
                            <li>
                                <a href="#"><span class="fa fa-file-pdf-o"></span></a>
                            </li>
                            <li>
                                <a href="#"><span class="fa fa-file-text-o"></span></a>
                            </li>
                        </ul>
                        <i class="icon icon-sheet"></i>
                    </div>-->
                    <br><br>
                    <div class="getin-tuch">
                        <h4>¿Tiene alguna duda?</h4>
                        <p>Envíanos un correo electrónico y nos pondremos en contacto a la brevedad posible o llámanos al <b>(+51) 7231180 - (+51) 3295650</b></p>
                        <div class="link">
                            <a href="/contacto.php" class="default_link">Ubicanos<i class="fa fa-angle-right"></i></a>
                        </div>
                        <i class="icon icon-multimedia-1"></i>
                    </div>

                </div>
            </div>
            <?php
                switch ($_GET["a"]) {
                  case 'hoteles':
                  include ("hotelescontenido.php");
                  break;
                  case 'restaurantes':
                  include ("restaurantescontenido.php");
                  break;
                  case 'retail':
                  include ("retailcontenido.php");
                  break;
                  case 'touroperador':
                  include ("touroperadorcontenido.php");
                  break;
                  case 'agenciadeviajes':
                  include ("agenciadeviajescontenido.php");
                  break;
                  default:
                  include ("hotelescontenido.php");
                  break;
                }
            ?>
        </div>
    </div>
</section>







<div class="call-out">
    <div class="container">
        <div class="float_left">
            <h4>OFRECEMOS  LA SOLUCION CORRECTA PARA SU NEGOCIO</h4>
        </div>
        <div class="float_right">
            <a href="/contacto.php" class="thm-btn">MÁS INFORMACIÓN </a>
        </div>
    </div>
</div>

<?php include('footer.php'); ?>

</div>
    
</body>
</html>