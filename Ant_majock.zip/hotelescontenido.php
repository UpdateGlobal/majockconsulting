<div class="col-md-9">
                <div class="outer-box">
                    <div class="intro-img">
                        <div class="row">
                            <div class="col-md-6 col-sm-6 col-xs-12">
                            <div class="section-title">
                                <h3>Sofware para Hoteles</h3>
                            </div>
                            <br>
                                <div class="img-box">
                                    <a href="#"><img src="images/service/16.jpg" alt=""></a>
                                    <h5> El éxito de una empresa se ve reflejado las decisiones que se toman.</h5>
                                </div>
                            </div>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <video width="320" height="240" controls>
                                  <source src="http://www.arionpoint.com/Arion.mp4" type="video/mp4">
                                </video>
                            </div>
                        </div>
                    </div>
                    <div class="text">
                        <p>El objetivo de Majock consulting, es ofrecer asesoría estratégica y técnica que permita resolver problemas o potencializar las fortalezas, sea en casos de personas, empresas privadas o Entidades Públicas, utilizando métodos y procesos que permitan obtener el mejor resultado para su negocio.</p>
                        <p>La importancia de utilizar buenas prácticas es reflejo de un buen uso del potencial humano. Es por ello que en Majock Consulting le brindamos las herramientas necesarias para la toma de decisiones y lograr los resultados deseados que toda empresa aspira.</p>
                    </div>  
                    <br><br><div class="border-bottom"></div><br><br> 
                    <div class="section-title">
                        <h3>Ventajas del sistema para su Hotel</h3>
                    </div> 
                    <div class="row">
                        <div class="col-md-4 col-sm-4 col-xs-6">
                            <div class="growth-item">
                                <div class="icon_box">
                                    <span class="icon-business"></span>
                                </div>
                                <h4>Eficaz</h4>
                                <div class="content center">
                                    <p>Las diversas herramientas con las que cuenta el software va a contribuir en la toma de decisiones haciéndolo más rápido e intuitivo el uso diario en su establecimiento.</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 col-sm-4 col-xs-6">
                            <div class="growth-item">
                                <div class="icon_box">
                                    <span class="icon-graphic"></span>
                                </div>
                                <h4>Seguridad</h4>
                                <div class="content center">
                                    <p>Arion está diseñado con los más altos estándares en seguridad informática, proporcionándole estabilidad, confianza y absoluta privacidad a su información, convirtiéndose así, en una poderosa herramienta que le ayudará a mejorar sus operaciones y la rentabilidad de su negocio.</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 col-sm-4 col-xs-6">
                            <div class="growth-item">
                                <div class="icon_box">
                                    <span class="icon-business-1"></span>
                                </div>
                                <h4>Innovación</h4>
                                <div class="content center">
                                    <p>La innovación es parte de nuestra filosofía, es por ello que estamos mejorando constantemente para satisfacer las necesidades de nuestros clientes, cumpliendo con los más altos estándares internacionales.</p>
                                </div>
                            </div>
                        </div>
                    </div><br>
                    <div class="section-title">
                        <h3>Estrategia de Negocio:</h3>
                    </div>
                    <div class="text">
                        <p>Nuestra solución permite un control del 100% de la gestión operativa, comercial y gerencial, integrando las diferentes áreas de su establecimiento, así como del incremento de sus ventas. 
Es por ello que crecemos con ustedes y lo acompañamos en todo el proceso de adecuación de nuestro sistema a su negocio</p>
                    </div>
                    <div class="tabs-outer">
                        <!--Tabs Box-->
                        <div class="tabs-box tabs-style-two">
                            <!--Tab Buttons-->
                            <ul class="tab-buttons clearfix">
                                <li data-tab="#tab-one" class="tab-btn active-btn">PMS ( Proporty Management System)</li>
                                <li data-tab="#tab-two" class="tab-btn">Punto de Venta (POS) </li>
                                <li data-tab="#tab-three" class="tab-btn">Revenue Manager:</li>
                                <li data-tab="#tab-four" class="tab-btn">Channel manager y CRS</li>
                            </ul>
                        
                            <!--Tabs Content-->
                            <div class="tabs-content">
                                <!--Tab / Active Tab-->
                                <div class="tab active-tab" id="tab-one" style="display: block;">
                                    <div class="text-content clearfix">
                                        <div class="img-box float_left">
                                            <a href="#"><img src="images/productos/pms.jpg" alt="" width="289px" height="150px" ></a>
                                        </div>
                                        <div class="text float_left"><p>El PMS permite gestionar las operaciones  de su hotel. Gracias a diferentes módulos que van a permitir una mejor administración de las  áreas críticas de tu establecimiento,  está diseñado para gestionar desde hoteles pequeños hasta grandes  cadenas hoteleras.</p>
<p>Una de las grandes ventajas de nuestra solución es que se integra muy fácilmente a cualquier sistema  contable, almacén, distribución, existente en el mercado.</p></div>
                                    </div>
                                </div>
                                
                                <!--Tab-->
                                <div class="tab" id="tab-two" style="display: none;">
                                    <div class="text-content clearfix">
                                        <div class="img-box float_left">
                                            <a href="#"><img src="images/Punto de venta POS.jpg" alt="" width="289px" height="150px" ></a>
                                        </div>
                                        <div class="text float_left"><p>La interfaz de nuestro punto de venta es fácil e intuitivo.<br> Es completamente configurable adaptándose a cualquier  tipo de negocio. Está diseñado para ser operado desde  cualquier dispositivo móvil y táctil.</p><p>Optimicé sus  ventas y  controles sus almacenes. El Software se integra fácilmente a cualquier  sistema de gestión. </p></div>
                                    </div>
                                </div>
                                
                                <!--Tab-->
                                <div class="tab" id="tab-three" style="display: none;">
                                    <div class="text-content clearfix">
                                        <div class="img-box float_left">
                                            <a href="#"><img src="images/revenue manager.jpg" alt="" style="width: 288px;"></a>
                                        </div>
                                        <div class="text float_left"><p>Tenga un mejor control de sus tarifas aplicando estrategias que le llevaran a una mejor rentabilidad. Nuestra solución le proporcionara un mejor análisis de su estrategia de ventas.</p><p>Los históricos de reservas y la tasa ocupación le van ayudar a tener una mejor proyección de ventas y una óptima segmentación de mercado  permitiéndole además la comparación entre temporadas pasadas.</p><p>Optimicé sus precios  con fundamento, tenemos lo que necesita.
</p></div>
                                    </div>
                                </div>
                                <!--Tab-->
                                <div class="tab" id="tab-four" style="display: none;">
                                    <div class="text-content clearfix">
                                        <div class="img-box float_left">
                                            <a href="#"><img src="images/productos/channel-manager.jpg" alt=""></a>
                                        </div>
                                        <div class="text float_left"><p>Olvídese de estar saltando de portal en portal, entrando y saliendo  de cada OTA (On Line Travel Agency) para gestionar y distribuir su disponibilidad.</p><p>Nuestra solución le permite controlar todas estas operaciones desde una sola plataforma, además de administrar mejor la disponibilidad y tarifas en cada uno de tus canales de venta on line, podrás integrarlo al PMS en tiempo real.</p><p>Incremente sus ventas y mejore su posición en la Web con nuestro CRS (Sistema Centralizado de Reservaciones) incrustando el motor de reservas a su Pagina WEB, proporcionándole mejor rentabilidad ya que estará libre de comisiones y regalías.</p><p>Estamos conectados con más de 80 canales de distribución.</p></div>
                                    </div>
                                </div>
                                
                            </div>
                            
                        </div>
                    </div>
                </div>
            </div>