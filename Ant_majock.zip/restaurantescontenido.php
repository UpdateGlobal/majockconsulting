<div class="col-md-9">
<div class="outer-box">
                    <div class="row">
                        <div class="col-md-6 col-sm-6 col-xs-12">
                            <div class="section-title">
                                <h3>BARES Y RESTAURANTES</h3>
                            </div>
                            <h4>NUESTROS SOFTWARE’S</h4><br>
                            <div class="text">
                                <p>La industria de la restauración está en constante crecimiento, por lo tanto la competencia es cada día más dura, para lo cual debemos estar a la vanguardia de la tecnología a todo nivel. Las herramientas que vayamos a usar para optimizar los tiempos de respuesta son muy importantes por lo que debemos saber elegir, de esto va a depender el éxito de nuestro negocios.</p>
                                <p>Majock trae el software más completo de gestión especializado en bares y restaurantes, por sus diseños totalmente intuitivos y a su medida.</p>
                                <p>El tiempo de respuesta es fundamental para un buen servicio, la gestión de pedidos mediante comandas manuales es una práctica descontinuada. Por esta razón queremos dar a conocer nuestra herramienta de gestión operativa, comercial y administrativa de bares y restaurantes, de forma fácil, rápida e intuitiva (pantallas táctiles), donde el camarero solo tiene que seleccionar la orden que el cliente desea y este será atendido inmediatamente y en forma directa en la cocina o bar.</p>
                                <p>Le ayudará tanto en el control de su almacén como en la gestión de compras de su empresa y pagos. Tome decisiones acertadas, basadas en los informes que le entregará la aplicación sobre ventas, compras, consumos, ocupación de mesas por horas, ventas por camarero, inventarios, ABC de ventas…</p>
                                <p>Todo un sistema creado y pensado para el éxito de su negocio.</p>

                            </div>
                        </div>

                        <div class="col-md-6 col-sm-6 col-xs-12">
                            <div class="img-box"><a href="#"><img src="images/Bar420x305.jpg" alt=""></a></div>
                            <div class="content center over-view">
                                <h4>Tenemos lo que busca </h4>
                                <a href="/contacto.php$contacto"><i class="fa fa-long-arrow-right"></i>CONTACTENOS</a>
                            </div>
                        </div>
                    </div><br><br>
                    <div class="border-bottom"></div>
                    <br><br>
                    <div class="section-title">
                        <h3>YA ESTAMOS!</h3>
                    </div>
                    <div class="text">
                        <p>Con mas de 30 años de experiencia en el mercado y gracias a nuestros clientes hemos logrado alcanzar los más altos estándares de programación, diseño y servicio. Gracias por confiar en nosotros y permitirnos crecer día a día juntos.</p>
                        <p>Más de 2.350 instalaciones en Europa, Latinoamérica y Norteamerica nos avalan.</p>
                    </div>
                    <div class="analysis-chart">
                        <div class="row">
                            <div class="col-md-4 col-sm-4 col-xs-6">    
                                <div class="item center">
                                    <img src="images/service/10.jpg" alt="">
                                    <h4>Europa 50%</h4>
                                </div>
                                
                            </div>
                            <div class="col-md-4 col-sm-4 col-xs-6">    
                                <div class="item center">
                                    <img src="images/service/10.jpg" alt="">
                                    <h4>Latinoamerica 35%</h4>
                                </div>
                                
                            </div>
                            <div class="col-md-4 col-sm-4 col-xs-6">    
                                <div class="item center">
                                    <img src="images/service/10.jpg" alt="">
                                    <h4>Norteamerica 15%</h4>
                                </div>
                                
                            </div>
                        </div>
                    </div>
                        
                    <div class="section-title">
                        <h3>AQUÍ ALGUNAS RAZONES PARA ELEGIRNOS</h3>
                    </div>    
                     <div class="text">
                            <p><span>1.- Fáciles de utilizar: Gracias y su diseño visual y totalmente intuitivo no requiere de mucha capacitació</span><br>
                            <span>2.- Fiables: Los datos siempre están protegidos, en momentos de máximo trabajo y en entornos multiusuario. Los datos son totalmente estables</span><br>
                            <span>3.- Seguros: Los usuarios se identifican a través de sus usuarios y contraseñas para acceder a sus funciones y permisos. Auditoria de todas las acciones de los empleados. Esto nos garantiza la seguridad de la información.</span><br>
                            <span>4.- Precisos: Garantiza el control de efectivo, simplifica el cuadre de caja y evita posibles hurtos.</span><br>
                            <span>5.- Escalables: Se adapta a la dimensión del cliente, desde un pequeño local, hasta una cadena con cientos de establecimientos.</span><br>
                            <span>6.- Rentables: Consigue mayor rotación de ventas y ayuda a reducirlas mermas de producto y los costes del personal.</span></p>
                    </div>
                </div>

</div>