<footer class="main-footer sec-padd-top" style="background-image: url(images/background/4.jpg);">
    <div class="container">
        <div class="row">
            <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                <div class="about-widget">
                    <figure class="footer-logo"><a href="index.php"><img src="images/logo/logo2.png" alt="" style="width: 200px;"></a></figure>
                    
                    <div class="text">
                        <p>Somos un gran equipo de profesionales experimentados en el sector hotelero, en Majock Consulting contamos con un staff de profesionales que poseen una vasta experiencia en instalación y configuración de hardware y software. Además somos representantes de las más reconocidas marcas del mercado.</p>
                    </div>
                    <br>
                    
                </div>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                <!--<div class="latest-post">
                    <div class="section-title">
                        <h3>Latest News</h3>
                    </div>
                    <div class="post">
                        <figure class="post-thumb"><img src="images/resource/post-thumb-1.jpg" alt=""><a href="#" class="overlay-link"><span class="fa fa-link"></span></a></figure>
                        <h5><a href="#">Seminar for improve your <br>business growth </a></h5>
                        <p>Master builder of human happiness</p>
                        <div class="link">
                            <a href="#" class="default_link">More About us <i class="fa fa-angle-right"></i></a>
                        </div>
                    </div>
                    <div class="post">
                        <figure class="post-thumb"><img src="images/resource/post-thumb-2.jpg" alt=""><a href="#" class="overlay-link"><span class="fa fa-link"></span></a></figure>
                        <h5><a href="#">How to improve employees <br>efficient skills </a></h5>
                        <p>To take a trivial example, which of us</p>
                        <div class="link">
                            <a href="#" class="default_link">More About us <i class="fa fa-angle-right"></i></a>
                        </div>
                    </div>
                   </div>--> 
                    <ul class="contact-infos">
                        <li>
                            <div class="icon_box">
                                <i class="fa fa-map-marker"></i>
                            </div><!-- /.icon-box -->
                            <div class="text-box">
                                <h5>Calle Manco Segundo 2462 Oficina 401<br> Lince, Lima</h5>
                            </div><!-- /.text-box -->
                        </li>
                        <li>
                            <div class="icon_box">
                                <i class="fa fa-phone"></i>
                            </div><!-- /.icon-box -->
                            <div class="text-box">
                                <h5>Telefonos</h5>
                                <p>7231180 – 3295650</p>
                            </div><!-- /.text-box -->
                        </li>
                        <li>
                            <div class="icon_box">
                                <i class="fa fa-envelope-o"></i>
                            </div><!-- /.icon-box -->
                            <div class="text-box">
                                <h5>Mail de contacto</h5>
                                <p>Info@majockconsulting.com</p>
                            </div>
                        </li>
                        <li>
                            <div class="icon_box">
                                <i class="fa fa-briefcase"></i>
                            </div><!-- /.icon-box -->
                            <div class="text-box">
                                <h5>Trabaja con nosotros</h5>
                                <p>rrhh@majockconsulting.com</p>
                            </div>
                        </li>
                    </ul>
                
            </div>
            <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                <div class="footer-link-widget">
                    <div class="section-title">
                        <h3>Enlaces rápidos</h3>
                    </div>
                    <div class="row">
                        <div class="col-md-6 col-sm-6 col-sx-6">
                            <ul class="list">
                                <li><a href="quienessomos.php">Quienes Somos</a></li>
                                <li><a href="#">Porque Elegirnos</a></li>
                                <li><a href="contacto.php#contacto">Contáctenos</a></li>
                                <li><a href="productos.php?a=hoteles">Software para hoteles</a></li>
                                <li><a href="productos.php?a=restaurantes">Software para Restaurantes</a></li>
                            </ul>
                        </div>
                        <div class="col-md-6 col-sm-6 col-sx-6">
                            <ul class="list">
                                <li><a href="productos.php?a=agenciadeviajes">Software para Agencias de Viajes</a></li>
                                <li><a href="productos.php?a=touroperador">Software para Tour Operadores</a></li>
                                <li><a href="productos.php?a=retail">Software para Retail</a></li>
                                <li><a href="#">Suscribete</a></li>
                            </ul>
                        </div>
                    </div>
                    <br>
                    <div class="opening-hour">
                        <h3>Horarios de atención</h3>
                        <br>
                        <p>Lunes a Viernes: 9.00 am. a 6.00 pm.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    
     
</footer>

<div class="footer-bottom">
    <div class="container">
        <div class="float_left copy-text">
            <p>Copyrights © 2017 Majock</p>
            
        </div>
        <div class="float_right">
            <ul class="social">
                <li>
                    <a href="https://www.facebook.com/Majockconsulting/?ref=aymt_homepage_panel"><i class="fa fa-facebook"></i></a>                              
                </li>
                <li>
                    <a href="https://twitter.com/MajockC"><i class="fa fa-twitter"></i></a>                               
                </li>
                <li>
                    <a href="skype:info.majock?call"><i class="fa fa-skype"></i></a>                             
                </li>
                <li>
                    <a href="https://www.linkedin.com/home?trk=nav_responsive_tab_home"><i class="fa fa-linkedin"></i></a>                              
                </li>
                <li>
                    <a href="https://plus.google.com/b/108574183967501053837/108574183967501053837"><i class="fa fa-google-plus"></i></a>     
                </li>
            </ul>
        </div>

    </div>
</div>


<!-- Scroll Top Button -->
	<button class="scroll-top tran3s color2_bg">
		<span class="fa fa-angle-up"></span>
	</button>
	<!-- pre loader  -->
	<div class="preloader"></div>


	<!-- jQuery js -->
	<script src="js/jquery.js"></script>
	<!-- bootstrap js -->
	<script src="js/bootstrap.min.js"></script>
	<!-- jQuery ui js -->
	<script src="js/jquery-ui.js"></script>
	<!-- owl carousel js -->
	<script src="js/owl.carousel.min.js"></script>
    <?php
        if( basename($_SERVER["SCRIPT_FILENAME"]) == 'quienessomos.php'){
            echo '<script src="js/bxslider.js"></script>'; 
        }
    ?>
	<!-- jQuery validation -->
	<script src="js/jquery.validate.min.js"></script>
	<!-- google map -->
	<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCRvBPo3-t31YFk588DpMYS6EqKf-oGBSI"></script> 
	<script src="js/gmap.js"></script>
	<!-- mixit up -->
	<script src="js/wow.js"></script>
	<script src="js/jquery.mixitup.min.js"></script>
	<script src="js/jquery.fitvids.js"></script>
    <script src="js/bootstrap-select.min.js"></script>
	<script src="js/menuzord.js"></script>

	<!-- revolution slider js -->
	<script src="assets/revolution/js/jquery.themepunch.tools.min.js"></script>
	<script src="assets/revolution/js/jquery.themepunch.revolution.min.js"></script>
	<script src="assets/revolution/js/extensions/revolution.extension.actions.min.js"></script>
	<script src="assets/revolution/js/extensions/revolution.extension.carousel.min.js"></script>
	<script src="assets/revolution/js/extensions/revolution.extension.kenburn.min.js"></script>
	<script src="assets/revolution/js/extensions/revolution.extension.layeranimation.min.js"></script>
	<script src="assets/revolution/js/extensions/revolution.extension.migration.min.js"></script>
	<script src="assets/revolution/js/extensions/revolution.extension.navigation.min.js"></script>
	<script src="assets/revolution/js/extensions/revolution.extension.parallax.min.js"></script>
	<script src="assets/revolution/js/extensions/revolution.extension.slideanims.min.js"></script>
	<script src="assets/revolution/js/extensions/revolution.extension.video.min.js"></script>

	<!-- fancy box -->
	<script src="js/jquery.fancybox.pack.js"></script>
	<script src="js/jquery.polyglot.language.switcher.js"></script>
	<script src="js/nouislider.js"></script>
	<script src="js/jquery.bootstrap-touchspin.js"></script>
	<script src="js/SmoothScroll.js"></script>
	<script src="js/jquery.appear.js"></script>
	<script src="js/jquery.countTo.js"></script>
	<script src="js/jquery.flexslider.js"></script>
    <script src="js/imagezoom.js"></script> 
	<script src="js/Chart.js"></script>	
	<script id="map-script" src="js/default-map.js"></script>
	<script src="js/custom.js"></script>

    <!-- BEGIN JIVOSITE CODE {literal} -->
<script type='text/javascript'>
(function(){ var widget_id = 'J3ci1wMluU';
var s = document.createElement('script'); s.type = 'text/javascript'; s.async = true; s.src = '//code.jivosite.com/script/widget/'+widget_id; var ss = document.getElementsByTagName('script')[0]; ss.parentNode.insertBefore(s, ss);})();</script>
<!-- {/literal} END JIVOSITE CODE -->