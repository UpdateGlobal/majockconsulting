<div class="col-md-9">
<div class="outer-box">
<div class="section-title">
                                <h3>Agencia de Viajes</h3>
                            </div>
                    <div class="img-box"><a href="#"><img src="/images/adv.jpg" alt=""></a></div>
                    <br>
                    
                    <br>
                    <div class="text">
                        <p>Porque sabemos cuáles son las principales necesidades de las agencias de viaje en el mercado actual y pensando en ellos, estamos contribuyendo con el desarrollo de su actividad insertando en el mercado un sistema que va permitir ayudar en la sistematización de procesos diarios del agente así como poder efectuar cambios en cada perfil de cliente.</p>
                        <p>Esto va con la Completa informatización de la agencia, teniendo un mejor control de los proveedores (agencias mayoristas, tour operadores), seguimiento del perfil del cliente, desde la reserva hasta el pago y todo esto completamente gestionado mediante un historial contable.</p>
                        <p>Además incluye un sistema de CRM que va a permitir aumentar las ventas, gracias a acciones concretas como e-mailing comercial y SMS. Así mismo brinda reportes del estado de la agencia con respecto a las ventas, por destinos, clientes fieles, etc.</p><br><br>
                    </div>
                    <div class="section-title">
                        <h3>Nuestra Experiencia</h3>
                    </div>
                    <div class="row">
                        <div class="col-md-7 col-sm-7 col-xs-12">
                            <div class="text">
                                <p>Fruto de la experiencia acumulada durante 34 años, ya es usado por más de 2.300 agencias en España y Latinoamérica (México, Chile, Perú....), con más de 6.250 agentes de viajes utilizándolo a diario.</p><br>
                            </div>
                            <ul class="benifit-list">
                                <li>Nuestro software agencias de viajes está homologado y recomendado por todos los principales Grupos

de Gestión y Franquicias del sector del Turismo (GEA, AIRMET, EUROPA, QUALITAS, PLANTOUR,

RIBERMOON, STAR, CYBAS, NEGO, LINEATOURS, PREMIUM, GLAUKA, INCAVISA, INNOVATOUR, OVER,

TOUROASIS, GIRAMONDO…..), siendo utilizado como materia de formación en numerosas Universidades

y Escuelas de Turismo. Tanto en España como en Latinoamérica.</li>
                            </ul>
                        </div>
                        <div class="col-md-5 col-sm-5 col-xs-12">
                            <div class="img-box"><a href="#"><img src="/images/experiencia.jpg" alt=""></a></div>
                        </div>
                    </div><br><br>
                    <!--<div class="section-title">
                        <h3>Performance System </h3>
                    </div>-->
                    <!--<div class="row">
                        <div class="col-md-7 col-sm-7 col-xs-12">
                            <div class="accordion-box accordion-style-two">
                                <!--Start single accordion box-->
                                <!--<div class="accordion animated out" data-delay="0" data-animation="fadeInUp">
                                    <div class="acc-btn">
                                        <p class="title">Customer Insights</p>
                                        <div class="toggle-icon">
                                            <span class="plus fa fa-arrow-circle-o-right"></span><span class="minus fa fa-arrow-circle-o-right"></span>
                                        </div>
                                    </div>
                                    <div class="acc-content">
                                        <div class="text"><p>
                                            Employers across all industry sectors to ensure that their internal sed HR systems processes align to their business requirements idea of denouncing pleasure and praising pain expound. 
                                        </p></div>
                                    </div>
                                </div>
                                <!--Start single accordion box-->
                                <!--<div class="accordion animated out" data-delay="0" data-animation="fadeInUp">
                                    <div class="acc-btn active">
                                        <p class="title">Customer Experience</p>
                                        <div class="toggle-icon">
                                            <i class="plus fa fa-arrow-circle-o-right"></i><i class="minus fa fa-arrow-circle-o-right"></i>
                                        </div>
                                    </div>
                                    <div class="acc-content collapsed">
                                        <div class="text"><p>
                                            Employers across all industry sectors to ensure that their internal sed HR systems processes align to their business requirements idea of denouncing pleasure and praising pain expound.
                                        </p></div>
                                    </div>
                                </div>

                                <!--Start single accordion box-->
                                <!--<div class="accordion animated out" data-delay="0" data-animation="fadeInUp">
                                    <div class="acc-btn">
                                        <p class="title">Leading of Way</p>
                                        <div class="toggle-icon">
                                            <i class="plus fa fa-arrow-circle-o-right"></i><i class="minus fa fa-arrow-circle-o-right"></i>
                                        </div>
                                    </div>
                                    <div class="acc-content">
                                        <div class="text"><p>
                                            Employers across all industry sectors to ensure that their internal sed HR systems processes align to their business requirements idea of denouncing pleasure and praising pain expound.
                                        </p></div>
                                    </div>
                                </div>


                            </div>
                        </div>
                        <div class="col-md-5 col-sm-5 col-xs-12">
                             <div class="text">
                                <p>Denouncing pleasure and praising pain was born and I will give you a complete account of the system no one rejects, dislikes, or avoids pleasure itself.</p><br>
                                <p>Expound the actually teachings of the great explorer of the truth, the master-builder of human happiness. No one rejects, dislikes, or avoids pleasure itself, because it is pleasure, but because those who do not know how to pursue pleasure rationally encounter consequences that are extremely painful.</p>
                            </div>
                        </div>
                    </div>-->
                    <br>

                </div>

</div>