<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Servicios || Majock Consulting</title> 

    <!-- mobile responsive meta -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">


    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/responsive.css">
    
    <link rel="apple-touch-icon" sizes="180x180" href="images/favicons/apple-touch-icon.png">
    <link rel="icon" type="image/png" href="images/favicons/favicon-32x32.png" sizes="32x32">
    <link rel="icon" type="image/png" href="images/favicons/favicon-16x16.png" sizes="16x16">

</head>
<body>

<div class="boxed_wrapper">



    

<?php include('header.php'); ?>

 


 


<div class="inner-banner has-base-color-overlay text-center" style="background: url(images/background/1.jpg);">
    <div class="container">
        <div class="box">
            <h3>Servicios </h3>
        </div>
    </div>
    <div class="breadcumb-wrapper">
        <div class="container">
            <div class="pull-left">
                <ul class="list-inline link-list">
                    <li>
                        <a href="index.php">Inicio</a>
                    </li>
                    <li>
                        Servicios
                    </li>
                </ul>
            </div>
            <div class="pull-right">
                <a href="#" class="get-qoute"><i class="fa fa-share-alt"></i>share</a>
            </div>
        </div>
    </div>
</div>




<section class="service-single sec-padd">
    <div class="container">
        <div class="row">     
            <!--<div class="col-md-3">
            
                <div class="service-sidebar">
                    <ul class="service-catergory">
                        <li><a href="business-growth.html">Business Growth</a></li>
                        <li class="active"><a href="sustainability.html">Sustainability</a></li>
                        <li><a href="performance.html">Performance</a></li>
                        <li><a href="advanced-analytics.html">Advanced Analytics</a></li>
                        <li><a href="organization.html">Organization</a></li>
                        <li><a href="customer-insights.html">Customer Insights</a></li>

                    </ul>
                        
                    <br><br>
                    <div class="brochures"> 
                        <h4>Our Brochures</h4>
                        <p>Download our comapny profile &amp; 2016 financial brochure.</p>

                        <ul class="brochures-lists">
                            <li>
                                <a href="#"><span class="fa fa-file-pdf-o"></span></a>
                            </li>
                            <li>
                                <a href="#"><span class="fa fa-file-text-o"></span></a>
                            </li>
                        </ul>
                        <i class="icon icon-sheet"></i>
                    </div>
                    <br><br>
                    <div class="getin-tuch">
                        <h4>Get Touch With Us</h4>
                        <p>You can also send us an <a href="#">email</a>  and we’ll get in touch shortly, or Troll Free Number <b>- (+91) 00-700-6202.</b></p>
                        <div class="link">
                            <a href="#" class="default_link">LOCATE US<i class="fa fa-angle-right"></i></a>
                        </div>
                        <i class="icon icon-multimedia-1"></i>
                    </div>

                </div>
            </div>-->
            <div class="col-md-12">
                <div class="outer-box">
                    <div class="row">
                        <div class="col-md-6 col-sm-6 col-xs-12">
                            <div class="section-title">
                                <h3>Hardware</h3>
                            </div>
                            <div class="text">
                                <p>Le ofrecemos una amplia gama en equipos informáticos, sistemas de seguridad y video vigilancia para el domicilio y todo tipo de negocios.</p>
                                <p>Equipos de escritorio, servidores, centros de datos, hogar y empresa, soluciones inalámbricas y todos los servicios relacionados.</p>
                                <p>Conoce un poco de nuestros servicios:</p>
                                <p>Consultorías y asesorías técnicas sobre diversas áreas como:</p>
                                <p style="margin-lef:40px">
                                    <span style="margin-lef:10px">- Telecomunicaciones</span><br>
                                    <span style="margin-lef:10px">- Seguridad</span><br>
                                    <span style="margin-lef:10px">- Gestión de infraestructuras informáticas, implementaciones de centros de comunicaciones de datos y de voz, Etc.</span>
                                </p>    
                            </div>
                        </div>

                        <div class="col-md-6 col-sm-6 col-xs-12">
                            <div class="img-box"><a href="#"><img src="images/Hardware420x305.jpg" alt=""></a></div>
                            <!--<div class="content center over-view">
                                <h4>We deliver right solution for you</h4>
                                <a href="contact.html"><i class="fa fa-long-arrow-right"></i>Free Consultation</a>
                            </div>-->
                        </div>
                    </div><br><br>
                    <div class="border-bottom"></div>
                    <br><br>
                    <div class="section-title">
                        <h3>Soporte Técnico</h3>
                    </div>
                    <div class="text">
                        <p>Nuestro equipo de técnicos altamente capacitado se encargará de revisar periódicamente todos los equipos informáticos y electrónicos que posea su empresa o tenga en su casa. El propósito de este mantenimiento es maximizar su correcto funcionamiento, extender la vida útil de sus equipos y brindarle las soluciones correctivas según sea el caso.</p>
                        <p>Nuestro servicio está orientado a disminuir la cantidad de incidencias y los tiempos de parada de los equipos y sistemas, trabajando para ser una empresa de verdadero soporte Informático y no un equipo de bomberos.</p>
                        <p>Como soporte técnico ofrecemos el servicio de mantenimiento preventivo, mantenimiento correctivo y el asesoramiento tecnológico que le brindara las mejores soluciones para su empresa y hogar.</p>
                        <p>Otros servicios que ofrecemos:</p>
                        <p style="margin-lef:40px">
                            <span style="margin-lef:10px">1. Asistencia Remota a través de Internet por horas.</span><br>
                            <span style="margin-lef:10px">2. Asistencia en Línea a través del teléfono o de un canal de Chat exclusivo.</span><br>
                            <span style="margin-lef:10px">3. Asistencia Presencial con diferentes planes por horas.</span><br>
                            <span style="margin-lef:10px">4. Capacitaciones en el uso de sistemas operativos y aplicativos como Office.</span><br>
                            <span style="margin-lef:10px">5. Implementación de Redes Informáticas de datos y de voz, Intranets y VPNs.</span><br>
                            <span style="margin-lef:10px">6. Implementación de sistemas de seguridad con cámaras y alarmas.</span><br>
                            <span style="margin-lef:10px">7. Asesores tecnológicos</span><br>
                            <span style="margin-lef:10px">8. Proveemos los mejores equipos tecnológicos para su empresa y hogar.</span><br>
                        </p>
                        <p>Le brindamos la mejor calidad en suministros y componentes informáticos.</p>
                    </div>
                        
                </div>
            </div>
        </div>
    </div>
</section>







<div class="call-out">
    <div class="container">
        <div class="float_left">
            <h4>OFRECEMOS  LA SOLUCION CORRECTA PARA SU NEGOCIO</h4>
        </div>
        <div class="float_right">
            <a href="/contacto.php" class="thm-btn">MÁS INFORMACIÓN </a>
        </div>
    </div>
</div>

<?php include('footer.php'); ?>

</div>
    
</body>
</html>