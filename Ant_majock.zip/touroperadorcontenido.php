<div class="col-md-9">
<div class="outer-box"><div class="section-title">
                                <h3>Tour Operador</h3>
                            </div>
                    <div class="text">
                        <p>La industria del turismo es una actividad muy importante para el desarrollo económico de los países, pueblos y ciudades. Es por ello que queremos dar a conocer cuáles son las herramientas necesarias para tener un buen manejo de su negocio. El tour operador ha estado en constante evolución desde el inicio del internet, lo cual ha abierto otros canales de distribución y venta, sirviendo como complemento para la optimización de la cadena de producción.</p>
                        <p>La adaptación a los nuevos cambios es una nueva tendencia que significa estar un paso adelante de lo que el cliente necesita. Es por ello que nuestros sistemas le van a permitir al Tour Operador ser más eficiente en la gestión administrativa comercial.</p><br><br>
                    </div>
                    <div class="section-title">
                        <h3>Beneficios</h3>
                    </div>
                    <div class="row">
                        <div class="col-md-7 col-sm-7 col-xs-12">
                            <div class="text">
                                <p>Los beneficios que proporciona nuestra solución podemos encontrar</p><br>
                            </div>
                            <ul class="benifit-list">
                                <li><i class="fa fa-angle-right"></i>Los beneficios que proporciona nuestra solución podemos encontra</li>
                                <li><i class="fa fa-angle-right"></i>Creación de Productos y Paquetes, Publicación, Ventas y Gestión de Expedientes, Bonos y Confirmaciones, Presupuestos, Facturación (electrónica opcional), Cobros, Chequeo y Recepción de Facturas de Proveedores, Pagos, Informes, Marketing.</li>                                <li><i class="fa fa-angle-right"></i>Control total de la cadena de produccion.</li>
                                <li><i class="fa fa-angle-right"></i>Control total de la cadena de producción.</li>
                                <li><i class="fa fa-angle-right"></i>Canal de venta on line a través del motor de reservas</li>
                                <li><i class="fa fa-angle-right"></i>Multi-idioma y multi-divisa.</li>
                                <li><i class="fa fa-angle-right"></i>Automatización de los precios de los contratos en base a porcentajes calculados como margen comercial o sobre costos.</li>
                             </ul>
                        </div>
                        <div class="col-md-5 col-sm-5 col-xs-12">
                            <div class="img-box"><a href="#"><img src="images/touroperador.jpg" alt=""></a></div>
                        </div>
                    </div><br><br>
                    <div class="section-title">
                        <h3>Está dirigido para: </h3>
                    </div>
                    <div class="row">
                        <div class="col-md-7 col-sm-7 col-xs-12">
                            <div class="accordion-box accordion-style-two">
                                <!--Start single accordion box-->
                                <div class="accordion animated out" data-delay="0" data-animation="fadeInUp">
                                    <div class="acc-btn active">
                                        <p class="title">Circuitos y excursiones</p>
                                        <div class="toggle-icon">
                                            <span class="plus fa fa-arrow-circle-o-right"></span><span class="minus fa fa-arrow-circle-o-right"></span>
                                        </div>
                                    </div>
                                    <div class="acc-content collapsed">
                                        <div class="text"><p>
                                            <ul>
                                                <li>Circuitos de autocar</li>
                                                <li>Bus lanzadera a destinos turísticos</li>
                                                <li>Excursiones radiales</li>
                                                <li>Liquidaciones a guías</li>
                                                <li>Productos combinados con multi-booking</li>
                                                <li>Doblaje automático de autocares</li>
                                                <li>Booking de plazas con la posibilidad de asignación de Asientos.</li>
                                            </ul>
                                        </p></div>
                                    </div>
                                </div>
                                <!--Start single accordion box-->
                                <div class="accordion animated out" data-delay="0" data-animation="fadeInUp">
                                    <div class="acc-btn">
                                        <p class="title">Alojamientos Hoteleros</p>
                                        <div class="toggle-icon">
                                            <i class="plus fa fa-arrow-circle-o-right"></i><i class="minus fa fa-arrow-circle-o-right"></i>
                                        </div>
                                    </div>
                                    <div class="acc-content">
                                        <div class="text"><p>
                                            <ul>
                                                <li>Los hoteleros pueden gestionar disponibilidad y precio diariamente</li>
                                                <li>Pago directo garantizado con tarjeta en plataforma segura OFIEDS</li>
                                                <li>Reserva anticipada, estancia mínima, suplementos, corta estancia, ...</li>
                                                <li>Contratos comerciales dirigidos a Agencias, Empresas y Colectivos con tarifas individuales</li>
                                                <li>Precios según parrilla para agilizar aplicación de precios por fechas con posibilidad de precio directo.</li>
                                            </ul>
                                        </p></div>
                                    </div>
                                </div>

                                <!--Start single accordion box-->
                                <div class="accordion animated out" data-delay="0" data-animation="fadeInUp">
                                    <div class="acc-btn">
                                        <p class="title">Visitas, entradas</p>
                                        <div class="toggle-icon">
                                            <i class="plus fa fa-arrow-circle-o-right"></i><i class="minus fa fa-arrow-circle-o-right"></i>
                                        </div>
                                    </div>
                                    <div class="acc-content">
                                        <div class="text"><p>
                                            <ul>
                                                <li>Visitas guiadas, Museos, Parques, Espectáculos</li>
                                                <li>Venta en plataforma web multi-tarifa</li>
                                                <li>Posibilidad de distintos horarios</li>
                                                <li>Idioma del cliente</li>
                                                <li>Módulo de venta rápida de productos turísticos (visitas guiadas) para oficinas de información turística,caso de asociaciones/empresas turísticas locales</li>
                                            </ul>
                                        </p></div>
                                    </div>
                                </div>

                                <!--Start single accordion box-->
                                <div class="accordion animated out" data-delay="0" data-animation="fadeInUp">
                                    <div class="acc-btn">
                                        <p class="title">Producto propio</p>
                                        <div class="toggle-icon">
                                            <i class="plus fa fa-arrow-circle-o-right"></i><i class="minus fa fa-arrow-circle-o-right"></i>
                                        </div>
                                    </div>
                                    <div class="acc-content">
                                        <div class="text"><p>
                                            <ul>
                                                <li>Si está especializado en un determinado destino y/o producto y quiere de forma cómoda ponerlo accesible a sus clientes en web, nuestra aplicación es la ideal para ello.</li>
                                            </ul>
                                        </p></div>
                                    </div>
                                </div>


                            </div>
                        </div>
                        <!--<div class="col-md-5 col-sm-5 col-xs-12">
                             <div class="text">
                                <p>Denouncing pleasure and praising pain was born and I will give you a complete account of the system no one rejects, dislikes, or avoids pleasure itself.</p><br>
                                <p>Expound the actually teachings of the great explorer of the truth, the master-builder of human happiness. No one rejects, dislikes, or avoids pleasure itself, because it is pleasure, but because those who do not know how to pursue pleasure rationally encounter consequences that are extremely painful.</p>
                            </div>
                        </div>-->
                    </div>
                    <br>

                </div>

</div>