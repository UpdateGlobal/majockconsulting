<div id="reservation">	
			<div id="reservation-container" class="primary-background img-rounded">
				<button class="close"><i class="fa fa-remove fa-lg"></i></button>
				<h2>Reservaciones</h2>
				<form method="post" action="reservaciones.php">
					<div class="row">
						<div class="form-group col-sm-6 has-feedback">
							<label for="reservation-arrival">Llegada</label>
							<input type="text" class="form-control" id="reservation-arrival" name="llegada" value="">
							<i class="fa fa-calendar form-control-feedback" aria-hidden="true"></i>
						</div>
						<div class="form-group col-sm-6 has-feedback">
							<label for="reservation-arrival">Salida</label>
							<input type="text" class="form-control" id="reservation-departure" name="salida" value="">
							<i class="fa fa-calendar form-control-feedback" aria-hidden="true"></i>
						</div>
					</div>
					<div class="row">
						<div class="form-group col-sm-6">
							<label for="reservation-adults">Adultos</label>
							<div class="input-group">
								<div class="input-group-addon quantity" data-multi="-1">-</div>
								<input type="text" name="adultos" class="form-control text-center" id="reservation-adults" value="1">
								<div class="input-group-addon quantity" data-multi="1">+</div>
							</div>
						</div>
						<div class="form-group col-sm-6">
							<label for="reservation-children">Niños</label>
							<div class="input-group">
								<div class="input-group-addon children-quantity" data-multi="-1">-</div>
								<input type="text" class="form-control text-center" name="ninos" id="reservation-children" value="0">
								<div class="input-group-addon children-quantity" data-multi="1">+</div>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-sm-12">
							<button type="submit" class="btn color3">Reservar</button>
						</div>
					</div>
				</form>
			</div>
		</div>