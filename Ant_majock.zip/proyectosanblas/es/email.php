<?php
/*if(isset($_POST['correo']))
{*/
 
	$subject = "Nuev Reserva";
	$body = "Tiene un nueva reserva para <strong>Hotel San Blas</strong>:
<br><br>
Check In: ".$_POST['llegada']."<br>
Check Out: ".$_POST['salida']."<br>
Tipo de Habitación: ".$_POST['tipo-habitacion']."<br>
Número de Habitaciones: ".$_POST['numero-habitacion']."<br>
Número de Adultos: ".$_POST['adultos']."<br>
Número de Niños: ".$_POST['ninos']."<br>
Tipo de Tarjeta de Crédito: ".$_POST['tipo-tarjeta']."<br>
Número de Tarjeta: ".$_POST['numero-tarjeta']."<br>
Número CCV: ".$_POST['ccv']."<br>
Nombre: ".$_POST['nombre']."<br>
Empresa: ".$_POST['empresa']."<br>
Teléfono: ".$_POST['telefono']."<br>
Dirección: ".$_POST['direccion']."<br>
Dirección 2: ".$_POST['direccion2']."<br>
Código Postal: ".$_POST['codigo-postal']."<br>
Ciudad: ".$_POST['ciudad']."<br>
País: ".$_POST['pais']."<br></br>";

//------Codigo para el envio del correo --------
$mailTo = "jason.m2710@gmail.com";
$headers = "To: SAN BLAS HOTEL <".$mailTo.">\r\n";
	$headers .= "From: ".$_POST['nombre']." <".$_POST['email'].">\r\n";
	$headers .= "Content-Type: text/html";
	$mail_success =  mail($mailTo, utf8_decode($subject), utf8_decode($body), $headers);	
	header("index.php");
//}       
?>  


