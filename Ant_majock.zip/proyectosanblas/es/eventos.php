<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
		<meta name="description" content="Hotel San Blas">
		<meta name="author" content="Jason Gonzales">
		<title>Eventos | HOTEL SAN BLAS, Siempre Brindándole lo Mejor | sanblashotel.com</title>
		<link rel="shortcut icon" href="images/favicon.png">

		<!-- Main Stylesheet -->
		<link href="css/style.css" rel="stylesheet">

		<!-- HTML5 shiv and Respond.js IE8 support of HTML5 elements and media queries -->
		<!--[if lt IE 9]>
		<script src="js/html5shiv.js"></script>
		<script src="js/respond.min.js"></script>
		<![endif]-->

	</head>
	<body>

		<!-- ============ LOADER START ============ -->

		<!-- <div id="loader">
			<i class="fa fa-cog fa-4x fa-spin primary-color"></i>
		</div> -->

		<!-- ============ LOADER END ============ -->

		<!-- ============ HEADER START ============ -->

		<header>
			<?php include("header.php"); ?>
			<?php include("nav.php"); ?>
		</header>
		<section id="content">
			<div class="container">
				<div class="row">
					<div class="col-sm-12 text-center">
						<h5>San Blas Hotel</h5>
						<h1>Servicios</h1>

						<div class="owl-carousel" id="hot-deals">
							
							<!-- Hot Deal 1 -->
							<div class="hot-deal">
								<img src="images/eventos.jpg" alt="" class="img-responsive" />
								<h4>Recepción de Bodas</h4>
								<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc eu lacus sed neque auctor cursus. Integer egestas quam non orci pharetra, vel accumsan ante tristique.</p>
								<p>
									
									<a href="reservas.html" class="btn btn-primary">Reservar</a>
								</p>
								<div class="price">Desde<span class="primary-color">S/. 299</span>por evento</div>
							</div>
							
							<!-- Hot Deal 2 -->
							<div class="hot-deal">
								<img src="images/eventos.jpg" alt="" class="img-responsive" />
								<h4>Reuniones de Negocio</h4>
								<p>Fusce eu convallis mauris, et ornare neque. Nulla cursus sit amet ex eu tempus. Etiam rhoncus tincidunt eleifend. Morbi quis iaculis arcu. Curabitur efficitur finibus.</p>
								<p>
									
									<a href="reservas.html" class="btn btn-primary">Reservar</a>
								</p>
								<div class="price">Desde<span class="primary-color">S/. 89</span>por persona</div>
							</div>
							<!-- Hot Deal 1 -->
							<div class="hot-deal">
								<img src="images/eventos.jpg" alt="" class="img-responsive" />
								<h4>Convenciones</h4>
								<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc eu lacus sed neque auctor cursus. Integer egestas quam non orci pharetra, vel accumsan ante tristique.</p>
								<p>
									
									<a href="reservas.html" class="btn btn-primary">Reservar</a>
								</p>
								<div class="price">Desde<span class="primary-color">S/. 299</span>por evento</div>
							</div>
							
							<!-- Hot Deal 2 -->
							<div class="hot-deal">
								<img src="images/eventos.jpg" alt="" class="img-responsive" />
								<h4>Conferencias</h4>
								<p>Fusce eu convallis mauris, et ornare neque. Nulla cursus sit amet ex eu tempus. Etiam rhoncus tincidunt eleifend. Morbi quis iaculis arcu. Curabitur efficitur finibus.</p>
								<p>
									
									<a href="reservas.html" class="btn btn-primary">Reservar</a>
								</p>
								<div class="price">Desde<span class="primary-color">S/. 89</span>por persona</div>
							</div>

						</div>

					</div>
				</div>
			</div>
		</section>
		<?php include("footer.php"); ?>
		<?php include("reserva-rapida.php"); ?>

		<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
		<script src="js/jquery-1.11.2.min.js"></script>

		<!-- Bootstrap Plugins -->
		<script src="js/bootstrap.min.js"></script>

		<!-- Retina Plugin -->
		<script src="js/retina.min.js"></script>

		<!-- Jetmenu Plugin -->
		<script src="js/jetmenu.js"></script>

		<!-- Superslides Plugin -->
		<script src="js/jquery.superslides.min.js"></script>

		<!-- Flat Weather Plugin -->
		<script src="js/jquery.flatWeatherPlugin.min.js"></script>

		<!-- Owl Carousel Plugin -->
		<script src="js/owl.carousel.min.js"></script>

		<!-- Datepicker Plugin -->
		<script src="js/bootstrap-datepicker.js"></script>

		<!-- Parallax Plugin -->
		<script src="js/parallax.js"></script>

		<!-- Fotorama Plugin -->
		<script src="js/fotorama.js"></script>

		<!-- Fancybox Plugin -->
		<script src="js/fancybox.pack.js"></script>

		<!-- Magic Form Processing -->
		<script src="js/magic.js"></script>

		<!-- jQuery Settings -->
		<script src="js/settings.js"></script>

	</body>
</html>