<footer>
			<div id="widgets">
				<div class="container">
					<div class="row">
						<div class="col-sm-3 widget">
							<h4>Contactenos</h4>
							<p>
								Hotel San Blas<br>
								Av. Arequipa 3940<br>
								Miraflores, Lima
							</p>
							<p>
								Telf: (511) 222 2601<br>
								Email: reservas@sanblashotel.com
							</p>
							<p>
								<a href="#">Contactar &nbsp; <i class="fa fa-angle-right"></i></a>
							</p>
						</div>
						
						<div class="col-sm-3 widget">
							<h4>HABITACIONES</h4>
							<nav>
								<ul>
									<li><a href="#"><i class="fa fa-angle-right primary-color"></i>Junior Suite</a></li>
									<li><a href="#"><i class="fa fa-angle-right primary-color"></i>Ejecutiva Simple</a></li>
									<li><a href="#"><i class="fa fa-angle-right primary-color"></i>Clásica Simple</a></li>
									<li><a href="#"><i class="fa fa-angle-right primary-color"></i>Ejecutiva Doble</a></li>
									<li><a href="#"><i class="fa fa-angle-right primary-color"></i>Clásica Doble</a></li>
								</ul>
							</nav>
						</div><div class="col-sm-3 widget">
							<h4>EVENTOS</h4>
							<nav>
								<ul>
									<li><a href="#"><i class="fa fa-angle-right primary-color"></i>Recepción de bodas</a></li>
									<li><a href="#"><i class="fa fa-angle-right primary-color"></i>Reuniones de negocio</a></li>
									<li><a href="#"><i class="fa fa-angle-right primary-color"></i>Convenciones</a></li>
									<li><a href="#"><i class="fa fa-angle-right primary-color"></i>Conferencias</a></li>
								</ul>
							</nav>
						</div>
						<div class="col-sm-3 widget">
							<h4>Recibe Nuestras Ofertas</h4>
							<form role="form" name="newsletter-form" id="newsletter-form" action="process-newsletter.php">
								<div class="form-group" id="newsletter-email-group">
									<label class="sr-only" for="newsletter-email">Email</label>
									<input type="email" class="form-control" id="newsletter-email" placeholder="Email">
								</div>
								<button type="submit" class="btn btn-primary">Suscribirme</button>
							</form>
						</div>
						
					</div>
				</div>
			</div>
			<div id="credits">
				<div class="container">
					<div class="row">
						<div class="col-sm-6">
							Hotel San Blas &copy; Todos los derechos reservados 2016
						</div>
						<div class="col-sm-2 text-right">
							<ul>
								<li><a href="#"><i class="fa fa-facebook fa-lg"></i></a></li>
								<li><a href="#"><i class="fa fa-twitter fa-lg"></i></a></li>
								<li><a href="#"><i class="fa fa-youtube fa-lg"></i></a></li>
								<li><a href="#"><i class="fa fa-google-plus fa-lg"></i></a></li>
								<li><a href="#"><i class="fa fa-skype fa-lg"></i></a></li>
							</ul>
						</div>
						<div class="col-sm-4 text-right">
							Powered by <a href="http://linkreativo.com/">Linkreativo</a>
						</div>
					</div>
				</div>
			</div>
		</footer>