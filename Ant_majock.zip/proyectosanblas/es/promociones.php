<?php
    // Consulta de Conexion
    require_once("Conexion.php");
    header('Content-type: text/html; charset=utf-8');

    $sql = "SELECT * FROM Promociones where idioma=1 AND act=1";
    $Promociones2 = mysqli_query($conexion,$sql);
?>


<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
		<meta name="description" content="Hotel San Blas">
		<meta name="author" content="Jason Gonzales">
		<title>Promociones | HOTEL SAN BLAS, Siempre Brindándole lo Mejor | sanblashotel.com</title>
		<link rel="shortcut icon" href="images/favicon.png">

		<!-- Main Stylesheet -->
		<link href="css/style.css" rel="stylesheet">

		<!-- HTML5 shiv and Respond.js IE8 support of HTML5 elements and media queries -->
		<!--[if lt IE 9]>
		<script src="js/html5shiv.js"></script>
		<script src="js/respond.min.js"></script>
		<![endif]-->

	</head>
	<body>

		<!-- ============ LOADER START ============ -->

		<!-- <div id="loader">
			<i class="fa fa-cog fa-4x fa-spin primary-color"></i>
		</div> -->

		<!-- ============ LOADER END ============ -->

		<!-- ============ HEADER START ============ -->

		<header>
			<?php include("header.php"); ?>
			<?php include("nav.php"); ?>
		</header>
		<section id="content">
			<div class="container">
				<div class="row">
					<div class="col-sm-12 text-center">	
						<h5>Nuestras</h5>
						<h1>Últimas Promociones</h1>

						<div class="owl-carousel" id="hot-deals">
							
							<?php while ($p=mysqli_fetch_array($Promociones2)) {  ?>

								<div class="hot-deal">
									<img src="../img/promociones/<?php echo $p['img']?>" alt="" class="img-responsive" />
									<h4> <?php echo $p['titulo'] ?> </h4>
									<p> <?php echo $p['detalles'] ?></p>
									<p>
										
										<a href="reservas.html" class="btn btn-primary">Reservar</a>
									</p>
									<div class="price">Desde<span class="primary-color">S/. <?php echo $p['precio']?></span>por habitación</div>
								</div>

							<?php } ?>

						</div>
					</div>
				</div>
			</div>
		</section>
		<?php include("footer.php"); ?>
		<?php include("reserva-rapida.php"); ?>

		<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
		<script src="js/jquery-1.11.2.min.js"></script>

		<!-- Bootstrap Plugins -->
		<script src="js/bootstrap.min.js"></script>

		<!-- Retina Plugin -->
		<script src="js/retina.min.js"></script>

		<!-- Jetmenu Plugin -->
		<script src="js/jetmenu.js"></script>

		<!-- Superslides Plugin -->
		<script src="js/jquery.superslides.min.js"></script>

		<!-- Flat Weather Plugin -->
		<script src="js/jquery.flatWeatherPlugin.min.js"></script>

		<!-- Owl Carousel Plugin -->
		<script src="js/owl.carousel.min.js"></script>

		<!-- Datepicker Plugin -->
		<script src="js/bootstrap-datepicker.js"></script>

		<!-- Parallax Plugin -->
		<script src="js/parallax.js"></script>

		<!-- Fotorama Plugin -->
		<script src="js/fotorama.js"></script>

		<!-- Fancybox Plugin -->
		<script src="js/fancybox.pack.js"></script>

		<!-- Magic Form Processing -->
		<script src="js/magic.js"></script>

		<!-- jQuery Settings -->
		<script src="js/settings.js"></script>

	</body>
</html>