<?php

    // Consulta de Conexion
    require_once("Conexion.php");
    header('Content-type: text/html; charset=utf-8');
    // GET SLIDER ESPAÑOL
    $sql = "SELECT * FROM Slider where idioma=1 AND act=1";
    $Slider= mysqli_query($conexion,$sql);

?>


<div id="slider">
	<ul class="slides-container">
		
	<?php while ($s=mysqli_fetch_array($Slider)) {  ?>

		<li>
			<img src="../img/slider/<?php echo $s['img']?>" alt="" />
			<div class="tint">
				<div class="content text-center">
					<h1><?php echo $s['titulo']?></h1>
					<h5><?php echo $s['frase']?></h5>
					<p><a href="<?php echo $s['link']?>" class="btn btn-primary">VER OFERTA</a></p>
				</div>
			</div>
		</li>

	<?php } ?>


	</ul>
	<nav class="slides-navigation">
		<a href="#" class="prev"><i class="fa fa-angle-left fa-2x"></i></a>
		<a href="#" class="next"><i class="fa fa-angle-right fa-2x"></i></a>
	</nav>
</div>