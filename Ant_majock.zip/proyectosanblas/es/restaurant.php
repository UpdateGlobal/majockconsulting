<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
		<meta name="description" content="Hotel San Blas">
		<meta name="author" content="Jason Gonzales">
		<title>Restaurant | HOTEL SAN BLAS, Siempre Brindándole lo Mejor | sanblashotel.com</title>
		<link rel="shortcut icon" href="images/favicon.png">

		<!-- Main Stylesheet -->
		<link href="css/style.css" rel="stylesheet">

		<!-- HTML5 shiv and Respond.js IE8 support of HTML5 elements and media queries -->
		<!--[if lt IE 9]>
		<script src="js/html5shiv.js"></script>
		<script src="js/respond.min.js"></script>
		<![endif]-->

	</head>
	<body>

		<!-- ============ LOADER START ============ -->

		<!-- <div id="loader">
			<i class="fa fa-cog fa-4x fa-spin primary-color"></i>
		</div> -->

		<!-- ============ LOADER END ============ -->

		<!-- ============ HEADER START ============ -->

		<header>
			<?php include("header.php"); ?>
			<?php include("nav.php"); ?>
		</header>
		<section id="content">
			<div class="container">
				<div class="row">
					<div class="col-sm-8">
						<h5>Restaurant</h5>
						<h1>Nuestro Restaurant</h1>

						<!-- Gallery Start -->
						<div class="fotorama" data-nav="thumbs" data-loop="true">
							<img src="images/restaurant-2.jpg" alt="" />
							<img src="images/cafeteria.jpg" alt="" />
							<img src="images/terraza.jpg" alt="" />
						</div>
						<!-- Gallery End -->

						
						<p>
							<a href="reservas.html" class="btn btn-primary">Reservar</a>
						</p>
					</div>
					<div class="col-sm-4">
						<h4>Servicios del Restasurant</h4>
						<ul class="amenities">
							<li>
								<span class="icon-fontic-hotel-wine pull-left"></span>
								<h6>Vinos</h6>
								<p>Las mejores cosechas</p>
							</li>
							<li>
								<span class="icon-fontic-hotel-restaurant pull-left"></span>
								<h6>Platos a la Carta</h6>
								<p>Con el toque de nuestro Cheff</p>
							</li>
							<li>
								<span class="icon-fontic-hotel-no-smoking pull-left"></span>
								<h6>Zona No-Fumador</h6>
								<p>Todos los ambientes son no-fumador</p>
							</li>
							<li>
								<span class="icon-fontic-hotel-music pull-left"></span>
								<h6>Música de Fondo</h6>
								<p>Sólo en la terraza</p>
							</li>
							<li>
								<span class="icon-fontic-hotel-meal pull-left"></span>
								<h6>Especialidad de la Casa</h6>
								<p>Platos para eventos</p>
							</li>
							<li>
								<span class="icon-fontic-hotel-hot-chocolate pull-left"></span>
								<h6>Infusiones</h6>
								<p>Bebidas calientes</p>
							</li>
							<li>
								<span class="icon-fontic-hotel-drink pull-left"></span>
								<h6>Tragos</h6>
								<p>Para acompañar sus comidas</p>
							</li>
							<li>
								<span class="icon-fontic-hotel-chicken pull-left"></span>
								<h6>Buffet</h6>
								<p>Los platos más exquisitos</p>
							</li>
							<li>
								<span class="icon-fontic-hotel-card pull-left"></span>
								<h6>Aceptamos Tarjetas</h6>
								<p>Visa, Mastercard</p>
							</li>
							<li>
								<span class="icon-fontic-hotel-toilet pull-left"></span>
								<h6>Servicios Higiénicos</h6>
								<p>Sin abandonar la terraza</p>
							</li>
						</ul>
					</div>
				</div>
			</div>
		</section>
		<?php include("footer.php"); ?>
		<?php include("reserva-rapida.php"); ?>

		<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
		<script src="js/jquery-1.11.2.min.js"></script>

		<!-- Bootstrap Plugins -->
		<script src="js/bootstrap.min.js"></script>

		<!-- Retina Plugin -->
		<script src="js/retina.min.js"></script>

		<!-- Jetmenu Plugin -->
		<script src="js/jetmenu.js"></script>

		<!-- Superslides Plugin -->
		<script src="js/jquery.superslides.min.js"></script>

		<!-- Flat Weather Plugin -->
		<script src="js/jquery.flatWeatherPlugin.min.js"></script>

		<!-- Owl Carousel Plugin -->
		<script src="js/owl.carousel.min.js"></script>

		<!-- Datepicker Plugin -->
		<script src="js/bootstrap-datepicker.js"></script>

		<!-- Parallax Plugin -->
		<script src="js/parallax.js"></script>

		<!-- Fotorama Plugin -->
		<script src="js/fotorama.js"></script>

		<!-- Fancybox Plugin -->
		<script src="js/fancybox.pack.js"></script>

		<!-- Magic Form Processing -->
		<script src="js/magic.js"></script>

		<!-- jQuery Settings -->
		<script src="js/settings.js"></script>

	</body>
</html>