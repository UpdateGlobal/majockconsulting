
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
		<meta name="description" content="Hotel San Blas">
		<meta name="author" content="Jason Gonzales - www.linkreativo.com">
		<title>HOTEL SAN BLAS | Siempre Brindándole lo Mejor | Alojamiento | Restaurant | Sala de eventos | sanblashotel.com</title>
		<link rel="shortcut icon" href="images/favicon.png">
		<!-- Main Stylesheet -->
		<link href="css/style.css" rel="stylesheet">
		<!-- HTML5 shiv and Respond.js IE8 support of HTML5 elements and media queries -->
		<!--[if lt IE 9]>
		<script src="js/html5shiv.js"></script>
		<script src="js/respond.min.js"></script>
		<![endif]-->

	</head>
	<body>
		<header>
			<?php include("header.php"); ?>
			<?php include("nav.php"); ?>
		</header>
		<?php include("slider.php"); ?>
		<section id="welcome" class="row color2 home-section">
			<div class="col-sm-7 col-md-6 col-lg-5 text">
				<div class="padding">
					<h5>Bienvenido al</h5>
					<h1>Hotel San Blas</h1>
					<p>El hotel fue fundado en el año 1998 por importantes empresarios de nuestra ciudad que sintieron la necesidad de ofrecer a los turistas nacionales y extranjeros un lugar cómodo y acogedor con un ambiente de familia, tarea en la cuál estamos inmersos.<br>
					

					<a href="nosotros.php">Ver más...</a></p>
				</div>
			</div>
			<div class="col-sm-5 col-md-6 col-lg-7 photo"></div>
		</section>
		<section id="rooms" class="row color3 home-section">
			<div class="col-sm-5 col-md-6 col-lg-7 photo"></div>
			<div class="col-sm-7 col-md-6 col-lg-5 text">
				<div class="padding">
					<h5>Conoce nuestros exclusivo</h5>
					<h1>Alojamiento</h1>
					<p>Contamos con 38 cómodas habitaciones para que usted pueda disfrutar su estancia: 22 habitaciones estándar simple, 12 habitaciones Superiores dobles, 4 habitaciones Junior Suite.<br><a href="habitaciones.php">Ver más...</a></p>
				</div>
			</div>
		</section>
		<section id="restaurant" class="row home-section">
			<div class="col-sm-7 col-md-6 col-lg-5 text">
				<div class="padding">
					<h5>Salas equipadas para</h5>
					<h1>Eventos</h1>
					<p>El hotel San Blas cuenta con 5 modernas y cómodas salas de eventos en las que podrá realizar cursos de capacitación, conferencia, reuniones y demás. Las salas se encuentran ubicadas en diferentes partes para que así usted pueda elegir la de su preferencia.<br><a href="eventos.php">Ver más...</a></p>
				</div></div>
			<div class="col-sm-5 col-md-6 col-lg-7 photo"></div>
		</section>
		<section id="spa" class="row color2 home-section">
			<div class="col-sm-5 col-md-6 col-lg-7 photo"></div>
			<div class="col-sm-7 col-md-6 col-lg-5 text">
				<div class="padding">
					<h5>Instalaciones para</h5>
					<h1>Recién Casados</h1>
					<p>El hotel San Blas ofrece un excelente lugar para poder disfrutar de una magnífica noche de bodas, la cual cuenta con jacuzzi y excelente vista de todo el esplendor de Miraflores.<br><a href="promociones.php">Ver más...</a></p>
				</div></div>
		</section>
		<section id="golf" class="row color3 home-section">
			<div class="col-sm-7 col-md-6 col-lg-5 text">
				<div class="padding">
					<h5>¿Cómo llegar?</h5>
					<h1>Ubica Nuestro Hotel</h1>
					<p>Estamos ubicados cerca en la mejor zona de Lima, rodeado de parques, zona comercial y empresarial.<br></p>
				</div></div>
			<div class="col-sm-5 col-md-6 col-lg-7 mapa"><iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d15604.418297109516!2d-77.0314789!3d-12.104993!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xba69d808591c2659!2sHotel+San+Blas!5e0!3m2!1ses!2spe!4v1464448857746" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe></div>
		</section>
		<section id="specials">
			<div class="container">
				<div class="row">
					<div class="col-sm-12 text-center">
						<h5>Echa un vistazo a nuestras</h5>
						<h1>Últimas Ofertas</h1>
						<div class="owl-carousel">
							<!-- OFERTA ITEM -->
							<div class="special-offer">
								<img src="images/desayuno.jpg" alt="" class="img-responsive" />
								<h4>Desayuno Buffet</h4>
								<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc eu lacus sed neque auctor cursus. Integer egestas quam non orci pharetra, vel accumsan ante tristique.</p>
								<p><a href="reservas.html" class="btn btn-primary">Reservar</a></p>
								<div class="price">
									desde <span class="primary-color">S/.95</span> soles
								</div>
							</div>
							<!-- OFERTA ITEM -->
							<div class="special-offer">
								<img src="images/desayuno.jpg" alt="" class="img-responsive" />
								<h4>Desayuno Buffet</h4>
								<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc eu lacus sed neque auctor cursus. Integer egestas quam non orci pharetra, vel accumsan ante tristique.</p>
								<p><a href="reservas.html" class="btn btn-primary">Reservar</a></p>
								<div class="price">
									desde <span class="primary-color">S/.95</span> soles
								</div>
							</div>
							<!-- OFERTA ITEM -->
							<div class="special-offer">
								<img src="images/desayuno.jpg" alt="" class="img-responsive" />
								<h4>Desayuno Buffet</h4>
								<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc eu lacus sed neque auctor cursus. Integer egestas quam non orci pharetra, vel accumsan ante tristique.</p>
								<p><a href="reservas.html" class="btn btn-primary">Reservar</a></p>
								<div class="price">
									desde <span class="primary-color">S/.95</span> soles
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>
		<?php include("footer.php"); ?>
		<?php include("reserva-rapida.php"); ?>

		<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
		<script src="js/jquery-1.11.2.min.js"></script>

		<!-- Bootstrap Plugins -->
		<script src="js/bootstrap.min.js"></script>

		<!-- Retina Plugin -->
		<script src="js/retina.min.js"></script>

		<!-- Jetmenu Plugin -->
		<script src="js/jetmenu.js"></script>

		<!-- Superslides Plugin -->
		<script src="js/jquery.superslides.min.js"></script>

		<!-- Flat Weather Plugin -->
		<script src="js/jquery.flatWeatherPlugin.min.js"></script>

		<!-- Owl Carousel Plugin -->
		<script src="js/owl.carousel.min.js"></script>

		<!-- Datepicker Plugin -->
		<script src="js/bootstrap-datepicker.js"></script>

		<!-- Parallax Plugin -->
		<script src="js/parallax.js"></script>

		<!-- Fancybox Plugin -->
		<script src="js/fancybox.pack.js"></script>

		<!-- Magic Form Processing -->
		<script src="js/magic.js"></script>

		<!-- jQuery Settings -->
		<script src="js/settings.js"></script>
		

	</body>
</html>