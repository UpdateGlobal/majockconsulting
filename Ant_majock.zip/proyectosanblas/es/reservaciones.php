<?php
$llegada = $_POST["llegada"];
$salida = $_POST["salida"];
$adultos = $_POST["adultos"];
$ninos = $_POST["ninos"];
?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
		<meta name="description" content="Hotel San Blas">
		<meta name="author" content="Jason Gonzales">
		<title>Restaurant | HOTEL SAN BLAS, Siempre Brindándole lo Mejor | sanblashotel.com</title>
		<link rel="shortcut icon" href="images/favicon.png">

		<!-- Main Stylesheet -->
		<link href="css/style.css" rel="stylesheet">

		<!-- HTML5 shiv and Respond.js IE8 support of HTML5 elements and media queries -->
		<!--[if lt IE 9]>
		<script src="js/html5shiv.js"></script>
		<script src="js/respond.min.js"></script>
		<![endif]-->

	</head>
	<body>

		<!-- ============ LOADER START ============ -->

		<!-- <div id="loader">
			<i class="fa fa-cog fa-4x fa-spin primary-color"></i>
		</div> -->

		<!-- ============ LOADER END ============ -->

		<!-- ============ HEADER START ============ -->

		<header>
			<?php include("header.php"); ?>
			<?php include("nav.php"); ?>
		</header>
		<section id="content">
			<div class="container">
				<div class="row">
					<div class="col-sm-12 text-center">
						<h5>Separa tu alojamiento</h5>
						<h1>Reservaciones</h1>
						<div class="alert alert-warning" role="alert"><strong>¡Importante!</strong><br>Procura llenar tus datos correctamente.</div>
					</div>
				</div>
				<form method="post" action="email.php">
					<h4>Detalles de la Reserva</h4>
					<div class="row">
						<div class="form-group has-feedback col-sm-6">
							<label for="booking-arrival">Check In</label>
							<input type="text" class="form-control" id="booking-arrival" value="<?php echo($llegada);?>">
							<i class="fa fa-calendar form-control-feedback" aria-hidden="true"></i>
						</div>
						<div class="form-group has-feedback col-sm-6">
							<label for="booking-departure">Check Out</label>
							<input type="text" class="form-control" id="booking-departure" value="<?php echo($salida);?>">
							<i class="fa fa-calendar form-control-feedback" aria-hidden="true"></i>
						</div>
					</div>
					<div class="row">
						<div class="col-sm-3">
							<div class="form-group">
								<label for="booking-type">Tipo de Habitación</label>
								<select class="form-control" id="booking-type">
									<option>Seleccionar</option>
									<option>Habitación Simple</option>
									<option>Ejecutiva Simple</option>
									<option>Clásica Doble</option>
									<option>Ejecutiva Doble</option>
									<option>Junior Suite</option>
								</select>
							</div>
						</div>
						<div class="col-sm-3">
							<div class="form-group">
								<label for="booking-rooms">No. de Habitaciones</label>
								<select class="form-control" id="booking-rooms">
									<option>Seleccionar</option>
									<option>1</option>
									<option>2</option>
									<option>3</option>
									<option>4</option>
								</select>
							</div>
						</div>
						<div class="col-sm-3">
							<div class="form-group">
								<label for="booking-adults">Adultos</label>
								<div class="input-group">
									<div class="input-group-addon children-quantity" data-multi="-1">-</div>
									<input type="text" class="form-control text-center" name="ninos" id="reservation-children" value="<?php echo($adultos);?>">
									<div class="input-group-addon children-quantity" data-multi="1">+</div>
								</div>
							</div>
						</div>
						<div class="col-sm-3">
							<div class="form-group">
								<label for="booking-children">Niños</label>
								<div class="input-group">
									<div class="input-group-addon children-quantity" data-multi="-1">-</div>
									<input type="text" class="form-control text-center" name="ninos" id="reservation-children" value="<?php echo($ninos);?>">
									<div class="input-group-addon children-quantity" data-multi="1">+</div>
								</div>
							</div>
						</div>
					</div>
					<hr>
					<h4>Detalle de Pago</h4>
					<div class="row">
						<div class="form-group col-sm-3">
							<label for="booking-card-type">Tipo de Tarjeta de Crédito</label>
							<select class="form-control" id="booking-card-type">
								<option>Escoger</option>
								<option>Visa</option>
								<option>Master Card</option>
								<option>Maestro</option>
								<option>American Express</option>
							</select>
						</div>
						<div class="form-group col-sm-6">
							<label for="booking-card-number">Número de Tarjeta de Crédito</label>
							<input type="text" class="form-control" id="booking-card-number">
						</div>
						<div class="form-group col-sm-3">
							<label for="booking-ccv">Número CCV</label>
							<input type="text" class="form-control" id="booking-ccv">
						</div>
					</div>
					<hr>
					<h4>Detalles Personales</h4>
					<div class="row">
						<div class="form-group col-sm-6">
							<label for="booking-name">Nombre y apellidos</label>
							<input type="text" class="form-control" id="booking-name">
						</div>
						<div class="form-group col-sm-6">
							<label for="booking-company">Nombre de la empresa (opcional)</label>
							<input type="text" class="form-control" id="booking-company">
						</div>
					</div>
					<div class="row">
						<div class="form-group col-sm-6">
							<label for="booking-email">Email</label>
							<input type="email" class="form-control" id="booking-email">
						</div>
						<div class="form-group col-sm-6">
							<label for="booking-phone">Teléfono</label>
							<input type="phone" class="form-control" id="booking-phone">
						</div>
					</div>
					<div class="row">
						<div class="form-group col-sm-6">
							<label for="booking-address1">Dirección</label>
							<input type="text" class="form-control" id="booking-address1">
						</div>
						<div class="form-group col-sm-6">
							<label for="booking-address2">Dirección 2 (opcional)</label>
							<input type="text" class="form-control" id="booking-address2">
						</div>
					</div>
					<div class="row">
						<div class="form-group col-sm-2">
							<label for="booking-zipcode">Código Postal</label>
							<input type="text" class="form-control" id="booking-zipcode">
						</div>
						<div class="form-group col-sm-4">
							<label for="booking-city">Ciudad</label>
							<input type="text" class="form-control" id="booking-city">
						</div>
						<div class="form-group col-sm-6">
							<label for="booking-country">País</label>
							<input type="text" class="form-control" id="booking-country">
						</div>
					</div>
					<hr>
					<div class="row">
						<div class="col-sm-12 text-center">
							<button type="submit" class="btn btn-primary">Reservar</button>
						</div>
					</div>
				</form>
			</div>
		</section>
		<?php include("footer.php"); ?>
		<?php include("reserva-rapida.php"); ?>

		<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
		<script src="js/jquery-1.11.2.min.js"></script>

		<!-- Bootstrap Plugins -->
		<script src="js/bootstrap.min.js"></script>

		<!-- Retina Plugin -->
		<script src="js/retina.min.js"></script>

		<!-- Jetmenu Plugin -->
		<script src="js/jetmenu.js"></script>

		<!-- Superslides Plugin -->
		<script src="js/jquery.superslides.min.js"></script>

		<!-- Flat Weather Plugin -->
		<script src="js/jquery.flatWeatherPlugin.min.js"></script>

		<!-- Owl Carousel Plugin -->
		<script src="js/owl.carousel.min.js"></script>

		<!-- Datepicker Plugin -->
		<script src="js/bootstrap-datepicker.js"></script>

		<!-- Parallax Plugin -->
		<script src="js/parallax.js"></script>

		<!-- Fotorama Plugin -->
		<script src="js/fotorama.js"></script>

		<!-- Fancybox Plugin -->
		<script src="js/fancybox.pack.js"></script>

		<!-- Magic Form Processing -->
		<script src="js/magic.js"></script>

		<!-- jQuery Settings -->
		<script src="js/settings.js"></script>

	</body>
</html>