<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
		<meta name="description" content="Hotel San Blas">
		<meta name="author" content="Jason Gonzales">
		<title>Clásica | HOTEL SAN BLAS, Siempre Brindándole lo Mejor | sanblashotel.com</title>
		<link rel="shortcut icon" href="images/favicon.png">

		<!-- Main Stylesheet -->
		<link href="css/style.css" rel="stylesheet">

		<!-- HTML5 shiv and Respond.js IE8 support of HTML5 elements and media queries -->
		<!--[if lt IE 9]>
		<script src="js/html5shiv.js"></script>
		<script src="js/respond.min.js"></script>
		<![endif]-->

	</head>
	<body>

		<!-- ============ LOADER START ============ -->

		<!-- <div id="loader">
			<i class="fa fa-cog fa-4x fa-spin primary-color"></i>
		</div> -->

		<!-- ============ LOADER END ============ -->

		<!-- ============ HEADER START ============ -->

		<header>
			<?php include("header.php"); ?>
			<?php include("nav.php"); ?>
		</header>
		<section id="content">
			<div class="container">
				<div class="row">
					<div class="col-sm-8">
						<h5>Habitaciones San Blas</h5>
						<h1>Clásica Simple</h1>

						<!-- Gallery Start -->
						<div class="fotorama" data-nav="thumbs" data-loop="true">
							<img src="images/clasica.jpg" alt="" />
							<img src="images/clasica.jpg" alt="" />
							<img src="images/clasica.jpg" alt="" />
						</div>
						<!-- Gallery End -->

						
						<p>
							<a href="reservas.html" class="btn btn-primary">Reservar</a>
							<a href="habitaciones.html" class="btn btn-default">Ver otras habitaciones</a>
						</p>
					</div>
					<div class="col-sm-4">
						<h4>Servicios de la Habitación</h4>
						<ul class="amenities">
							<li>
								<span class="icon-fontic-hotel-double-bed pull-left"></span>
								<h6>Cama Queen Size</h6>
								<p>Con el mejor colchón disponible</p>
							</li>
							<li>
								<span class="icon-fontic-hotel-refridgerator pull-left"></span>
								<h6>Frigobar</h6>
								<p>Sus bebidas siempre frescas</p>
							</li>
							<li>
								<span class="icon-fontic-hotel-snowflake pull-left"></span>
								<h6>Aire Acondicionado</h6>
								<p>Ambiente siempre fresco</p>
							</li>
							<li>
								<span class="icon-fontic-hotel-tv pull-left"></span>
								<h6>Entretenimiento</h6>
								<p>Incluye un Televisor LCD de 20"</p>
							</li>
							<li>
								<span class="icon-fontic-hotel-bathtube pull-left"></span>
								<h6>Ducha con bañera</h6>
								<p>Relájese y disfrute de un largo baño</p>
							</li>
							<li>
								<span class="icon-fontic-hotel-water pull-left"></span>
								<h6>Agua</h6>
								<p>Caliente y fría para su comodidad</p>
							</li>
							<li>
								<span class="icon-fontic-hotel-towel pull-left"></span>
								<h6>Closet</h6>
								<p>En todas las habitaciones</p>
							</li>
							<li>
								<span class="icon-fontic-hotel-restaurant pull-left"></span>
								<h6>Desayuno</h6>
								<p>Incluye un desayuno Buffet</p>
							</li>
							<li>
								<span class="icon-fontic-hotel-reception pull-left"></span>
								<h6>Servicio al cuarto</h6>
								<p>A su servicio hasta las 22:00 hrs</p>
							</li>
						</ul>
					</div>
				</div>
			</div>
		</section>
		<?php include("footer.php"); ?>
		<?php include("reserva-rapida.php"); ?>

		<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
		<script src="js/jquery-1.11.2.min.js"></script>

		<!-- Bootstrap Plugins -->
		<script src="js/bootstrap.min.js"></script>

		<!-- Retina Plugin -->
		<script src="js/retina.min.js"></script>

		<!-- Jetmenu Plugin -->
		<script src="js/jetmenu.js"></script>

		<!-- Superslides Plugin -->
		<script src="js/jquery.superslides.min.js"></script>

		<!-- Flat Weather Plugin -->
		<script src="js/jquery.flatWeatherPlugin.min.js"></script>

		<!-- Owl Carousel Plugin -->
		<script src="js/owl.carousel.min.js"></script>

		<!-- Datepicker Plugin -->
		<script src="js/bootstrap-datepicker.js"></script>

		<!-- Parallax Plugin -->
		<script src="js/parallax.js"></script>

		<!-- Fotorama Plugin -->
		<script src="js/fotorama.js"></script>

		<!-- Fancybox Plugin -->
		<script src="js/fancybox.pack.js"></script>

		<!-- Magic Form Processing -->
		<script src="js/magic.js"></script>

		<!-- jQuery Settings -->
		<script src="js/settings.js"></script>

	</body>
</html>