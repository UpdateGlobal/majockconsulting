 <?php
 session_start();
  
 if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true) {
  
 }
 else{
    
    header('Location: login.php');
    exit;
  }
?>

<!DOCTYPE html>
<html lang="es">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>GestorPro - Content Management System</title>
    <!-- Bootstrap -->
    <link href="estilos.css" rel="stylesheet">
    <link href="tabs.css" rel="stylesheet">
  </head>

  <body class="nav-md">
    <div class="container body">
      <div class="main_container">
        <?php include("panel-lateral.php"); ?>

        <!-- top navigation -->
        <?php include("menu-top.php"); ?>
        <!-- /top navigation -->
        <!-- CONTENIDO -->
        <div class="right_col" role="main" style="min-height:none !important">
           
          <div class="">
            <!-- <button id="uno" onlick="duplicar()" type="submit" class="btn btn-primary"><i class="fa fa-plus"></i></button> -->
            <div class="page-title">
              <div class="title_left">
                <h3>Administrar Usuarios
                </h3>
                <!-- <button id="uno" onlick="duplicar()" type="submit" class="btn btn-primary"><i class="fa fa-plus"></i></button> -->
              </div>
            </div>
            <div class="col-md-12">
              <div class="x_content">
                <div class="col-md-12">
                  <div class="col-md-2" style="padding-left:0px">
                    <div class="item form-group">
                      <div class="flecha">
                        <span style="float:left;"><h5>Seleccionar Usuario:</h5></span>
                        <select id="selec-user" class="select2_single form-control">
                          <option value="0" selected hidden inactive>Seleccionar</option>
                          <option value="1">Administrador</option>
                        </select>
                      </div>
                    </div>
                  </div>
                  <div class="col-md-2" style="padding-left:0px">
                    <div class="item form-group">
                      <div class="flecha">
                        <span id="label-accion-user" style="float:left;"><h5>Seleccionar acción:</h5></span>
                        <select id="accion-user" class="select2_single form-control">
                          <option value="0" selected hidden inactive>Acción</option>
                          <option value="1" disabled>Activar</option>
                          <option value="2" disabled>Desactivar</option>
                          <option value="3" disabled>Eliminar</option>
                          <option value="4">Editar</option>
                        </select>
                      </div>
                    </div>
                  </div>
                  <div id="editar-user">
                    <div class="col-md-2" style="padding-left:0px">
                      <div class="item form-group flecha">
                        <span style="float:left;"><h5>Correo electrónico:</h5></span>
                        <input type="email" name="email" class="form-control" placeholder="ejemplo@correo.com"/>
                        <br>
                      </div>
                  </div>
                  <div class="col-md-2" style="padding-left:0px">
                      <div class="item form-group flecha">
                        <span style="float:left;"><h5>Nombre de usuario:</h5></span>
                        <input type="text" id="username" name="username" class="form-control" placeholder="username"/>
                        <br>
                      </div>
                  </div>
                  <div class="col-md-2" style="padding-left:0px">
                      <div class="item form-group flecha">
                        <span style="float:left;"><h5>Nombres:</h5></span>
                        <input type="text" name="name" class="form-control" placeholder="Nombres"/>
                        <br>
                      </div>
                  </div>
                  <div class="col-md-2" style="padding-left:0px">
                      <div class="item form-group flecha">
                        <span style="float:left;"><h5>Apellidos:</h5></span>
                        <input type="text" name="lastname" class="form-control" placeholder="Apellidos"/>
                        <br>
                      </div>
                  </div>
                  <div class="col-md-2" style="padding-left:0px">
                      <div class="item form-group flecha">
                        <span style="float:left;"><h5>Contraseña:</h5></span>
                        <input type="password" name="password" class="form-control" placeholder="Nombre"/>
                        <br>
                      </div>
                  </div>
                  <div class="col-md-2" style="padding-left:0px">
                      <div class="item form-group flecha">
                        <span style="float:left;"><h5>Repetir Contraseña:</h5></span>
                        <input type="password" name="password-repeat" class="form-control" placeholder="Contraseña"/>
                        <br>
                      </div>
                  </div>
                  <div class="col-md-2">
                    <span style="float:left;"><h5>Foto de perfil <a href="#" data-toggle="modal" data-target="#myModal2"><sup><i class="fa fa-question-circle-o"></i></sup></a></h5></span>
                    <input id="upload1" type="file" readonly placeholder="No hay ningún archivo seleccionado" onchange="document.getElementById('blah').src = window.URL.createObjectURL(this.files[0])">
                    <label for="upload1">
                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="17" viewBox="0 0 20 17">
                            <path d="M10 0l-5.2 4.9h3.3v5.1h3.8v-5.1h3.3l-5.2-4.9zm9.3 11.5l-3.2-2.1h-2l3.4 2.6h-3.5c-.1 0-.2.1-.2.1l-.8 2.3h-6l-.8-2.2c-.1-.1-.1-.2-.2-.2h-3.6l3.4-2.6h-2l-3.2 2.1c-.4.3-.7 1-.6 1.5l.6 3.1c.1.5.7.9 1.2.9h16.3c.6 0 1.1-.4 1.3-.9l.6-3.1c.1-.5-.2-1.2-.7-1.5z"/>
                        </svg>
                        <span> Elegir foto&hellip;</span>
                    </label>
                  </div>
                  <div class="col-md-2">
                    <img id="blah" width="100%" height="auto"/>
                  </div>
                  </div>
                  
                  
                  
                 
                </div>
               
              </div>
            </div>
            <div class="col-md-12">

                  <div class="item form-group" style="margin-left: 10px;">
                  <br>
                  <button id="confirm" type="submit" onclick="confirmButton()" class="btn btn-primary float-l"><i class="fa fa-save"></i> Actualizar</button>  
                  </div>
                </div>
            <div class="clearfix"></div>
            <div class="row">
              
            </div>
          </div>

        </div>


       
       <?php include("creditos.php"); ?>
        <!-- CONTENIDO -->

        
      </div>
    </div>
    <div id="myModal2" class="modal fade" role="dialog">
      <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
          <div class="modal-header">
            <h2><i class="fa fa-flash"></i> GestorPro - SUGERENCIAS</h2>
            <button type="button" class="close" data-dismiss="modal">&times;</button>
          </div>
          <div class="modal-body">
            
            <div class="col-md-12">
             <h2>Añadir nueva imagen</h2>
             <p>Para un desempeño óptimo del slider, te recomendamos usar una imagen de <b>999px alto x 999px ancho</b> o superior (manteniendo la proporción) a una resolución de 72dpi. Para mayores dudas por favor consulte con su proveedor o escríbanos a gestorpro@linkreativo.com.</p>
            </div>
          </div>
          <div class="modal-footer">
            <br>
            <div class="col-md-12">
              <button type="submit" class="btn btn-guardarcambios" data-dismiss="modal">Aceptar</button>
            </div>
          </div>
        </div>
      </div>
    </div>
    <?php include("soporte.php"); ?>
    <!-- jQuery -->
    <script src="js/jquery.min.js"></script>
    <!-- Bootstrap -->
    <script src="js/bootstrap.min.js"></script>
    <!-- Bootstrap -->
     <!-- Custom Theme Scripts -->
    <script src="js/custom.min.js"></script>
    <!--x-Editable-->
    <script src="js/bootstrap-editable.min.js"></script>
    <script src="js/main.js"></script>
    <!-- WOW.js -->
    <script src="js/plugins.js"></script>
    <script src="js/scripts.js"></script>

    
    <script src="js/hematobank.js"></script>
    <script src="js/cbpFWTabs.js"></script>
    
    <script>
      (function() {

        [].slice.call( document.querySelectorAll( '.tabs' ) ).forEach( function( el ) {
          new CBPFWTabs( el );
        });

      })();
    </script>
    <script>
    document.getElementById('uno').onclick = duplicar;
    var i = 0;
    var primerbloque = document.getElementById('primerbloque');

    function duplicar() {
        var clone = primerbloque.cloneNode(true); // "deep" clone
        clone.id = "primerbloque" + ++i; // there can only be one element with an ID
        primerbloque.parentNode.appendChild(clone);
        primerbloque.style.display = "block";
    }
    </script>
   
    <!-- WOW.js -->
    <script src="js/wow.js"></script>
    
     <!-- PNotify -->
    <script src="js/pnotify.js"></script>
    <script src="js/pnotify.buttons.js"></script>
    <script src="js/pnotify.nonblock.js"></script>
    
    <!-- Scripts Varios -->
    <script type="text/javascript" src="js/script.js"></script>
    <script type="text/javascript" src="js/tabs.js"></script>

    
  </body>
</html>
