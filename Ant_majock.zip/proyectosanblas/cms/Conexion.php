<?php

	/*$host='localhost';
	$usuario='root';
	$password='grupocoril';
	$db = 'Hotel_Sanblas';
	$conexion = mysqli_connect($host, $usuario, $password, $db);
	*/
	/*$host='localhost';
	$usuario='root';
	$password='triacana';
	$db = 'Hotel_Atiq';
	$conexion = mysqli_connect($host, $usuario, $password, $db);
	*/
	$host='localhost';
	$usuario='san1148_Paul';
	$password='incuba2017';
	$db = 'san1148_Hotel_Sanblas';
	$conexion = mysqli_connect($host, $usuario, $password, $db);
	
?> 