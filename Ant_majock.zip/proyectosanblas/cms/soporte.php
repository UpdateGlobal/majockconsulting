<div id="myModal1" class="modal fade" role="dialog">
  <div class="modal-dialog">
    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <h2><i class="fa fa-flash"></i> GestorPro - SOPORTE</h2>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
      <div class="modal-body">
        
        <div class="col-md-12">
         <h2>Añadir nuevo ícono</h2>
         <p>Para un desempeño óptimo del slider, te recomendamos usar una imagen de <b>999px alto x 999px ancho</b> o superior (manteniendo la proporción) a una resolución de 72dpi. Para mayores dudas por favor consulte con su proveedor o escríbanos a gestorpro@linkreativo.com.</p>
         <div class="col-md-12">
          <div class="item form-group">
            <div class="flecha">
              <span style="float:left;"><h5>Descripción de la promoción:</h5></span>
              <textarea id="textarea" required="required" class="form-control" name="textarea" placeholder="Descripción de la habitación..."></textarea>
              <div id ="error4"></div>
            </div>
          </div>
        </div>
        </div>
      </div>
      <div class="modal-footer">
        <br>
        <div class="col-md-12">
          <button type="submit" class="btn btn-guardarcambios" data-dismiss="modal">Aceptar</button>
        </div>
      </div>
    </div>
  </div>
</div>