<footer>
<div class="center-margin wow fadeInLeft" style="text-align:center">
<p> <i class="fa fa-flash"></i> GestorPro &copy; Todos los derechos reservados 2017 - Desarrollado por <a href="#">Linkreativo</a> <!-- - Distribuido por <a href="#">Majock Consultores</a> --></p>
</div>
<div class="clearfix"></div>
</footer>