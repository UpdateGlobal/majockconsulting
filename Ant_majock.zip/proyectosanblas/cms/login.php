<!DOCTYPE html>
<html lang="es">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>GestorPro - Content Management System</title>
    <!-- Bootstrap -->
    <link href="css/login.css" rel="stylesheet">
    <link href="estilo-login.css" rel="stylesheet">
    <link rel="stylesheet" href="css/plugins.css">
  </head>

   <body >
    <div class="wrapper">
      <h1 class="wow fadeInLeft">
        <i class="fa fa-flash" style="color:#ef7120"></i> 
        <span style="color:#666">GestorPro <sup>&reg;</sup></span>
        <!-- <i class="fa fa-heartbeat" style="color:#ff2424"></i> 
      <span style="color:#5d5d5d">HematoBank</span> -->
      </h1>
      




      <form action="checklogin.php" method="post" class="login wow pulse">
        <p class="title">Acceso restringido</p>
        <input name="username" id="username" type="text" placeholder="Usuario" autofocus class="wow fadeIn"/>
        <i class="fa fa-user"></i>
        <input name="password" type="password" id="password" placeholder="Contraseña" class="wow fadeIn"/>
        <i class="fa fa-key"></i>
        <a href="#">No recuerdo mi contraseña</a>
        <button type="submit" name="Submit" class="wow fadeIn">
          <span class="state">Ingresar</span>
        </button>
      </form>
      


      <footer>
        <div class="center-margin wow fadeInLeft" style="text-align:center">
         <p> <i class="fa fa-flash"></i> GestorPro &copy; Todos los derechos reservados 2017 - Desarrollado por <a href="#">Linkreativo</a></p>
        </div>
        <div class="clearfix"></div>
      </footer>
    </div>
    <!-- jQuery -->
    <script src="js/jquery.min.js"></script>
    <!--<script src="js/login.js"></script>-->
    <!-- WOW.js -->
    <script src="js/plugins.js"></script>
    <script src="js/scripts.js"></script>
  </body>
</html>
