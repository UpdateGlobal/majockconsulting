<?php 
	require_once("../Conexion.php");
	
	header('Content-type: application/json; charset=utf-8');
	
	$funcion =  $_POST['funcion'];

	

	// --------------------------------------------------------------------------------------
    // ------------------- INSERT PROMOCION -------------------------------------------------
    // --------------------------------------------------------------------------------------

	if($funcion =="insert"){

		$idioma = $_POST['idioma'];
		$titulo = $_POST['titulo'];
		$precio = $_POST['precio'];
		$detalles = $_POST['detalles'];

		$temp = $_FILES['img']['tmp_name']; // tmp name (no se puede cambiar el nombre nos devuelve la ubicación temporal del archivo. 
		$name = $_FILES['img']['name']; // nombre original del archivo 
		$tamanoBytes = $_FILES['img']['size']; // En bytes 
		$tipoFile = $_FILES['img']['type'];
		$fecha=date("Y-m-d");

		if($tipoFile == "image/jpeg" || $tipoFile == "image/gif" || $tipoFile == "image/png"){ 

			// UPDATE BASE DE DATOS
			$sql="INSERT INTO Promociones VALUES (null,'$idioma','$titulo','$precio','$name','$detalles', '$fecha','1')";
			$Slider = mysqli_query($conexion,$sql);

			// GUARDAR ARCHIVO
			$ruta = "../../atiq8/img/promociones/";
			move_uploaded_file ($temp,"$ruta$name");
		}

		// REDIRECCIONO
		header('Location: ../tabla-promociones.php');

	}

	// --------------------------------------------------------------------------------------
    // ------------------- GET PROMOCION SLIDER POR IDIOMA-----------------------------------
    // --------------------------------------------------------------------------------------

	if($funcion =="getSelect"){

		$idioma = $_POST['idioma'];
		
		$sql="SELECT * FROM Promociones WHERE idioma='$idioma'";
		$Promos = mysqli_query($conexion,$sql);
		
		$idPromos="";
		$tituloPromos="";

		while ($promo=mysqli_fetch_array($Promos)) {
			
			if($idPromos==""){ 
				$idPromos = $promo['id'];
			}
			else{
				$idPromos=$idPromos.".".$promo['id'];
			}


			if($tituloPromos==""){ 
				$tituloPromos = $promo['titulo'];
			}
			else{
				$tituloPromos=$tituloPromos.".".$promo['titulo'];
			}

		}

		$resultado = array(
			'idPromos' => $idPromos,
			'tituloPromos' => $tituloPromos,
		);

		echo json_encode($resultado);
	}

	// --------------------------------------------------------------------------------------
    // ------------------- GET PROMOCION ----------------------------------------------------
    // --------------------------------------------------------------------------------------

	if($funcion =="get"){

		$idP = $_POST['idP'];

		$sql="SELECT * FROM Promociones WHERE id='$idP'";
		$Promo = mysqli_query($conexion,$sql);
		$promo = mysqli_fetch_array($Promo);

		$resultado = array(
			'img' => $promo['img'],
			'idP' => $idP,
			'titulo'=>$promo['titulo'],
			'detalles'=>$promo['detalles'],
			'precio'=>$promo['precio'],
		);

		echo json_encode($resultado);
	}

	// --------------------------------------------------------------------------------------
    // ------------------- UPDATE PROMOCION -------------------------------------------------
    // --------------------------------------------------------------------------------------

	if($funcion =="update"){

		$titulo = $_POST['titulo'];
		$precio = $_POST['precio'];
		$detalles = $_POST['detalles'];
		$idP = $_POST['idP'];
		$fecha=date("Y-m-d");

		$temp = $_FILES['imagen']['tmp_name']; // tmp name (no se puede cambiar el nombre nos devuelve la ubicación temporal del archivo. 
		$name = $_FILES['imagen']['name']; // nombre original del archivo 
		$tamanoBytes = $_FILES['imagen']['size']; // En bytes 
		$tipoFile = $_FILES['imagen']['type'];

		if($tipoFile == "image/jpeg" || $tipoFile == "image/gif" || $tipoFile == "image/png"){ 

			// UPDATE BASE DE DATOS
			$sql="UPDATE Promociones SET titulo='$titulo',precio='$precio',img='$name',detalles='$detalles',fecha='$fecha' WHERE id='$idP'";
			//$sql="UPDATE Promociones SET titulo='$titulo',precio='".$precio."' WHERE id='$idP'";
			$Slider = mysqli_query($conexion,$sql);

			// GUARDAR ARCHIVO
			$ruta = "../../atiq8/img/promociones/";
			move_uploaded_file ($temp,"$ruta$name");
		}

		// REDIRECCIONO
		header('Location: ../tabla-promociones.php');
	}

	// --------------------------------------------------------------------------------------
    // ------------------- ACTIVAR PROMOCION ------------------------------------------------
    // --------------------------------------------------------------------------------------

	if($funcion =="activar"){

		$idP = $_POST['idP'];

		$sql="UPDATE Promociones SET act='1' WHERE id='$idP'";
		$Slider = mysqli_query($conexion,$sql);

		$resultado = array(
			'msg' => "ok",
		);
		echo json_encode($resultado);
	}

	// --------------------------------------------------------------------------------------
    // ------------------- DESACTIVAR PROMOCION ---------------------------------------------
    // --------------------------------------------------------------------------------------

	if($funcion =="desactivar"){

		$idP = $_POST['idP'];

		$sql="UPDATE Promociones SET act='0' WHERE id='$idP'";
		$Slider = mysqli_query($conexion,$sql);

		$resultado = array(
			'msg' => "ok",
		);
		echo json_encode($resultado);
	}

	// --------------------------------------------------------------------------------------
    // ------------------- ELIMINAR PROMOCION------------------------------------------------
    // --------------------------------------------------------------------------------------

	if($funcion =="eliminar"){

		$idP = $_POST['idP'];

		$sql="DELETE FROM Promociones WHERE id='$idP'";
		$Slider = mysqli_query($conexion,$sql);

		$resultado = array(
			'msg' => "ok",
		);
		echo json_encode($resultado);
	}

?>