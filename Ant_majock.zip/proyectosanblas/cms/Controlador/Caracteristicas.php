<?php 
	require_once("../Conexion.php");
	
	header('Content-type: application/json; charset=utf-8');
	
	$funcion =  $_POST['funcion'];

	// --------------------------------------------------------------------------------------
    // ------------------- GET CARACTERISTICA ---------------------------------------------------
    // --------------------------------------------------------------------------------------


	if($funcion =="get"){

		$idC = $_POST['idC'];

		$sql="SELECT * FROM HabitacionesIncluye WHERE id='$idC'";
		$Promo = mysqli_query($conexion,$sql);
		$promo = mysqli_fetch_array($Promo);

		$resultado = array(
			'nombre' => $promo['nombre'],
			'nombreI' => $promo['nombreI'],
			'ico'=>$promo['ico'],
		);

		echo json_encode($resultado);
	}

	// --------------------------------------------------------------------------------------
    // ------------------- INSERT CARACTERISTICA -------------------------------------------------
    // --------------------------------------------------------------------------------------

	if($funcion =="insert"){

		$ico = $_POST['ico'];
		$nombre = $_POST['nombre'];
		$nombreI = $_POST['nombreI'];

		$sql="INSERT INTO HabitacionesIncluye VALUES (null,'$nombre','$nombreI','$ico')";
		$Slider = mysqli_query($conexion,$sql);

		header('Location: ../reg-room-carac.php');

	}



	// --------------------------------------------------------------------------------------
    // ------------------- UPDATE PROMOCION -------------------------------------------------
    // --------------------------------------------------------------------------------------

	if($funcion =="update"){

		$nombre = $_POST['nombre'];
		$nombreI = $_POST['nombreI'];
		$ico = $_POST['ico'];
		$idC = $_POST['idC'];

		// UPDATE BASE DE DATOS
		$sql="UPDATE HabitacionesIncluye SET nombre='$nombre',nombreI='$nombreI',ico='$ico' WHERE id='$idC'";
		$Slider = mysqli_query($conexion,$sql);

		$resultado = array(
			'txt' => "ok"
		);
		echo json_encode($resultado);

	}


	// --------------------------------------------------------------------------------------
    // ------------------- ELIMINAR PROMOCION------------------------------------------------
    // --------------------------------------------------------------------------------------

	if($funcion =="eliminar"){

		$idC = $_POST['idC'];

		$sql="DELETE FROM HabitacionesIncluye WHERE id='$idC'";
		$Slider = mysqli_query($conexion,$sql);

		$resultado = array(
			'msg' => "ok",
		);
		echo json_encode($resultado);
	}

?>