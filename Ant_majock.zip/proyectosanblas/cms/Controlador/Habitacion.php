<?php 
	require_once("../Conexion.php");
	
	header('Content-type: application/json; charset=utf-8');
	
	$funcion =  $_POST['funcion'];

	// --------------------------------------------------------------------------------------
    // ------------------- GET HABITACION ---------------------------------------------------
    // --------------------------------------------------------------------------------------

	if($funcion =="get"){

		$idH = $_POST['idH'];
		$Img="";
		$idImg="";
		
		$sql="select * from Habitaciones where id='$idH'";
		$Habitacion = mysqli_query($conexion,$sql);
		$Habitacion = mysqli_fetch_array($Habitacion);

		$sql="select * from HabitacionesImg where idH='$idH'";
		$ArrayImg = mysqli_query($conexion,$sql);
		
		while ($img=mysqli_fetch_array($ArrayImg)) {
			
			if($Img==""){
				$Img = $img['img'];
				$idImg =  $img['id'];
			}
			else{
				$Img = $Img."?".$img['img']; 
				$idImg = $idImg."?".$img['id']; 
			}
		}

		$resultado = array(
			'nombre' => $Habitacion['nombre'], 
			'precio' => $Habitacion['precio'],
			'detalles' => $Habitacion['detalles'], 
			'incluye' => $Habitacion['caracteristicas'],
			'img' => $Img,
			'idImg' => $idImg,
			'id' => $Habitacion['id']
			);

		echo json_encode($resultado);
	}


  // --------------------------------------------------------------------------------------
  // ------------------- UPDATE HABITACION ------------------------------------------------
  // --------------------------------------------------------------------------------------

  if($funcion =="update"){
  	
  	$numCheckbox =  $_POST['numCheckbox'];
  	$id = $_POST["id"];
  	$nombre = $_POST["nombre"];
  	$precio = $_POST["precio"];
  	$detalles = $_POST["detalles"];
  	$incluye ="";
  	
  	for($i=1; $i<=$numCheckbox; $i++){
  		
  		if( isset($_POST['myCheckbox'.$i]) ){
  			if ($incluye=="") { $incluye = $i; }
  			else { $incluye = $incluye.".".$i; }
  		}
  	}

	$sql="UPDATE Habitaciones SET nombre ='".$nombre."', precio ='".$precio."', detalles = '".$detalles."', caracteristicas = '".$incluye."' WHERE id='$id'  ";
	$res = mysqli_query($conexion,$sql);

  	$resultado = array(
		'msj' => "ok"
		);
  	echo json_encode($resultado);	
  }	


	// --------------------------------------------------------------------------------------
    // ------------------- ACTIVAR HABITACION------------------------------------------------
    // --------------------------------------------------------------------------------------

	if($funcion =="activar"){

		$idH = $_POST['idH'];

		$sql="UPDATE Habitaciones SET act='1' WHERE id='$idH'";
		$Slider = mysqli_query($conexion,$sql);

		$resultado = array(
			'msg' => "ok",
		);
		echo json_encode($resultado);
	}

	// --------------------------------------------------------------------------------------
    // ------------------- DESACTIVAR HABITACION --------------------------------------------
    // --------------------------------------------------------------------------------------

	if($funcion =="desactivar"){

		$idH = $_POST['idH'];

		$sql="UPDATE Habitaciones SET act='0' WHERE id='$idH'";
		$Slider = mysqli_query($conexion,$sql);

		$resultado = array(
			'msg' => "ok",
		);
		echo json_encode($resultado);
	}

	// --------------------------------------------------------------------------------------
    // ------------------- ELIMINAR HABITACION ----------------------------------------------
    // --------------------------------------------------------------------------------------

	if($funcion =="eliminar"){

		$idH = $_POST['idH'];

		$sql="DELETE FROM Habitaciones WHERE id='$idH'";
		$Slider = mysqli_query($conexion,$sql);

		$sql="DELETE FROM HabitacionesImg WHERE idH='$idH'";
		$Slider = mysqli_query($conexion,$sql);

		$resultado = array(
			'msg' => "ok",
		);
		echo json_encode($resultado);
	}

?>