<?php 
	require_once("../Conexion.php");
	
	header('Content-type: application/json; charset=utf-8');
	
	$funcion =  $_POST['funcion'];

	// --------------------------------------------------------------------------------------
    // ------------------- GET SELECT SLIDER POR IDIOMA--------------------------------------
    // --------------------------------------------------------------------------------------

	if($funcion =="getSelect"){

		$idioma = $_POST['idioma'];
		
		$sql="SELECT * FROM Slider WHERE idioma='$idioma'";
		$Slider = mysqli_query($conexion,$sql);
		$resultado = array();
		$idSlider="";

		while ($slider=mysqli_fetch_array($Slider)) {
			
			if($idSlider==""){ 
				$idSlider = $slider['id'];
			}
			else{
				$idSlider=$idSlider.".".$slider['id'];
			}

		}

		$resultado = array(
			'idSlider' => $idSlider
		);

		echo json_encode($resultado);
	}

	// --------------------------------------------------------------------------------------
    // ------------------- GET SLIDER -------------------------------------------------------
    // --------------------------------------------------------------------------------------

	if($funcion =="get"){

		$idS = $_POST['idS'];

		$sql="SELECT * FROM Slider WHERE id='$idS'";
		$Slider = mysqli_query($conexion,$sql);
		$slider=mysqli_fetch_array($Slider);

		$resultado = array(
			'img' => $slider['img'],
			'titulo' => $slider['titulo'],
			'frase' => $slider['frase'],
			'link' => $slider['link'],
			'idS' => $idS
		);

		echo json_encode($resultado);
	}

	// --------------------------------------------------------------------------------------
    // ------------------- UPDATE SLIDER ----------------------------------------------------
    // --------------------------------------------------------------------------------------

	if($funcion =="update"){

		$temp = $_FILES['imagen']['tmp_name']; // tmp name (no se puede cambiar el nombre nos devuelve la ubicación temporal del archivo. 
		$name = $_FILES['imagen']['name']; // nombre original del archivo 
		$tamanoBytes = $_FILES['imagen']['size']; // En bytes 
		$tipoFile = $_FILES['imagen']['type'];
		$idS = $_POST['idS'];
		$titulo = $_POST['titulo'];
		$frase = $_POST['frase'];
		$link = $_POST['link'];

		if($tipoFile == "image/jpeg" || $tipoFile == "image/gif" || $tipoFile == "image/png"){ 

			// UPDATE BASE DE DATOS
			$sql="UPDATE Slider SET img='$name',frase='$frase',titulo='$titulo',link='$link' WHERE id='$idS'";
			$Slider = mysqli_query($conexion,$sql);

			// GUARDAR ARCHIVO
			$ruta = "../../atiq8/img/slider/";
			move_uploaded_file ($temp,"$ruta$name");
		}else{
			$sql="UPDATE Slider SET frase='$frase',titulo='$titulo',link='$link' WHERE id='$idS'";
			$Slider = mysqli_query($conexion,$sql);
		}	

		// REDIRECCIONO
		header('Location: ../edit-banners.php');
	}

	// --------------------------------------------------------------------------------------
    // ------------------- ACTIVAR SLIDER ---------------------------------------------------
    // --------------------------------------------------------------------------------------

	if($funcion =="activar"){

		$idS = $_POST['idS'];

		$sql="UPDATE Slider SET act='1' WHERE id='$idS'";
		$Slider = mysqli_query($conexion,$sql);

		$resultado = array(
			'msg' => "ok",
		);
		echo json_encode($resultado);
	}

	// --------------------------------------------------------------------------------------
    // ------------------- DESACTIVAR SLIDER ------------------------------------------------
    // --------------------------------------------------------------------------------------

	if($funcion =="desactivar"){

		$idS = $_POST['idS'];

		$sql="UPDATE Slider SET act='0' WHERE id='$idS'";
		$Slider = mysqli_query($conexion,$sql);

		$resultado = array(
			'msg' => "ok",
		);
		echo json_encode($resultado);
	}

	// --------------------------------------------------------------------------------------
    // ------------------- ELIMINAR SLIDER --------------------------------------------------
    // --------------------------------------------------------------------------------------

	if($funcion =="eliminar"){

		$idS = $_POST['idS'];

		$sql="DELETE FROM Slider WHERE id='$idS'";
		$Slider = mysqli_query($conexion,$sql);

		$resultado = array(
			'msg' => "ok",
		);
		echo json_encode($resultado);
	}

?>