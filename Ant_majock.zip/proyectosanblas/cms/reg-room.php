 <?php
 session_start();
  
 if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true) {
  
 }
 else{
    
    header('Location: login.php');
    exit;
  }
?>

<!DOCTYPE html>
<html lang="es">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>GestorPro - Content Management System</title>
    <!-- Bootstrap -->
    <link href="estilos.css" rel="stylesheet">
    <link href="tabs.css" rel="stylesheet">
  </head>

  <body class="nav-md">
    <div class="container body">
      <div class="main_container">
        <?php include("panel-lateral.php"); ?>

        <!-- top navigation -->
        <?php include("menu-top.php"); ?>
        <!-- /top navigation -->
        <!-- CONTENIDO -->
        <div class="right_col" role="main" style="min-height:none !important">
           
          <div class="">
            
            <div class="page-title">
              <div class="title_left">
                <h3>Registrar Habitación
                </h3>
                <button id="uno" onlick="duplicar()" type="submit" class="btn btn-primary"><i class="fa fa-plus"></i></button>
              </div>
            </div>
            <div class="col-md-12">
              <div class="x_content">
                <div id="primerbloque" class="col-md-12">
                  <div class="col-md-2" style="padding-left:0px">
                    <div class="item form-group">
                      <div class="flecha">
                        <span style="float:left;"><h5>Seleccionar idioma del sitio:</h5></span>
                        <select class="select2_single form-control">
                          <option value="0" selected hidden inactive>Idioma</option>
                          <option value="Grupo Coril SAC">Sitio en Español</option>
                          <option value="Data System SAC">Sitio en Inglés</option>
                        </select>
                      </div>
                    </div>
                  </div>
                  <div class="col-md-2" style="padding-left:0px">
                    <div class="item form-group">
                      <div class="flecha">
                        <span style="float:left;"><h5>Tipo de habitación:</h5></span>
                        <select class="select2_single form-control">
                          <option value="0" selected hidden inactive>Seleccionar Tipo</option>
                          <option value="1">Junior Suite</option>
                          <option value="2">Clásica Simple</option>
                          <option value="3">Ejecutiva Simple</option>
                          <option value="4">Ejecutiva Doble</option>
                        </select>
                      </div>
                    </div>
                  </div>
                  
                  
                  <div class="col-md-2">
                    <span style="float:left;"><h5>Galería <a href="#" data-toggle="modal" data-target="#myModal2"><sup><i class="fa fa-question-circle-o"></i></sup></a></h5></span>
                    <input id="upload1" type="file" readonly placeholder="No hay ningún archivo seleccionado">
                    <label for="upload1">
                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="17" viewBox="0 0 20 17">
                            <path d="M10 0l-5.2 4.9h3.3v5.1h3.8v-5.1h3.3l-5.2-4.9zm9.3 11.5l-3.2-2.1h-2l3.4 2.6h-3.5c-.1 0-.2.1-.2.1l-.8 2.3h-6l-.8-2.2c-.1-.1-.1-.2-.2-.2h-3.6l3.4-2.6h-2l-3.2 2.1c-.4.3-.7 1-.6 1.5l.6 3.1c.1.5.7.9 1.2.9h16.3c.6 0 1.1-.4 1.3-.9l.6-3.1c.1-.5-.2-1.2-.7-1.5z"/>
                        </svg>
                        <span> Elegir imagen 1&hellip;</span>
                    </label>
                  </div>
                  <div class="col-md-2">
                    <span style="float:left;"><h5>Galería <a href="#" data-toggle="modal" data-target="#myModal2"><sup><i class="fa fa-question-circle-o"></i></sup></a></h5></span>
                    <input id="upload1" type="file" readonly placeholder="No hay ningún archivo seleccionado">
                    <label for="upload1">
                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="17" viewBox="0 0 20 17">
                            <path d="M10 0l-5.2 4.9h3.3v5.1h3.8v-5.1h3.3l-5.2-4.9zm9.3 11.5l-3.2-2.1h-2l3.4 2.6h-3.5c-.1 0-.2.1-.2.1l-.8 2.3h-6l-.8-2.2c-.1-.1-.1-.2-.2-.2h-3.6l3.4-2.6h-2l-3.2 2.1c-.4.3-.7 1-.6 1.5l.6 3.1c.1.5.7.9 1.2.9h16.3c.6 0 1.1-.4 1.3-.9l.6-3.1c.1-.5-.2-1.2-.7-1.5z"/>
                        </svg>
                        <span> Elegir imagen 2&hellip;</span>
                    </label>
                  </div>
                  <div class="col-md-2">
                    <span style="float:left;"><h5>Galería <a href="#" data-toggle="modal" data-target="#myModal2"><sup><i class="fa fa-question-circle-o"></i></sup></a></h5></span>
                    <input id="upload1" type="file" readonly placeholder="No hay ningún archivo seleccionado">
                    <label for="upload1">
                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="17" viewBox="0 0 20 17">
                            <path d="M10 0l-5.2 4.9h3.3v5.1h3.8v-5.1h3.3l-5.2-4.9zm9.3 11.5l-3.2-2.1h-2l3.4 2.6h-3.5c-.1 0-.2.1-.2.1l-.8 2.3h-6l-.8-2.2c-.1-.1-.1-.2-.2-.2h-3.6l3.4-2.6h-2l-3.2 2.1c-.4.3-.7 1-.6 1.5l.6 3.1c.1.5.7.9 1.2.9h16.3c.6 0 1.1-.4 1.3-.9l.6-3.1c.1-.5-.2-1.2-.7-1.5z"/>
                        </svg>
                        <span> Elegir imagen 3&hellip;</span>
                    </label>
                  </div>
                  <div class="col-md-12">
                      <ul>
                        <li>
                          <input type="checkbox" id="myCheckbox1" />
                          <label for="myCheckbox1">
                            <i class="fa fa-flash"></i>
                            <p>Cama Queen</p>
                          </label>
                        </li>
                        <li>
                          <input type="checkbox" id="myCheckbox1" />
                          <label for="myCheckbox1">
                            <i class="fa fa-flash"></i>
                            <p>Cama Dos Plazas</p>
                          </label>
                        </li>
                        <li>
                          <input type="checkbox" id="myCheckbox2" />
                          <label for="myCheckbox2">
                            <i class="fa fa-flash"></i>
                            <p>Cama Plaza 1/2</p>
                          </label>
                        </li>
                        <li>
                          <input type="checkbox" id="myCheckbox2" />
                          <label for="myCheckbox2">
                            <i class="fa fa-flash"></i>
                            <p>Cama Plaza 1/2</p>
                          </label>
                        </li>
                        <li>
                          <input type="checkbox" id="myCheckbox3" />
                          <label for="myCheckbox3">
                            <i class="fa fa-flash"></i>
                            <p>Cama King Size</p>
                          </label>
                        </li>
                        <li>
                          <input type="checkbox" id="myCheckbox4" />
                          <label for="myCheckbox4">
                            <i class="fa fa-flash"></i>
                            <p>Closet</p>
                          </label>
                        </li>
                      </ul>
                  </div>
                  
                 
                </div>
                
                
                
                
                

               
              </div>
            </div>
            <div class="col-md-12">

                  <div class="item form-group">
                  <br>
                  <button id="confirm" type="submit" onclick="confirmButton()" class="btn btn-primary float-l"><i class="fa fa-save"></i> REGISTRAR</button>  
                  </div>
                </div>
            <div class="clearfix"></div>
            <div class="row">
              
            </div>
          </div>

        </div>


       
       <?php include("creditos.php"); ?>
        <!-- CONTENIDO -->

        
      </div>
    </div>
    <div id="myModal2" class="modal fade" role="dialog">
      <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
          <div class="modal-header">
            <h2><i class="fa fa-flash"></i> GestorPro - SUGERENCIAS</h2>
            <button type="button" class="close" data-dismiss="modal">&times;</button>
          </div>
          <div class="modal-body">
            
            <div class="col-md-12">
             <h2>Añadir nueva imagen</h2>
             <p>Para un desempeño óptimo del slider, te recomendamos usar una imagen de <b>999px alto x 999px ancho</b> o superior (manteniendo la proporción) a una resolución de 72dpi. Para mayores dudas por favor consulte con su proveedor o escríbanos a gestorpro@linkreativo.com.</p>
            </div>
          </div>
          <div class="modal-footer">
            <br>
            <div class="col-md-12">
              <button type="submit" class="btn btn-guardarcambios" data-dismiss="modal">Aceptar</button>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- jQuery -->
    <script src="js/jquery.min.js"></script>
    <!-- Bootstrap -->
    <script src="js/bootstrap.min.js"></script>
    <!-- Bootstrap -->
     <!-- Custom Theme Scripts -->
    <script src="js/custom.min.js"></script>
    <!--x-Editable-->
    <script src="js/bootstrap-editable.min.js"></script>
    <script src="js/main.js"></script>
    <!-- WOW.js -->
    <script src="js/plugins.js"></script>
    <script src="js/scripts.js"></script>

    
    <script src="js/hematobank.js"></script>
    <script src="js/cbpFWTabs.js"></script>
    
    <script>
      (function() {

        [].slice.call( document.querySelectorAll( '.tabs' ) ).forEach( function( el ) {
          new CBPFWTabs( el );
        });

      })();
    </script>
    <script>
    document.getElementById('uno').onclick = duplicar;
    var i = 0;
    var primerbloque = document.getElementById('primerbloque');

    function duplicar() {
        var clone = primerbloque.cloneNode(true); // "deep" clone
        clone.id = "primerbloque" + ++i; // there can only be one element with an ID
        primerbloque.parentNode.appendChild(clone);
        primerbloque.style.display = "block";
    }
    </script>
   
    <!-- WOW.js -->
    <script src="js/wow.js"></script>
    
     <!-- PNotify -->
    <script src="js/pnotify.js"></script>
    <script src="js/pnotify.buttons.js"></script>
    <script src="js/pnotify.nonblock.js"></script>
    
    <!-- Scripts Varios -->
    <script type="text/javascript" src="js/script.js"></script>
    <script type="text/javascript" src="js/tabs.js"></script>

    
  </body>
</html>
