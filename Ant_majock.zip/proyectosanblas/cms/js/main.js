$(document).ready(function() {
    //toggle `popup` / `inline` mode
    $.fn.editable.defaults.mode = 'inline';     
    
    $('#moneda').editable({
        value: 2,    
        source: [
              {value: 1, text: 'Soles'},
              {value: 2, text: 'Dólares'}
           ]
    });
    //make username editable
    
    $('#apositivo1').editable({
            title: 'Enter username'
        });
    $('#anegativo1').editable({
            title: 'Enter username'
        });
    $('#a1positivo1').editable({
            title: 'Enter username'
        });
    $('#a1negativo1').editable({
            title: 'Enter username'
        });
    $('#bpositivo1').editable({
            title: 'Enter username'
        });
    $('#bnegativo1').editable({
            title: 'Enter username'
        });
    $('#opositivo1').editable({
            title: 'Enter username'
        });
    $('#onegativo1').editable({
            title: 'Enter username'
        });
    $('#abpositivo1').editable({
            title: 'Enter username'
        });
    $('#abnegativo1').editable({
            title: 'Enter username'
        });
    $('#apositivo2').editable({
            title: 'Enter username'
        });
    $('#anegativo2').editable({
            title: 'Enter username'
        });
    $('#a1positivo2').editable({
            title: 'Enter username'
        });
    $('#a1negativo2').editable({
            title: 'Enter username'
        });
    $('#bpositivo2').editable({
            title: 'Enter username'
        });
    $('#bnegativo2').editable({
            title: 'Enter username'
        });
    $('#opositivo2').editable({
            title: 'Enter username'
        });
    $('#onegativo2').editable({
            title: 'Enter username'
        });
    $('#abpositivo2').editable({
            title: 'Enter username'
        });
    $('#abnegativo2').editable({
            title: 'Enter username'
        });
    $('#apositivo3').editable({
            title: 'Enter username'
        });
    $('#anegativo3').editable({
            title: 'Enter username'
        });
    $('#a1positivo3').editable({
            title: 'Enter username'
        });
    $('#a1negativo3').editable({
            title: 'Enter username'
        });
    $('#bpositivo3').editable({
            title: 'Enter username'
        });
    $('#bnegativo3').editable({
            title: 'Enter username'
        });
    $('#opositivo3').editable({
            title: 'Enter username'
        });
    $('#onegativo3').editable({
            title: 'Enter username'
        });
    $('#abpositivo3').editable({
            title: 'Enter username'
        });
    $('#abnegativo3').editable({
            title: 'Enter username'
        });
    $('#apositivo4').editable({
            title: 'Enter username'
        });
    $('#anegativo4').editable({
            title: 'Enter username'
        });
    $('#a1positivo4').editable({
            title: 'Enter username'
        });
    $('#a1negativo4').editable({
            title: 'Enter username'
        });
    $('#bpositivo4').editable({
            title: 'Enter username'
        });
    $('#bnegativo4').editable({
            title: 'Enter username'
        });
    $('#opositivo4').editable({
            title: 'Enter username'
        });
    $('#onegativo4').editable({
            title: 'Enter username'
        });
    $('#abpositivo4').editable({
            title: 'Enter username'
        });
    $('#abnegativo4').editable({
            title: 'Enter username'
        });
    
    //make status editable
    $('#status').editable({
        type: 'select',
        title: 'Select status',
        placement: 'right',
        value: 2,
        source: [
            {value: 1, text: 'Registro 01'},
            {value: 2, text: 'Registro 02'},
            {value: 3, text: 'Registro 03'}
        ]
        /*
        //uncomment these lines to send data on server
        ,pk: 1
        ,url: '/post'
        */
    });
    $('#observaciones').editable({
        title: 'Observaciones'
    });
    $('#selector').editable({
        source: [
              {id: '0', text: 'Primera Opción'},
              {id: '1', text: 'Segunda Opción'},
              {id: '2', text: 'Tercera'}
           ],
        select2: {
           multiple: false,
           placeholder: 'Selecciona una opcion'
        }
    });
    $('#ereceptor').editable({
        select2: {
            placeholder: 'Empresa Receptora',
            allowClear: false,
            minimumInputLength: 3,
            id: function (item) {
                return item.EmpresaId;
            },
            ajax: {
                url: '/getEmpresas',
                dataType: 'json',
                data: function (term, page) {
                    return { query: term };
                },
                results: function (data, page) {
                    return { results: data };
                }
            },
            formatResult: function (item) {
                return item.EmpresaName;
            },
            formatSelection: function (item) {
                return item.EmpresaName;
            },
            initSelection: function (element, callback) {
                return $.get('/getEmpresas', { query: element.val() }, function (data) {
                    callback(data);
                });
            } 
        }  
    });
    $('#eemisor').editable({
        select2: {
            placeholder: 'Empresa Emisora',
            allowClear: true,
            minimumInputLength: 3,
            id: function (item) {
                return item.EmpresaId;
            },
            ajax: {
                url: '/getEmpresas',
                dataType: 'json',
                data: function (term, page) {
                    return { query: term };
                },
                results: function (data, page) {
                    return { results: data };
                }
            },
            formatResult: function (item) {
                return item.EmpresaName;
            },
            formatSelection: function (item) {
                return item.EmpresaName;
            },
            initSelection: function (element, callback) {
                return $.get('/getEmpresas', { query: element.val() }, function (data) {
                    callback(data);
                });
            } 
        }  
    });
    $('#documento').editable({
        select2: {
            placeholder: 'Tipo Documento',
            allowClear: true,
            minimumInputLength: 3,
            id: function (item) {
                return item.EmpresaId;
            },
            ajax: {
                url: '/getEmpresas',
                dataType: 'json',
                data: function (term, page) {
                    return { query: term };
                },
                results: function (data, page) {
                    return { results: data };
                }
            },
            formatResult: function (item) {
                return item.EmpresaName;
            },
            formatSelection: function (item) {
                return item.EmpresaName;
            },
            initSelection: function (element, callback) {
                return $.get('/getEmpresas', { query: element.val() }, function (data) {
                    callback(data);
                });
            } 
        }  
    });
    $('#femision').editable({
        format: 'yyyy-mm-dd',    
        viewformat: 'dd/mm/yyyy',    
        datepicker: {
                weekStart: 1
           }
        });
   $('#ndoc').editable({
        url: '/post',
        title: 'N° Documento',
    });

    

});



