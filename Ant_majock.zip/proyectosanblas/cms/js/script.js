
$(document).ready(function() {
  $(":input").inputmask();
});

$("#idioma").change(function () {
    var selected_option = $('#idioma').val();
    if (selected_option === '1') {
        $('#banner').fadeIn("slow");
        $('#label-banner').fadeIn("slow");
        $('#tabla-es').fadeIn("slow");
        $('#tabla-en').fadeOut("slow");

    }
    if (selected_option === '2') {
        $('#banner').fadeIn("slow");
        $('#label-banner').fadeIn("slow");
        $('#tabla-es').fadeOut("slow");
        $('#tabla-en').fadeIn("slow");
    }
})

$("#idioma-room").change(function () {
    var selected_option = $('#idioma-promo').val();
    {
        $('#selec-room').fadeIn("slow");
        $('#label-selec-room').fadeIn("slow");
    }
})
$("#idioma-admin-carac").change(function () {
    var selected_option = $('#idioma-admin-carac').val();
    {
        $('#label-caracteristica').fadeIn("slow");
        $('#caracteristica').fadeIn("slow");
    }
})
$("#caracteristica").change(function () {
    var selected_option = $('#caracteristica').val();
    {
        $('#label-accion-admin-carac').fadeIn("slow");
        $('#accion-admin-carac').fadeIn("slow");
    }
})
$("#accion-admin-carac").change(function () {
    var selected_option = $('#accion-admin-carac').val();
    if (selected_option === '4') {
        $('#editar-admin-carac').fadeIn("slow");
    }
    else{
      $('#editar-admin-carac').fadeOut("slow");
    }
})

$("#selec-room").change(function () {
    var selected_option = $('#selec-room').val();
    {
        $('#accion-room').fadeIn("slow");
        $('#label-accion-room').fadeIn("slow");
    }
})
$("#selec-user").change(function () {
    var selected_option = $('#selec-user').val();
    {
        $('#accion-user').fadeIn("slow");
        $('#label-accion-user').fadeIn("slow");
    }
})
$("#accion-user").change(function () {
    var selected_option = $('#accion-user').val();
    if (selected_option === '4') {
        $('#editar-user').fadeIn("slow");
    }
    else{
      $('#editar-user').fadeOut("slow");
    }
})
$("#accion-room").change(function () {
    var selected_option = $('#accion-room').val();
    if (selected_option === '4') {
        $('#editar-room').fadeIn("slow");
    }
    else{
      $('#editar-room').fadeOut("slow");
    }
})
$("#idioma-promo").change(function () {
    var selected_option = $('#idioma-promo').val();
    if (selected_option === '1') {
        $('#promo').fadeIn("slow");
        $('#label-promo').fadeIn("slow");
    }
    if (selected_option === '2') {
        $('#promo').fadeIn("slow");
        $('#label-promo').fadeIn("slow");
    }
})

$("#promo").change(function () {
    var selected_option = $('#promo').val();
    {
        $('#accion-promo').fadeIn("slow");
        $('#label-accion-promo').fadeIn("slow");
    }
})

$("#accion-promo").change(function () {
    var selected_option = $('#accion-promo').val();
    if (selected_option === '4') {
        $('#edit-promo').fadeIn("slow");
    }
    else{
      $('#edit-promo').fadeOut("slow");
    }
})

$("#banner").change(function () {
    var selected_option = $('#banner').val();
    {
        $('#accion-banner').fadeIn("slow");
        $('#label-accion').fadeIn("slow");
    }
})
$("#accion-banner").change(function () {
    var selected_option = $('#accion-banner').val();
    if (selected_option === '4') {
        $('#edit-banner').fadeIn("slow");
    }
    else {
        $('#edit-banner').fadeOut("slow");
    }
})

function copyToClipboard(element) {
  var $temp = $("<a>");
  $("body").append($temp);
  $temp.val($(element).text()).select();
  document.execCommand("copy");
  $temp.remove();
}




    $("#rango").change(function () {
    var selected_option = $('#rango').val();
    if (selected_option === '1') {
        $('#fecha').fadeIn("slow");
        $('#hora').fadeIn("slow");
        $('#mes').hide();
        $('#ano').hide();
        $('#boton').fadeIn("slow");
    }
    if (selected_option === '2') {
        $('#fecha').fadeIn("slow");
        $('#hora').hide();
        $('#mes').hide();
        $('#ano').hide();
        $('#boton').fadeIn("slow");
    }
    if (selected_option === '3') {
        $('#fecha').fadeIn();
        $('#hora').hide();
        $('#mes').hide();
        $('#ano').hide();
        $('#boton').fadeIn("slow");
    }
    if (selected_option === '4') {
        $('#fecha').hide();
        $('#hora').hide();
        $('#mes').fadeIn("slow");
        $('#ano').hide();
        $('#boton').fadeIn("slow");
    }
    if (selected_option === '5') {
        $('#fecha').hide();
        $('#hora').hide();
        $('#mes').hide();
        $('#ano').fadeIn("slow");
        $('#boton').fadeIn("slow");
    }
})



function Mostrar(id) {
          if (id == "1") {
              $("#1").show();
              $("#2").hide();
              $("#3").hide();
              return false;
          }
           if (id == "2") {
              $("#1").hide();
              $("#2").show();
              $("#3").hide();
          }
          if (id == "3") {
              $("#1").hide();
              $("#2").hide();
              $("#3").show();
          }
      }

function Mostrar(id) {
          if (id == "1") {
              $("#1").show();
              $("#2").hide();
              $("#3").hide();
              return false;
          }
           if (id == "2") {
              $("#1").hide();
              $("#2").show();
              $("#3").hide();
          }
          if (id == "3") {
              $("#1").hide();
              $("#2").hide();
              $("#3").show();
          }
      }

function ver(id) {
          if (id == "mensual") {
              $("#mensual").show();
              $("#anual").hide();
              $("#unselect").hide();
          }
           if (id == "anual") {
              $("#mensual").hide();
              $("#anual").show();
              $("#unselect").hide();
          }
          if (id == "0") {
              $("#mensual").hide();
              $("#anual").hide();
              $("#unselect").show();
          }
      }

/*$(document).ready(function(){ //Make script DOM ready
    $('#tipopago').change(function() { //jQuery Change Function
        var opval = $(this).val(); //Get value from select element
        if(opval=="mensual"){ //Compare it and if true
            $('#myModal').modal("show"); //Open Modal
        }
    });
});*/

//Appear Disappear Divs
   
      function mostrar(id) {
          if (id == "factura") {
              $("#factura").show();
              $("#facturaelectronica").hide();
              $("#boleta").hide();
              $("#recibo").hide();
              $("#guiaremision").hide();
              $("#recibohonorarios").hide();
              $("#recibohonorarioselectronico").hide();
              $("#notacredito").hide();
              $("#comprobantepago").hide();
              $("#notadebito").hide();
          }
           if (id == "facturaelectronica") {
              $("#factura").hide();
              $("#facturaelectronica").show();
              $("#boleta").hide();
              $("#recibo").hide();
              $("#guiaremision").hide();
              $("#recibohonorarios").hide();
              $("#recibohonorarioselectronico").hide();
              $("#notacredito").hide();
              $("#comprobantepago").hide();
              $("#notadebito").hide();
          }
           if (id == "boleta") {
              $("#factura").hide();
              $("#facturaelectronica").hide();
              $("#boleta").show();
              $("#recibo").hide();
              $("#guiaremision").hide();
              $("#recibohonorarios").hide();
              $("#recibohonorarioselectronico").hide();
              $("#notacredito").hide();
              $("#comprobantepago").hide();
              $("#notadebito").hide();
          }
           if (id == "recibo") {
              $("#factura").hide();
              $("#facturaelectronica").hide();
              $("#boleta").hide();
              $("#recibo").show();
              $("#guiaremision").hide();
              $("#recibohonorarios").hide();
              $("#recibohonorarioselectronico").hide();
              $("#notacredito").hide();
              $("#comprobantepago").hide();
              $("#notadebito").hide();
          }
           if (id == "guiaremision") {
              $("#factura").hide();
              $("#facturaelectronica").hide();
              $("#boleta").hide();
              $("#recibo").hide();
              $("#guiaremision").show();
              $("#recibohonorarios").hide();
              $("#recibohonorarioselectronico").hide();
              $("#notacredito").hide();
              $("#comprobantepago").hide();
              $("#notadebito").hide();
          }
           if (id == "recibohonorarios") {
              $("#factura").hide();
              $("#facturaelectronica").hide();
              $("#boleta").hide();
              $("#recibo").hide();
              $("#guiaremision").hide();
              $("#recibohonorarios").show();
              $("#recibohonorarioselectronico").hide();
              $("#notacredito").hide();
              $("#comprobantepago").hide();
              $("#notadebito").hide();
          }
           if (id == "recibohonorarioselectronico") {
              $("#factura").hide();
              $("#facturaelectronica").hide();
              $("#boleta").hide();
              $("#recibo").hide();
              $("#guiaremision").hide();
              $("#recibohonorarios").hide();
              $("#recibohonorarioselectronico").show();
              $("#notacredito").hide();
              $("#comprobantepago").hide();
              $("#notadebito").hide();
          }
           if (id == "notacredito") {
              $("#factura").hide();
              $("#facturaelectronica").hide();
              $("#boleta").hide();
              $("#recibo").hide();
              $("#guiaremision").hide();
              $("#recibohonorarios").hide();
              $("#recibohonorarioselectronico").hide();
              $("#notacredito").show();
              $("#comprobantepago").hide();
              $("#notadebito").hide();
          }
           if (id == "comprobantepago") {
              $("#factura").hide();
              $("#facturaelectronica").hide();
              $("#boleta").hide();
              $("#recibo").hide();
              $("#guiaremision").hide();
              $("#recibohonorarios").hide();
              $("#recibohonorarioselectronico").hide();
              $("#notacredito").hide();
              $("#comprobantepago").show();
              $("#notadebito").hide();
          }
           if (id == "notadebito") {
              $("#factura").hide();
              $("#facturaelectronica").hide();
              $("#boleta").hide();
              $("#recibo").hide();
              $("#guiaremision").hide();
              $("#recibohonorarios").hide();
              $("#recibohonorarioselectronico").hide();
              $("#notacredito").hide();
              $("#comprobantepago").hide();
              $("#notadebito").show();
          }
      }

//    <!-- Autocomplete Inputs -->

      function cargar_al_input(valor) {
        var txt = document.getElementById("RUCemisor");

        switch(valor)
        {
        case 'Grupo Coril SAC':
        codigo= '204080100';
        break;
        case 'Data System SAC':
        codigo= '204080200';
        break;
        case 'Incuba SAC':
        codigo= '204080300';
        break;
        case 'Empresa SRL':
        codigo= '204080400';
        }
        txt.value = codigo;
        var txt = document.getElementById("RUCreceptor");

        switch(valor)
        {
        case 'Grupo Coril SAC':
        codigo= '206080900';
        break;
        case 'Data System SAC':
        codigo= '205080700';
        break;
        case 'Incuba SAC':
        codigo= '203080500';
        break;
        case 'Empresa SRL':
        codigo= '201080200';
        }
        txt.value = codigo;
        var txt = document.getElementById("RSemisor");

        switch(valor)
       {
        case 'Grupo Coril SAC':
        codigo= 'Grupo Coril Agente de Bolsa SA';
        break;
        case 'Data System SAC':
        codigo= 'Data System SAC';
        break;
        case 'Incuba SAC':
        codigo= 'Incuba SAC';
        break;
        case 'Empresa SRL':
        codigo= 'Empresa SRL';
        }
        txt.value = codigo;
        var txt = document.getElementById("RSreceptor");

        switch(valor)
       {
        case 'Grupo Coril SAC':
        codigo= 'Proveedor Inversiones Perú SAC';
        break;
        case 'Data System SAC':
        codigo= 'Proveedor 02 SAC';
        break;
        case 'Incuba SAC':
        codigo= 'Proveedor 03 SAC';
        break;
        case 'Empresa SRL':
        codigo= 'Proveedor 04 SAC';
        }
        txt.value = codigo;
        var txt = document.getElementById("DFemisor");

        switch(valor)
       {
        case 'Grupo Coril SAC':
        codigo= 'Calle Monte Rosa 256 - Chacarilla - Surco';
        break;
        case 'Data System SAC':
        codigo= 'Calle Monte Rosa 256 - Chacarilla - Surco - Of. 1001';
        break;
        case 'Incuba SAC':
        codigo= 'Calle Los Laureles 3234 - Jesús María';
        break;
        case 'Empresa SRL':
        codigo= 'Avenid Miguel Grau 2034 - Barranco';
        }
        txt.value = codigo;
        var txt = document.getElementById("DFreceptor");

        switch(valor)
       {
        case 'Grupo Coril SAC':
        codigo= 'Jirón Lambayeque 3404 - Lima';
        break;
        case 'Data System SAC':
        codigo= 'Jirón Toquepala 508 - Breña';
        break;
        case 'Incuba SAC':
        codigo= 'Avenida Los Libertadores 5600 - Los Olivos';
        break;
        case 'Empresa SRL':
        codigo= 'Calle Los Embajadores 4560 - Ate Vitare';
        }
        txt.value = codigo;
        var txt = document.getElementById("RUCemisor1");

        switch(valor)
        {
        case 'Grupo Coril SAC':
        codigo= '204080100';
        break;
        case 'Data System SAC':
        codigo= '204080200';
        break;
        case 'Incuba SAC':
        codigo= '204080300';
        break;
        case 'Empresa SRL':
        codigo= '204080400';
        }
        txt.value = codigo;
        var txt = document.getElementById("RUCreceptor1");

        switch(valor)
        {
        case 'Grupo Coril SAC':
        codigo= '206080900';
        break;
        case 'Data System SAC':
        codigo= '205080700';
        break;
        case 'Incuba SAC':
        codigo= '203080500';
        break;
        case 'Empresa SRL':
        codigo= '201080200';
        }
        txt.value = codigo;
        var txt = document.getElementById("RSemisor1");

        switch(valor)
       {
        case 'Grupo Coril SAC':
        codigo= 'Grupo Coril SAC';
        break;
        case 'Data System SAC':
        codigo= 'Data System SAC';
        break;
        case 'Incuba SAC':
        codigo= 'Incuba SAC';
        break;
        case 'Empresa SRL':
        codigo= 'Empresa SRL';
        }
        txt.value = codigo;
        var txt = document.getElementById("RSreceptor1");

        switch(valor)
       {
        case 'Grupo Coril SAC':
        codigo= 'Proveedor 01 SAC';
        break;
        case 'Data System SAC':
        codigo= 'Proveedor 02 SAC';
        break;
        case 'Incuba SAC':
        codigo= 'Proveedor 03 SAC';
        break;
        case 'Empresa SRL':
        codigo= 'Proveedor 04 SAC';
        }
        txt.value = codigo;
        var txt = document.getElementById("DFemisor1");

        switch(valor)
       {
        case 'Grupo Coril SAC':
        codigo= 'Calle Monte Rosa 256 - Chacarilla - Surco';
        break;
        case 'Data System SAC':
        codigo= 'Calle Monte Rosa 256 - Chacarilla - Surco - Of. 1001';
        break;
        case 'Incuba SAC':
        codigo= 'Calle Los Laureles 3234 - Jesús María';
        break;
        case 'Empresa SRL':
        codigo= 'Avenid Miguel Grau 2034 - Barranco';
        }
        txt.value = codigo;
        var txt = document.getElementById("DFreceptor1");

        switch(valor)
       {
        case 'Grupo Coril SAC':
        codigo= 'Jirón Lambayeque 3404 - Lima';
        break;
        case 'Data System SAC':
        codigo= 'Jirón Toquepala 508 - Breña';
        break;
        case 'Incuba SAC':
        codigo= 'Avenida Los Libertadores 5600 - Los Olivos';
        break;
        case 'Empresa SRL':
        codigo= 'Calle Los Embajadores 4560 - Ate Vitare';
        }
        txt.value = codigo;
        var txt = document.getElementById("RUCemisor2");

        switch(valor)
        {
        case 'Grupo Coril SAC':
        codigo= '204080100';
        break;
        case 'Data System SAC':
        codigo= '204080200';
        break;
        case 'Incuba SAC':
        codigo= '204080300';
        break;
        case 'Empresa SRL':
        codigo= '204080400';
        }
        txt.value = codigo;
        var txt = document.getElementById("RUCreceptor2");

        switch(valor)
        {
        case 'Grupo Coril SAC':
        codigo= '206080900';
        break;
        case 'Data System SAC':
        codigo= '205080700';
        break;
        case 'Incuba SAC':
        codigo= '203080500';
        break;
        case 'Empresa SRL':
        codigo= '201080200';
        }
        txt.value = codigo;
        var txt = document.getElementById("RSemisor2");

        switch(valor)
       {
        case 'Grupo Coril SAC':
        codigo= 'Grupo Coril SAC';
        break;
        case 'Data System SAC':
        codigo= 'Data System SAC';
        break;
        case 'Incuba SAC':
        codigo= 'Incuba SAC';
        break;
        case 'Empresa SRL':
        codigo= 'Empresa SRL';
        }
        txt.value = codigo;
        var txt = document.getElementById("RSreceptor2");

        switch(valor)
       {
        case 'Grupo Coril SAC':
        codigo= 'Proveedor 01 SAC';
        break;
        case 'Data System SAC':
        codigo= 'Proveedor 02 SAC';
        break;
        case 'Incuba SAC':
        codigo= 'Proveedor 03 SAC';
        break;
        case 'Empresa SRL':
        codigo= 'Proveedor 04 SAC';
        }
        txt.value = codigo;
        var txt = document.getElementById("DFemisor2");

        switch(valor)
       {
        case 'Grupo Coril SAC':
        codigo= 'Calle Monte Rosa 256 - Chacarilla - Surco';
        break;
        case 'Data System SAC':
        codigo= 'Calle Monte Rosa 256 - Chacarilla - Surco - Of. 1001';
        break;
        case 'Incuba SAC':
        codigo= 'Calle Los Laureles 3234 - Jesús María';
        break;
        case 'Empresa SRL':
        codigo= 'Avenid Miguel Grau 2034 - Barranco';
        }
        txt.value = codigo;
        var txt = document.getElementById("DFreceptor2");

        switch(valor)
       {
        case 'Grupo Coril SAC':
        codigo= 'Jirón Lambayeque 3404 - Lima';
        break;
        case 'Data System SAC':
        codigo= 'Jirón Toquepala 508 - Breña';
        break;
        case 'Incuba SAC':
        codigo= 'Avenida Los Libertadores 5600 - Los Olivos';
        break;
        case 'Empresa SRL':
        codigo= 'Calle Los Embajadores 4560 - Ate Vitare';
        }
        txt.value = codigo;
      }



PDFObject.embed("pdf/prueba.pdf", "#pdf");
  
//Script Datepicker

      $(document).ready(function() {
        $('#single_cal1').daterangepicker({
          singleDatePicker: true,
          calender_style: "picker_1"
        }, function(start, end, label) {
          console.log(start.toISOString(), end.toISOString(), label);
        });
        $('#single_cal2').daterangepicker({
          singleDatePicker: true,
          calender_style: "picker_2"
        }, function(start, end, label) {
          console.log(start.toISOString(), end.toISOString(), label);
        });
        $('#single_cal3').daterangepicker({
          singleDatePicker: true,
          calender_style: "picker_3"
        }, function(start, end, label) {
          console.log(start.toISOString(), end.toISOString(), label);
        });
        $('#single_cal4').daterangepicker({
          singleDatePicker: true,
          calender_style: "picker_4"
        }, function(start, end, label) {
          console.log(start.toISOString(), end.toISOString(), label);
        });
      });
$(function(){
    $('.borrar .eliminar').click( function (){
        $(this).closest('.borrar').remove();
    });
});