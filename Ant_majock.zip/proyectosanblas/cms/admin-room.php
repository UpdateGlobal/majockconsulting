<?php

    session_start();
    if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true) { }
    else{
        header('Location: login.php');
        exit;
    }
    // Consulta de Conexion
    require_once("Conexion.php");
    header('Content-type: text/html; charset=utf-8');
    // GET HABITACIONES
    $sql="SELECT * FROM Habitaciones WHERE idioma=1";
    $Habitaciones = mysqli_query($conexion,$sql);

    // GET CARACTERISTICAS
    $sql="SELECT * FROM HabitacionesIncluye";
    $Incluye = mysqli_query($conexion,$sql);

?>

<!DOCTYPE html>
<html lang="es">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>GestorPro - Content Management System</title>
    <!-- Bootstrap -->
    <link href="estilos.css" rel="stylesheet">
    <link href="tabs.css" rel="stylesheet">
  </head>

  <body class="nav-md">
    <div class="container body">
      <div class="main_container">
        <?php include("panel-lateral.php"); ?>

        <!-- top navigation -->
        <?php include("menu-top.php"); ?>
        <!-- /top navigation -->
        <!-- CONTENIDO -->
        <div class="right_col" role="main" style="min-height:none !important">
           
          <div class="">
            <!-- <button id="uno" onlick="duplicar()" type="submit" class="btn btn-primary"><i class="fa fa-plus"></i></button> -->
            <div class="page-title">
              <div class="title_left">
                <h3>Administrar Habitación
                </h3>
                <!-- <button id="uno" onlick="duplicar()" type="submit" class="btn btn-primary"><i class="fa fa-plus"></i></button> -->
              </div>
            </div>
            <div class="col-md-12">
              <div class="x_content">
                <div class="col-md-12">
                  <div class="col-md-2" style="padding-left:0px">
                    <div class="item form-group">
                      <div class="flecha">
                        <span style="float:left;"><h5>Seleccionar idioma del sitio:</h5></span>
                        <select id="idioma-room" class="select2_single form-control" onchange="revisarRoom();">
                          <option value="0" selected hidden inactive>Idioma</option>
                          <option value="1">Sitio en Español</option>
                          <option value="2">Sitio en Inglés</option>
                        </select>
                      </div>
                    </div>
                  </div>
                  <div class="col-md-2" style="padding-left:0px">
                    <div class="item form-group">
                      <div class="flecha">
                        <span id="label-selec-room" style="float:left;"><h5>Tipo de habitación:</h5></span>
                        <select id="selec-room" class="select2_single form-control" onchange="revisarRoom();">
                          <option value="0" selected hidden inactive>Seleccionar Tipo</option>
                            
                            <?php while ($h=mysqli_fetch_array($Habitaciones)) {  ?> 
                                <option value="<?php echo $h['id']?>"><?php echo $h['nombre']?></option>
                            <?php } ?>  

                        </select>
                      </div>
                    </div>
                  </div>
                  <div class="col-md-2" style="padding-left:0px">
                    <div class="item form-group">
                      <div class="flecha">
                        <span id="label-accion-room" style="float:left;"><h5>Seleccionar acción:</h5></span>
                        <select id="accion-room" class="select2_single form-control" onchange="revisarRoom();">
                          <option value="0" selected hidden inactive>Acción</option>
                          <option value="1">Activar</option>
                          <option value="2">Desactivar</option>
                          <option value="3">Eliminar</option>
                          <option value="4" >Editar</option>
                        </select>
                      </div>
                    </div>
                  </div>

                   <div class="col-md-2" style="display:none" id="confirm2">
                    <div class="item form-group">
                      <div class="flecha">
                        <span id="idioma" style="float:left;"><h5>Confirmar</h5></span><br><br>
                        <button id="btn-confirm2" type="submit" onclick="UpdateEstado();" class="btn btn-primary float-r"><i class="fa fa-save"></i> Actualizar</button> 
                      </div>
                    </div>
                  </div>
                  
                  <div id="editar-room">
                    <div class="col-md-12">
                    <span style="float:left;"><h5>Imágenes <a href="#" data-toggle="modal" data-target="#myModal2"><sup><i class="fa fa-question-circle-o"></i></sup></a></h5></span>
                  </div>
                  <form id="formulario" action="Controlador/Habitacion.php" method="post">
                  <div class="col-md-12" style="margin-left:-10px">
                        
                        <div class="col-md-2">
                            <input type="hidden" id="idImg1" name="idImg1">
                            <input id="upload1" type="file" readonly placeholder="No hay ningún archivo seleccionado" onchange="document.getElementById('img1').src = window.URL.createObjectURL(this.files[0])" value="">
                            <label for="upload1">
                                <span> Elegir imagen 1&hellip;</span>
                            </label>
                            <img id="img1" width="100%" height="auto"/ >
                        </div>

                        <div class="col-md-2">
                            <input type="hidden" id="idImg2" name="idImg2">
                            <input id="upload2" type="file" readonly placeholder="No hay ningún archivo seleccionado" onchange="document.getElementById('img2').src = window.URL.createObjectURL(this.files[0])"  value="">
                            <label for="upload2">
                                <span> Elegir imagen 2&hellip;</span>
                            </label>
                            <img id="img2" width="100%" height="auto"/ >
                        </div>

                        <div class="col-md-2">
                            <input type="hidden" id="idImg3" name="idImg3">
                            <input id="upload3" type="file" readonly placeholder="No hay ningún archivo seleccionado"  onchange="document.getElementById('img3').src = window.URL.createObjectURL(this.files[0])" value="">
                            <label for="upload3">
                                <span> Elegir imagen 3&hellip;</span>
                            </label>
                            <img id="img3" width="100%" height="auto"/>
                        </div>

                        <div class="col-md-2">
                            <input type="hidden" id="idImg4" name="idImg4">
                            <input id="upload4" type="file" readonly placeholder="No hay ningún archivo seleccionado" onchange="document.getElementById('img4').src = window.URL.createObjectURL(this.files[0])"  value="">
                            <label for="upload4">
                                <span> Elegir imagen 4&hellip;</span>
                            </label>
                            <img id="img4" width="100%" height="auto"/ >     
                        </div>

                        <div class="col-md-2">
                            <input type="hidden" id="idImg5" name="idImg5">
                            <input id="upload5" type="file" readonly placeholder="No hay ningún archivo seleccionado" onchange="document.getElementById('img5').src = window.URL.createObjectURL(this.files[0])"  value="">
                            <label for="upload5">
                                <span> Elegir imagen 5&hellip;</span>
                            </label>
                            <img id="img5" width="100%" height="auto"/ >
                        </div>

                       <div class="col-md-2">
                            <input type="hidden" id="idImg6" name="idImg6">
                            <input id="upload6" type="file" readonly placeholder="No hay ningún archivo seleccionado" onchange="document.getElementById('img6').src = window.URL.createObjectURL(this.files[0])"  value="">
                            <label for="upload6">
                                <span> Elegir imagen 6&hellip;</span>
                            </label>
                            <img id="img6" width="100%" height="auto"/ >  
                        </div>


                  </div>

                  <input type="hidden" id="funcion" name="funcion" value="update"></input>
                  <input type="hidden" id="id" name="id"></input>

                  <span style="float:left;"><h5>Características:</h5></span>
                  
                  <div class="col-md-12">
                      <ul>
                        <?php $aux=1;?>
                        <?php while ($incluye=mysqli_fetch_array($Incluye)) {?>
                            <li>
                              <input type="checkbox" id="myCheckbox<?php echo $incluye['id']?>" name="myCheckbox<?php echo $incluye['id']?>" " />
                              <label for="myCheckbox<?php echo $incluye['id']?>">
                                <i class="fa fa-flash"></i>
                                <p> <?php echo $incluye['nombre']?></p>
                              </label>
                            </li>
                        <?php $aux = $aux + 1;} ?> 
                        <input type="hidden" id="numCheckbox" name="numCheckbox" value="<?php echo $aux?>"></input>

                      </ul>
                  </div>

                  <div class="col-md-12">
                    <div class="item form-group">
                      <div class="flecha">
                        <span style="float:left;"><h5>Nombre:</h5></span>
                        <input type="text" id="nombre" name="nombre" required="required" class="form-control" placeholder="Nombre de la habitación..."></input>
                        <div id ="error4"></div>
                      </div>
                    </div>
                  </div>

                  <div class="col-md-12">
                    <div class="item form-group">
                      <div class="flecha">
                        <span style="float:left;"><h5>Precio:</h5></span>
                        <input type="text" id="precio" name="precio" required="required" class="form-control" placeholder="Precio"></input>
                        <div id ="error4"></div>
                      </div>
                    </div>
                  </div>

                  <div class="col-md-12">
                    <div class="item form-group">
                      <div class="flecha">
                        <span style="float:left;"><h5>Descripción:</h5></span>
                        <textarea id="detalles" name="detalles" required="required" class="form-control" placeholder="Descripción de la habitación..."></textarea>
                        <div id ="error4"></div>
                      </div>
                    </div>
                  </div>
                  </div>
                  
                 
                </div>
               
              </div>
              </div>
              <div class="col-md-12">
                  <div class="item form-group">
                  <br>
                  <button id="confirm" type="submit" style="display:none" class="btn btn-primary float-l"><i class="fa fa-save"></i> Actualizar</button>  
                  </div>
              </div>
              <div class="clearfix"></div>
              <div class="row">
              </form>
              
            </div>
          </div>

        </div>


       
       <?php include("creditos.php"); ?>
        <!-- CONTENIDO -->

        
      </div>
    </div>
    <div id="myModal2" class="modal fade" role="dialog">
      <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
          <div class="modal-header">
            <h2><i class="fa fa-flash"></i> GestorPro - SUGERENCIAS</h2>
            <button type="button" class="close" data-dismiss="modal">&times;</button>
          </div>
          <div class="modal-body">
            
            <div class="col-md-12">
             <h2>Añadir nueva imagen</h2>
             <p>Para un desempeño óptimo del slider, te recomendamos usar una imagen de <b>999px alto x 999px ancho</b> o superior (manteniendo la proporción) a una resolución de 72dpi. Para mayores dudas por favor consulte con su proveedor o escríbanos a gestorpro@linkreativo.com.</p>
            </div>
          </div>
          <div class="modal-footer">
            <br>
            <div class="col-md-12">
              <button type="submit" class="btn btn-guardarcambios" data-dismiss="modal">Aceptar</button>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- jQuery -->
    <script src="js/jquery.min.js"></script>
    <!-- Bootstrap -->
    <script src="js/bootstrap.min.js"></script>
    <!-- Bootstrap -->
     <!-- Custom Theme Scripts -->
    <script src="js/custom.min.js"></script>
    <!--x-Editable-->
    <script src="js/bootstrap-editable.min.js"></script>
    <script src="js/main.js"></script>
    <!-- WOW.js -->
    <script src="js/plugins.js"></script>
    <script src="js/scripts.js"></script>

    
    <script src="js/hematobank.js"></script>
    <script src="js/cbpFWTabs.js"></script>
    
    <script>

      // --------------------------------------------------------------------------------------
      // ------------------- GET HABITACION ---------------------------------------------------
      // --------------------------------------------------------------------------------------

      function revisarRoom(){
        var tipo = document.getElementById("accion-room").value;
        var idioma = document.getElementById("idioma-room").value;
        var idH = document.getElementById("selec-room").value;
        
        // Pongo a cero las imagenes
        document.getElementById("img1").src ="";
        document.getElementById("img2").src ="";
        document.getElementById("img3").src ="";
        document.getElementById("img4").src ="";
        document.getElementById("img5").src ="";
        document.getElementById("img6").src ="";

        document.getElementById("idImg1").value ="*";
        document.getElementById("idImg2").value ="*";
        document.getElementById("idImg3").value ="*";
        document.getElementById("idImg4").value ="*";
        document.getElementById("idImg5").value ="*";
        document.getElementById("idImg6").value ="*";

        if(tipo=="4"){
          
          document.getElementById("confirm").style.display="block";
          document.getElementById("confirm2").style.display="none";
          
          if(idioma>1){
            idH = parseInt(idH) + 1;
          }

          var parametros = {"funcion":"get", "idH" : idH};

          $.ajax({
              data:  parametros,
              url:   'Controlador/Habitacion.php',
              type:  'post',
              success:  function (response) {
                document.getElementById("nombre").value = response.nombre;
                document.getElementById("precio").value = response.precio;
                document.getElementById("detalles").value = response.detalles;
                document.getElementById("id").value = response.id;
                
                // Caracteristicas de la Habitacion
                var Array = response.incluye;
                var ArrayIncluye = Array.split(".");
                for(var i=0;i<ArrayIncluye.length;i++){
                  document.getElementById("myCheckbox"+ArrayIncluye[i]).checked = "checked";
                }

                // Imagenes de la Habitacion
                var Array = response.img;
                var ArrayImg = Array.split("?");
                for(var i=0;i<ArrayImg.length;i++){
                  var j = parseInt(i) + 1;
                  document.getElementById("img"+j).src = "../img/rooms/" + ArrayImg[i];
                }

                // ID Imagenes de la Habitacion
                var Array = response.idImg;
                var ArrayImg = Array.split("?");
                for(var i=0;i<ArrayImg.length;i++){
                  var j = parseInt(i) + 1;
                  document.getElementById("idImg"+j).value =  ArrayImg[i];
                }
              }
          });
        }
        else if(tipo=="3"){ 
          document.getElementById("confirm").style.display="none";
          document.getElementById("confirm2").style.display="block";
        }
        else if(tipo=="2"){
          document.getElementById("confirm").style.display="none";
          document.getElementById("confirm2").style.display="block";
        }
        else if(tipo=="1"){
          document.getElementById("confirm").style.display="none";
          document.getElementById("confirm2").style.display="block";
        }




      }

      // --------------------------------------------------------------------------------------
      // ------------------- UPDATE HABITACION ------------------------------------------------
      // --------------------------------------------------------------------------------------

      $("#formulario").submit(function(){

        var btnEnviar = $("#confirm");
        $.ajax({
            type: $(this).attr("method"),
            url: $(this).attr("action"),
            data:$(this).serialize(),

            success: function(response){
              if(response.msj=="ok")
                alert("HABITACION ACTUALIZADA");
            }
        });
        return false;

      });
      

    // --------------------------------------------------------------------------------------
    // ------------------- ACTIVAR - DESACTIVAR - ELIMINAR SLIDER ---------------------------
    // --------------------------------------------------------------------------------------

    function UpdateEstado(){

      var tipo = document.getElementById("accion-room").value;
      var idioma = document.getElementById("idioma-room").value;
      var idH = document.getElementById("selec-room").value;

      if(idioma>1){
        idH = parseInt(idH) + 1;
      }

      if(tipo=="1"){

        var parametros = {"funcion":"activar", "idH" : idH};
        $.ajax({
            data:  parametros,
            url:   'Controlador/Habitacion.php',
            type:  'post',
            success:  function (response) {
              alert("SE ACTIVO CON EXITO");
            }
        });
      }
      else if(tipo=="2"){

        var parametros = {"funcion":"desactivar", "idH" : idH};
        $.ajax({
            data:  parametros,
            url:   'Controlador/Habitacion.php',
            type:  'post',
            success:  function (response) {
              alert("SE DESACTIVO CON EXITO");
            }
        });
      }
      else if(tipo=="3"){

        var parametros = {"funcion":"eliminar", "idH" : idH};
        $.ajax({
            data:  parametros,
            url:   'Controlador/Habitacion.php',
            type:  'post',
            success:  function (response) {
              alert("SE ELIMINO CON EXITO");
              location.reload();
            }
        });
      }
    }

    // --------------------------------------------------------------------------------------
    // ------------------------------------- FIN --------------------------------------------
    // --------------------------------------------------------------------------------------

      (function() {

        [].slice.call( document.querySelectorAll( '.tabs' ) ).forEach( function( el ) {
          new CBPFWTabs( el );
        });

      })();




    </script>
    <script>
    document.getElementById('uno').onclick = duplicar;
    var i = 0;
    var primerbloque = document.getElementById('primerbloque');

    function duplicar() {
        var clone = primerbloque.cloneNode(true); // "deep" clone
        clone.id = "primerbloque" + ++i; // there can only be one element with an ID
        primerbloque.parentNode.appendChild(clone);
        primerbloque.style.display = "block";
    }
    </script>
   
    <!-- WOW.js -->
    <script src="js/wow.js"></script>
    
     <!-- PNotify -->
    <script src="js/pnotify.js"></script>
    <script src="js/pnotify.buttons.js"></script>
    <script src="js/pnotify.nonblock.js"></script>
    
    <!-- Scripts Varios -->
    <script type="text/javascript" src="js/script.js"></script>
    <script type="text/javascript" src="js/tabs.js"></script>

    
  </body>
</html>
