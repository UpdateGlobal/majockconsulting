<?php
 session_start();
  
 if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true) {
  
 }
 else{
    
    header('Location: login.php');
    exit;
  }
?>

<!DOCTYPE html>
<html lang="es">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>GestorPro - Content Management System</title>
    <!-- Bootstrap -->
    <link href="estilos.css" rel="stylesheet">
    <link href="tabs.css" rel="stylesheet">
  </head>

  <body class="nav-md">
    <div class="container body">
      <div class="main_container">
        <?php include("panel-lateral.php"); ?>

        <!-- top navigation -->
        <?php include("menu-top.php"); ?>
        <!-- /top navigation -->
        <!-- CONTENIDO -->
        <div class="right_col" role="main" style="min-height:none !important">
           <!-- <div id="crouton">
              <ul>
                  <li><a href="tabla.php">Inicio</a></li>
              </ul>
            </div> -->
          <div class="">
            
            <div class="page-title">
              <div class="title_left">
                <h3>Usuarios
                </h3>
                
              </div>
            </div>
            <div class="col-md-12">
              <div id="iconos" class="x_content">
                <!-- start project list -->
                
                  
                      <table id="datatable3" class="table table-striped projects">
                      <thead>
                        <tr>
                          <th style="width: 1%">#</th>
                          <th style="width: 20%">Usuario</th>
                          <th>Nombres y apellidos</th>
                          <th>Correo electrónico</th>
                          <!-- <th>Progreso</th> -->
                          <th>Perfil</th>
                          <th>Foto de perfil</th>
                          <th style="width: 20%">Acciones</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td>1</td>
                          <td>
                            <a href="tabla-banners.php">admin</a>
                            <br />
                            <small>Registrado el 01.01.2017</small>
                          </td>
                          <td>Jhon Doe</td>
                          <td>jdoe@correo.com</td>
                          <td>Administrador</td>
                          <td>
                            <a href="images/profile-pic.jpg" class="with-caption image-link" title="Caption text" data-group="1">
                              <img src="images/profile-pic.jpg" height="128" width="128" class="avatar" />  
                            </a>
                          </td>
                          <td>
                            <a href="admin-user.php" class="btn btn-info btn-xs"><i class="fa fa-pencil"></i> Editar </a>
                            <!-- <a href="#" class="btn btn-danger btn-xs"><i class="fa fa-trash-o"></i> Eliminar </a> --><!-- EL ADMIN NO SE PUEDE ELIMINAR -->

                          </td>
                        </tr>
                        
                      </tbody>
                    </table>
                    
                    <!-- end project list -->
               
              </div>
            </div>
            <!-- <div class="col-md-12">
              <div class="item form-group">
              <br>
              <button id="confirm" type="submit" onclick="confirmButton()" class="btn btn-primary float-l"><i class="fa fa-save"></i> REGISTRAR</button>  
              </div>
            </div> -->
            <div class="clearfix"></div>
            <div class="row">
              
            </div>
          </div>

        </div>


       
       <?php include("creditos.php"); ?>
        <!-- CONTENIDO -->

        
      </div>
    </div>
    <div id="myModal2" class="modal fade" role="dialog">
      <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
          <div class="modal-header">
            <h2><i class="fa fa-flash"></i> GestorPro - SUGERENCIAS</h2>
            <button type="button" class="close" data-dismiss="modal">&times;</button>
          </div>
          <div class="modal-body">
            
            <div class="col-md-12">
             <h2>Añadir nueva imagen</h2>
             <p>Para un desempeño óptimo del slider, te recomendamos usar una imagen de <b>999px alto x 999px ancho</b> o superior (manteniendo la proporción) a una resolución de 72dpi. Para mayores dudas por favor consulte con su proveedor o escríbanos a gestorpro@linkreativo.com.</p>
            </div>
          </div>
          <div class="modal-footer">
            <br>
            <div class="col-md-12">
              <button type="submit" class="btn btn-guardarcambios" data-dismiss="modal">Aceptar</button>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- jQuery -->
    <script src="js/jquery.min.js"></script>
    <!-- Bootstrap -->
    <script src="js/bootstrap.min.js"></script>
    <!-- Bootstrap -->
     <!-- Custom Theme Scripts -->
    <script src="js/custom.min.js"></script>
    <script src="js/jquery.magnific-popup.js"></script>
    
    <script>
    var groups = {};
$('.image-link').each(function() {
  var id = parseInt($(this).attr('data-group'), 10);
  
  if(!groups[id]) {
    groups[id] = [];
  } 
  
  groups[id].push( this );
});


$.each(groups, function() {
  
  $(this).magnificPopup({
      type: 'image',
      closeOnContentClick: true,
      closeBtnInside: false,
      gallery: { enabled:true }
  })
  
});

   
    </script>
    <!--x-Editable-->
    <script src="js/bootstrap-editable.min.js"></script>
    <script src="js/main.js"></script>
    <!-- WOW.js -->
    <script src="js/plugins.js"></script>
    <script src="js/scripts.js"></script>

    
    <script src="js/hematobank.js"></script>
    <script src="js/cbpFWTabs.js"></script>
    
    <script>
      (function() {

        [].slice.call( document.querySelectorAll( '.tabs' ) ).forEach( function( el ) {
          new CBPFWTabs( el );
        });

      })();
    </script>
    <script>
    document.getElementById('uno').onclick = duplicar;
    var i = 0;
    var primerbloque = document.getElementById('primerbloque');

    function duplicar() {
        var clone = primerbloque.cloneNode(true); // "deep" clone
        clone.id = "primerbloque" + ++i; // there can only be one element with an ID
        primerbloque.parentNode.appendChild(clone);
        primerbloque.style.display = "block";
    }
    </script>
   
    <!-- WOW.js -->
    <script src="js/wow.js"></script>
    
     <!-- PNotify -->
    <script src="js/pnotify.js"></script>
    <script src="js/pnotify.buttons.js"></script>
    <script src="js/pnotify.nonblock.js"></script>
    
    <!-- Scripts Varios -->
    <script type="text/javascript" src="js/script.js"></script>
    <script type="text/javascript" src="js/tabs.js"></script>

    
  </body>
</html>
