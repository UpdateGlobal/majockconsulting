<?php
 session_start();
  
 if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true) {
  
 }
 else{
    
    header('Location: login.php');
    exit;
  }
?>

<!DOCTYPE html>
<html lang="es">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Gestor de Contenidos</title>
    <!-- Bootstrap -->
    <link href="estilos.css" rel="stylesheet">
    <link href="tabs.css" rel="stylesheet">
  </head>

  <body class="nav-md">
    <div class="container body">
      <div class="main_container">
        <?php include("panel-lateral.php"); ?>

        <!-- top navigation -->
        <?php include("menu-top.php"); ?>
        <!-- CONTENIDO -->
        <div class="right_col" role="main">
          <div class="">
            <!--Breadcrumbs-->
            <!-- <div id="crouton">
              <ul>
                  <li><a href="#">Uno</a></li>
                  <li><a href="#">Dos</a></li>
                  <li><a href="#">Tres</a></li>
                  <li><a href="#">Cuatro</a></li>
              </ul>
            </div> -->

            <!-- <div class="page-title">
              <div class="title_left">
                <h3><i class="fa fa-pencil-square-o" style="font-size:.7em;opacity:.7"></i> Nuevo registro</h3>
              </div>
            </div> -->
            <div class="clearfix"></div>
            
            <div class="row">
                <table id="datatable" class="table table-striped table-bordered bulk_action">
                      <thead>
                        <tr class="columnas">
                          <th>Usuario</th>
                          <th>Nombres y apellidos</th>
                          <th>Perfil</th>
                          <th>E-mail</th>
                          <th>Fecha de Registro</th>
                          <th>Estado</th>
                          <th>Acciones</th>
                        </tr>
                      </thead>
                      <tbody>
                        
                        <tr class="columnas1">
                          <td><input type="checkbox"></td>
                          <td>
                            Admin 
                          </td>
                          <td>
                            Jason Gonzales
                          </td>
                          <td>
                            Administrador
                          </td>
                          <td>
                            E-mail
                          </td>
                          <td>
                            10/12/2016
                          </td>
                          <td>
                            <button type="submit" onclick="confirmButton()" class="btn btn-primary">EDITAR</button>
                          </td>
                        </tr>
                      </tbody>
                    </table>
                <div id="chartdiv" class="wow fadeInUp"></div>
                <?php include("botones.php"); ?>
            </div>
          </div>
        </div>
       <?php include("creditos.php"); ?>
        <!-- CONTENIDO -->
      </div>
    </div>
    <!-- jQuery -->
    <script src="js/jquery.min.js"></script>
    <!-- Bootstrap -->
    <script src="js/bootstrap.min.js"></script>
    <!-- Custom Theme Scripts -->
    <script src="js/custom.min.js"></script>
    <!--x-Editable-->
    <script src="js/bootstrap-editable.min.js"></script>
    <script src="js/main.js"></script>
    <!-- bootstrap-daterangepicker -->
    <script src="js/moment.min.js"></script>
    <script src="js/daterangepicker.js"></script>
    <!-- bootstrap-daterangepicker -->
    <script>
      $(document).ready(function() {
        $('#single_cal1').daterangepicker({
          singleDatePicker: true,
          calender_style: "picker_1"
        }, function(start, end, label) {
          console.log(start.toISOString(), end.toISOString(), label);
        });
        $('#single_cal2').daterangepicker({
          singleDatePicker: true,
          calender_style: "picker_2"
        }, function(start, end, label) {
          console.log(start.toISOString(), end.toISOString(), label);
        });
        $('#single_cal3').daterangepicker({
          singleDatePicker: true,
          calender_style: "picker_3"
        }, function(start, end, label) {
          console.log(start.toISOString(), end.toISOString(), label);
        });
        $('#single_cal4').daterangepicker({
          singleDatePicker: true,
          calender_style: "picker_4"
        }, function(start, end, label) {
          console.log(start.toISOString(), end.toISOString(), label);
        });
      });
    </script>
    
    <!-- WOW.js -->
    <script src="js/plugins.js"></script>
    <script src="js/scripts.js"></script>
    
    <!-- Select2 -->
    <script src="js/select2.full.min.js"></script>
    <script>
    $(document).ready(function() {
    $(".select2_single").select2({
    placeholder: "Empresa Emisora",
    allowClear: false
    });
    $(".select2_single1").select2({
    placeholder: "Empresa Receptora",
    allowClear: false
    });
    $(".select2_single2").select2({
    placeholder: "Selecciona un nombre",
    allowClear: false
    });
    $(".select2_group").select2({
    placeholder: "Tipo de Documento",
    allowClear: false
    });
    });
    </script>
    <!-- Bootstrap -->
    <script src="js/hematobank.js"></script>
    <script src="js/cbpFWTabs.js"></script>
    <script>
      (function() {

        [].slice.call( document.querySelectorAll( '.tabs' ) ).forEach( function( el ) {
          new CBPFWTabs( el );
        });

      })();
    </script>
  
<!-- Styles -->
<style>
#chartdiv {
  width   : 100%;
  height    : 500px;
  font-size : 11px;
}         
</style>

<!-- Resources -->
<!-- <script src="js/amcharts.js"></script>
<script src="js/serial.js"></script>
<script src="js/export.min.js"></script>
<link rel="stylesheet" href="css/export.css" type="text/css" media="all" />
<script src="js/light.js"></script> -->
<script src="https://www.amcharts.com/lib/3/amcharts.js"></script>
<script src="https://www.amcharts.com/lib/3/serial.js"></script>
<script src="https://www.amcharts.com/lib/3/plugins/export/export.min.js"></script>
<link rel="stylesheet" href="https://www.amcharts.com/lib/3/plugins/export/export.css" type="text/css" media="all" />
<script src="https://www.amcharts.com/lib/3/themes/light.js"></script>


<!-- Chart code -->
<script>
var chart = AmCharts.makeChart("chartdiv", {
    "type": "serial",
    "theme": "light",
    "marginRight": 80,
    "dataDateFormat": "YYYY-MM-DD HH:NN",
    "dataProvider": [{
        "date": "2016-01-02 08:30",
        "duration": 7.3
    }, {
        "date": "2016-01-02 08:35",
        "duration": 5.4
    }, {
        "date": "2016-01-02 08:40",
        "duration": 7
    }, {
        "date": "2016-01-02 08:45",
        "duration": 6.1
    }, {
        "date": "2016-01-02 08:50",
        "duration": 9
    }, {
        "date": "2016-01-02 08:55",
        "duration": 6.2
    }, {
        "date": "2016-01-02 08:60",
        "duration": 7.5
    }, {
        "date": "2016-01-02 09:05",
        "duration": 7
    }, {
        "date": "2016-01-02 09:10",
        "duration": 5.8
    }, {
        "date": "2016-01-02 09:15",
        "duration": 7.2
    }, {
        "date": "2016-01-02 09:20",
        "duration": 6.7
    }, {
        "date": "2016-01-02 09:25",
        "duration": 7.9
    }],
    "balloon": {
        "cornerRadius": 6,
        "horizontalPadding": 15,
        "verticalPadding": 10
    },
    "valueAxes": [{
        "axisAlpha": 0
    }],
    "graphs": [{
        "bullet": "square",
        "bulletBorderAlpha": 1,
        "bulletBorderThickness": 1,
        "fillAlphas": 0.3,

        "fillColorsField": "lineColor",
        "legendValueText": "[[value]]",
        "lineColorField": "lineColor",
        "title": "duration",
        "valueField": "duration",
        "balloonText": "<div style='margin:3px; font-size:16px;'>Temperatura:<b>[[value]]</b> C°</div>"
    }],
    
    "chartCursor": {
        "categoryBalloonDateFormat": "YYYY-MMM-DD LL:NN",
        "cursorAlpha": 0,
        "fullWidth": true,
        "pan": true,
        "valueLineEnabled": true,
        "valueLineBalloonEnabled": true,
        "cursorAlpha":1,
        "cursorColor":"#258cbb",
        "limitToGraph":"g1",
        "valueLineAlpha":0.2,
        "valueZoomable":true
    },
    "dataDateFormat": "YYYY-MM-DD LL:NN",
    "categoryField": "date",
    "categoryAxis": {
        "minPeriod": "mm",
        "parseDates": true
    },
    "export": {
        "enabled": true
    }
});


chart.addListener("dataUpdated", zoomChart);

zoomChart();
// this method is called when chart is first inited as we listen for "dataUpdated" event
function zoomChart() {
    // different zoom methods can be used - zoomToIndexes, zoomToDates, zoomToCategoryValues
    chart.zoomToIndexes(chartData.length - 250, chartData.length - 100);
}
</script>

<!-- HTML -->
     <!-- PNotify -->
    <script src="js/pnotify.js"></script>
    <script src="js/pnotify.buttons.js"></script>
    <script src="js/pnotify.nonblock.js"></script>
    <!-- Scripts Varios -->
    <script type="text/javascript" src="js/script.js"></script>
    <script type="text/javascript" src="js/tabs.js"></script>
    <script type="text/javascript" src="js/dataTables.bootstrap.min.js"></script>
    
  </body>
</html>
