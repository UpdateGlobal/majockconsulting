<div class="top_nav">
<div class="nav_menu">
<nav>
<div class="nav toggle">
<a id="menu_toggle"><i class="fa fa-bars"></i></a>
</div>
<ul class="nav navbar-nav navbar-right">
<li class="">
<a href="javascript:;" class="user-profile dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
<img src="images/profile-pic.jpg" alt="">
<span class=" fa fa-angle-down"></span>
</a>
<ul class="dropdown-menu dropdown-usermenu pull-right">
<li><a href="javascript:;" onclick="new PNotify({
title: 'Migra a PRO',
text: 'Para acceder a esta funcionalidad debes tener una cuenta premium.',
type: 'info',
hide: false,
styling: 'bootstrap3'
});">Mi Perfil</a></li>
<li><a href="javascript:;" data-toggle="modal" data-target="#myModal1">Soporte</a></li>

<li><a href="javascript:;" >Migrar a 
<span class="badge bg-red">PRO</span></a></li>
<!-- <li><a href="javascript:;">Mis documentos</a></li> -->
<li><a href="logout.php"><i class="fa fa-sign-out pull-right"></i> Salir</a></li>
</ul>
</li>


</ul>
</nav>
</div>
</div>