 <?php
 session_start();
  
 if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true) {
  
 }
 else{
    
    header('Location: login.php');
    exit;
  }
?>


<!DOCTYPE html>
<html lang="es">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>GestorPro - Content Management System</title>
    <!-- Bootstrap -->
    <link href="estilos.css" rel="stylesheet">
    <link href="tabs.css" rel="stylesheet">
  </head>

  <body class="nav-md">
    <div class="container body">
      <div class="main_container">
        <?php include("panel-lateral.php"); ?>

        <!-- top navigation -->
        <?php include("menu-top.php"); ?>
        <!-- /top navigation -->
        <!-- CONTENIDO -->
        <div class="right_col" role="main" style="min-height:none !important">
           
          <div class="">
            <!--<button id="uno" onlick="duplicar()" type="submit" class="btn btn-primary"><i class="fa fa-plus"></i></button>-->
            <div class="page-title">
              <div class="title_left">
                <h3>Registrar Característica
                </h3>
                <!-- <button id="uno" onlick="duplicar()" type="submit" class="btn btn-primary"><i class="fa fa-plus"></i></button> -->
              </div>
            </div>
            
            <form name="form" action="Controlador/Caracteristicas.php" method="post" enctype="multipart/form-data">
                 <input type="hidden" id="funcion" name="funcion" value="insert"></input>
                <div class="col-md-12">
                  <div class="x_content" id="primerbloque">
                    
                    
                        <div class="col-md-4" style="padding-left:0px">
                          <div class="item form-group flecha">
                            <span style="float:left;"><h5>Nueva Característica (Español):</h5></span>
                            <input type="text" name="nombre" id="nombre" class="form-control" placeholder="Nombre de la característica"/>
                            <br>
                          </div>
                        </div>

                        <div class="col-md-4" style="padding-left:0px">
                          <div class="item form-group flecha">
                            <span style="float:left;"><h5>Nueva Característica (Ingles):</h5></span>
                            <input type="text" name="nombreI" id="nombreI" class="form-control" placeholder="Nombre de la característica"/>
                            <br>
                          </div>
                        </div>

                        <div class="col-md-2">
                        <span style="float:left;"><h5>Nuevo ícono <a href="#" data-toggle="modal" data-target="#myModal2"><sup><i class="fa fa-question-circle-o"></i></sup></a></h5></span>
                        <input type="text" name="ico" id="ico" class="form-control" placeholder="Pegar código aquí"/>
                      </div>
                      
                  </div>
                </div>
                <div class="col-md-12">

                  <div class="item form-group" style="margin-left:10px;">
                  <br>
                  <button id="confirm" type="submit" onclick="confirmButton()" class="btn btn-primary float-l"><i class="fa fa-save"></i> Actualizar</button>  
                  </div>
                </div>
                <div class="clearfix"></div>
                <div class="row">
            </form>
              
            </div>
          </div>

        </div>


       
       <?php include("creditos.php"); ?>
        <!-- CONTENIDO -->

        
      </div>
    </div>
    <div id="myModal2" class="modal fade" role="dialog">
      <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
          <div class="modal-header">
            <h2><i class="fa fa-flash"></i> GestorPro - SUGERENCIAS</h2>
            <button type="button" class="close" data-dismiss="modal">&times;</button>
          </div>
          <div class="modal-body">
            
            <div class="col-md-12">
             <h2>Añadir nuevo íconos</h2>
             <p>Para añadir un nuevo ícono debes dirigirte al <a href="iconos.php">Banco de Íconos</a> y seleccionar alguno de los íconos disponibles. Bastará hacer clic sobre el ícono que desea emplearse y volver a la página de registro de nuevas característica y pegar el código dentro del campo Nuevo Ícono.</p>
            </div>
          </div>
          <div class="modal-footer">
            <br>
            <div class="col-md-12">
              <button type="submit" class="btn btn-guardarcambios" data-dismiss="modal">Aceptar</button>
            </div>
          </div>
        </div>
      </div>
    </div>
    <?php include("soporte.php"); ?>
    <!-- jQuery -->
    <script src="js/jquery.min.js"></script>
    <!-- Bootstrap -->
    <script src="js/bootstrap.min.js"></script>
    <!-- Bootstrap -->
     <!-- Custom Theme Scripts -->
    <script src="js/custom.min.js"></script>
    <!--x-Editable-->
    <script src="js/bootstrap-editable.min.js"></script>
    <script src="js/main.js"></script>
    <!-- WOW.js -->
    <script src="js/plugins.js"></script>
    <script src="js/scripts.js"></script>

    
    <script src="js/hematobank.js"></script>
    <script src="js/cbpFWTabs.js"></script>
    
    <script>
      (function() {

        [].slice.call( document.querySelectorAll( '.tabs' ) ).forEach( function( el ) {
          new CBPFWTabs( el );
        });

      })();
    </script>
    <script>
    document.getElementById('uno').onclick = duplicar;
    var i = 0;
    var primerbloque = document.getElementById('primerbloque');

    function duplicar() {
        var clone = primerbloque.cloneNode(true); // "deep" clone
        clone.id = "primerbloque" + ++i; // there can only be one element with an ID
        primerbloque.parentNode.appendChild(clone);
        primerbloque.style.display = "block";
    }
    </script>
   
    <!-- WOW.js -->
    <script src="js/wow.js"></script>
    
     <!-- PNotify -->
    <script src="js/pnotify.js"></script>
    <script src="js/pnotify.buttons.js"></script>
    <script src="js/pnotify.nonblock.js"></script>
    
    <!-- Scripts Varios -->
    <script type="text/javascript" src="js/script.js"></script>
    <script type="text/javascript" src="js/tabs.js"></script>

    
  </body>
</html>
