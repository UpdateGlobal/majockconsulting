<?php
    
    session_start();
    if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true) { }
    else{
        header('Location: login.php');
        exit;
    }


    // Consulta de Conexion
    require_once("Conexion.php");
    header('Content-type: text/html; charset=utf-8');
    // GET SLIDER ESPAÑOL
    $sql="SELECT * FROM Slider WHERE idioma=1";
    $Slider = mysqli_query($conexion,$sql);
    //$SliderE = mysqli_fetch_array($SliderE);

?>


<!DOCTYPE html>
<html lang="es">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>GestorPro - Content Management System</title>
    <!-- Bootstrap -->
    <link href="estilos.css" rel="stylesheet">
    <link href="tabs.css" rel="stylesheet">
  </head>

  <body class="nav-md">
    <div class="container body">
      <div class="main_container">
        <?php include("panel-lateral.php"); ?>

        <!-- top navigation -->
        <?php include("menu-top.php"); ?>
        <!-- /top navigation -->
        <!-- CONTENIDO -->
        <div class="right_col" role="main" style="min-height:none !important">
           <div id="crouton">
              <ul>
                  <li><a href="tabla.php">Inicio</a></li>
                  <li><a href="tabla-promociones.php">Tabla de Banners</a></li>
              </ul>
            </div>
          <div class="">
            
            <div class="page-title">
              <div class="title_left">
                <h3>Tabla de contenidos - Banners
                </h3>
                
              </div>
            </div>
            <div class="col-md-12">
              <div id="iconos" class="x_content">
                <div class="col-md-2 selector-idioma" style="padding-left:0px">
                  <div class="item form-group">
                    <div class="flecha">
                      <span style="float:left;"><h5>Seleccionar idioma del sitio:</h5></span>
                      <select id="idioma" class="select2_single form-control" onchange="redireccion();">
                        <!-- <option value="0" selected hidden inactive>Idioma</option> -->
                        <option value="1" selected>Sitio en Español</option>
                        <option value="2"> Sitio en Inglés</option>
                      </select>
                    </div>
                  </div>
                </div>
                <!-- start project list -->
                    <table id="datatable3" class="table table-striped projects">
                      <thead>
                        <tr>
                          <th style="width: 1%">#</th>
                          <th style="width: 20%">Nombre del slide</th>
                          <th>Imágen</th>
                          <!-- <th>Progreso</th> -->
                          <th>Título del slide</th>
                          <th>Subtítulo del slide</th>
                          <th>Estado</th>
                          <th style="width: 20%">Acciones</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php $i=1;?>
                        <?php while ($slider=mysqli_fetch_array($Slider)) {?>
                            
                            <tr>
                              <td><?php echo $i?></td>
                              <td>
                                <a>Banner</a>
                                <br />
                              </td>
                              <td>
                                <ul class="list-inline">
                                  <li>
                                    <a href="../img/slider/<?php echo $slider['img']?>" class="with-caption image-link" title="Caption text">
                                      <img src="../img/slider/<?php echo $slider['img']?>" class="avatar" />  
                                    </a>
                                  </li>
                                </ul>
                              </td>
                              <td> <?php echo $slider['titulo']?> </td>
                              <td> <?php echo $slider['frase']?> </td>
                              <td>
                                <?php if($slider['act']==1){?>
                                  Activo
                                <?php } ?>

                                <?php if($slider['act']==0){?>
                                  Inactivo
                                <?php } ?>
                              </td>
                              <td>
                                <a href="edit-banners.php" class="btn btn-info btn-xs"><i class="fa fa-pencil"></i> Editar </a>
                                <a href="" onclick="eliminarSlide(<?php echo $slider['id']?>);" class="btn btn-danger btn-xs"><i class="fa fa-trash-o"></i> Eliminar </a>
                              </td>
                            </tr>
                        
                        <?php $i=$i+1;} ?>
                     
                        
                      </tbody>
                    </table>
                    <!-- end project list -->
               
              </div>
            </div>
            <!-- <div class="col-md-12">
              <div class="item form-group">
              <br>
              <button id="confirm" type="submit" onclick="confirmButton()" class="btn btn-primary float-l"><i class="fa fa-save"></i> REGISTRAR</button>  
              </div>
            </div> -->
            <div class="clearfix"></div>
            <div class="row">
              
            </div>
          </div>

        </div>


       
       <?php include("creditos.php"); ?>
        <!-- CONTENIDO -->

        
      </div>
    </div>
    <div id="myModal2" class="modal fade" role="dialog">
      <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
          <div class="modal-header">
            <h2><i class="fa fa-flash"></i> GestorPro - SUGERENCIAS</h2>
            <button type="button" class="close" data-dismiss="modal">&times;</button>
          </div>
          <div class="modal-body">
            
            <div class="col-md-12">
             <h2>Añadir nueva imagen</h2>
             <p>Para un desempeño óptimo del slider, te recomendamos usar una imagen de <b>999px alto x 999px ancho</b> o superior (manteniendo la proporción) a una resolución de 72dpi. Para mayores dudas por favor consulte con su proveedor o escríbanos a gestorpro@linkreativo.com.</p>
            </div>
          </div>
          <div class="modal-footer">
            <br>
            <div class="col-md-12">
              <button type="submit" class="btn btn-guardarcambios" data-dismiss="modal">Aceptar</button>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- jQuery -->
    <script src="js/jquery.min.js"></script>
    <!-- Bootstrap -->
    <script src="js/bootstrap.min.js"></script>
    <!-- Bootstrap -->
     <!-- Custom Theme Scripts -->
    <script src="js/custom.min.js"></script>
    <script src="js/jquery.magnific-popup.js"></script>
    
    <script>

    function eliminarSlide(idS){

        var parametros = {"funcion":"eliminar", "idS" : idS};
        $.ajax({
            data:  parametros,
            url:   'Controlador/Slider.php',
            type:  'post',
            success:  function (response) {
              alert("SE ELIMINO CON EXITO");
              location.reload();
            }
        });
    }

    function redireccion(){
      var idioma = document.getElementById("idioma").value;
      if(idioma==1){
          location.href="tabla-banners.php";
      }else{
          location.href="EN_tabla-banners.php";
      }
    }

   $('.image-link').magnificPopup({
    type: 'image',
    closeBtnInside: false,
    closeOnContentClick: true,
  
    image: {
      verticalFit: true,
      titleSrc: function(item) {
        return item.el.attr('title') + ' &middot; <a class="image-source-link" href="'+item.src+'" target="_blank">Abrir en una nueva ventana</a>';
      }
    }
  
  });
    </script>
    <!--x-Editable-->
    <script src="js/bootstrap-editable.min.js"></script>
    <script src="js/main.js"></script>
    <!-- WOW.js -->
    <script src="js/plugins.js"></script>
    <script src="js/scripts.js"></script>

    
    <script src="js/hematobank.js"></script>
    <script src="js/cbpFWTabs.js"></script>
    
    <script>
      (function() {

        [].slice.call( document.querySelectorAll( '.tabs' ) ).forEach( function( el ) {
          new CBPFWTabs( el );
        });

      })();
    </script>
    <script>
    document.getElementById('uno').onclick = duplicar;
    var i = 0;
    var primerbloque = document.getElementById('primerbloque');

    function duplicar() {
        var clone = primerbloque.cloneNode(true); // "deep" clone
        clone.id = "primerbloque" + ++i; // there can only be one element with an ID
        primerbloque.parentNode.appendChild(clone);
        primerbloque.style.display = "block";
    }
    </script>
   
    <!-- WOW.js -->
    <script src="js/wow.js"></script>
    
     <!-- PNotify -->
    <script src="js/pnotify.js"></script>
    <script src="js/pnotify.buttons.js"></script>
    <script src="js/pnotify.nonblock.js"></script>
    
    <!-- Scripts Varios -->
    <script type="text/javascript" src="js/script.js"></script>
    <script type="text/javascript" src="js/tabs.js"></script>
    <!-- Magnific Popup core JS file -->
    

    
  </body>
</html>
