<div class="col-md-2">
    <div class="item form-group">
        <div class="flecha wow fadeInUp">
          <select id="rango" class="select2_single1 form-control" tabindex="3" id="status" name="status">
            <option value="0" selected hidden disabled>Rango</option>
            <option value="1">Hora</option>
            <option value="2">Día</option>
            <option value="3">Semana</option>
            <option value="4">Mes</option>
            <option value="5">Año</option>
          </select>
        </div>
    </div>
</div>
<div id="fecha" class="col-md-2">
    <div class="item form-group flecha">
        <fieldset>
          <div class="control-group">
            <div class="controls">
              <div class="col-md-12 form-group">
                <input type="text" class="form-control has-feedback-left" id="single_cal4" placeholder="Seleccionar mes/año" aria-describedby="inputSuccess2Status">
                <span class="fa fa-calendar-o form-control-feedback left" aria-hidden="true"></span>
                <span id="inputSuccess2Status1" class="sr-only">(success)</span>
              </div>
            </div>
          </div>
        </fieldset>
    </div>
</div>
<div id="hora" class="col-md-2">
    <div class="item form-group">
        <div class="flecha">
          <input type="text" placeholder="Hora Inicio (Ej. 05:30)" class="form-control">
        </div>
    </div>
</div>
<div id="mes" class="col-md-2">
    <div class="item form-group">
        <div class="flecha">
          <select class="select2_single1 form-control" tabindex="3" id="status" name="status" onchange="showDiv(this)">
            <option value="0" selected hidden disabled>Mes</option>
            <option value="1">Enero</option>
            <option value="2">Febrero</option>
            <option value="3">Marzo</option>
            <option value="4">Abril</option>
            <option value="5">Mayo</option>
            <option value="1">Junio</option>
            <option value="2">Julio</option>
            <option value="3">Agosto</option>
            <option value="4">Setiembre</option>
            <option value="5">Octubre</option>
            <option value="4">Noviembre</option>
            <option value="5">Diciembre</option>
          </select>
        </div>
    </div>
</div>
<div id="ano" class="col-md-2">
    <div class="item form-group">
        <div class="flecha">
          <input type="text" placeholder="Año (Ej. 1985)" class="form-control">
        </div>
    </div>
</div>
<div id="boton" class="col-md-2">
    <div class="item form-group">
        <div class="flecha">
            <button type="submit" onclick="confirmButton()" class="btn btn-primary">MOSTRAR</button>
        </div>
    </div>
</div>

<script>

</script>

<style>
    #fecha, #hora, #mes, #boton, #ano{
        display: none;
    }
</style>