<div class="col-md-3 left_col menu_fixed">
<div class="left_col scroll-view">
<div class="navbar nav_title" style="border: 0;">
<a href="#" class="site_title">
	<i class="fa fa-flash" style="color:#ef7120"></i> 
<span style="color:white">GestorPro <sup>&reg;</sup></span>
</a>
<!-- <i class="fa fa-heartbeat" style="color:#ff2424"></i> 
<span style="color:white">HematoBank</span> -->
</div>
<div class="clearfix"></div>


    
<br />

<!-- sidebar menu -->
<div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
	<div class="menu_section">
		<!-- <h3>Principal</h3> -->
		<h3>Administrar Web</h3>
		<ul class="nav side-menu">
			<li>
				<a>
				<i class="fa fa-users"></i> Usuarios <span class="fa fa-chevron-right"></span>
				</a>
				<ul class="nav child_menu">
					<li><a href="usuarios.php">Usuarios Registrados</a></li>
				  	<li>
				  		<a href="#" onclick="new PNotify({
						title: 'No Disponible',
						text: 'Si quiere acceder a este beneficio contacte con su proveedor de servicios.',
						type: 'info',
						hide: false,
						sound: true,
						styling: 'bootstrap3'
						});">Registrar Usuarios 
						
						</a>
					</li>
				  <li><a href="admin-user.php">Administrar Usuarios</a></li>
				</ul>
			</li>
			<li>
				<a>
				<i class="fa fa-image"></i> Banners <span class="fa fa-chevron-right"></span>
				</a>
				<ul class="nav child_menu">
				  <!-- <li><a href="admin-banners.php">Banners</a></li> -->
				  <li><a href="tabla-banners.php">Administrar Banners</a></li>
				  <li><a href="edit-banners.php">Editar Banner</a></li>
				  <li><a href="#" onclick="new PNotify({
						title: 'No Disponible',
						text: 'Si quiere acceder a este beneficio contacte con su proveedor de servicios.',
						type: 'info',
						hide: false,
						sound: true,
						styling: 'bootstrap3'
						});">Editor de imágenes</a></li>
				</ul>
			</li>
			<li>
				<a>
				<i class="fa fa-bed"></i> Habitaciones <span class="fa fa-chevron-right"></span>
				</a>
				<ul class="nav child_menu">
				  <li><a href="tabla-habitaciones.php">Administrar Habitaciones</a></li>
				  <li><a href="#" onclick="new PNotify({
						title: 'No Disponible',
						text: 'Si quiere acceder a este beneficio contacte con su proveedor de servicios.',
						type: 'info',
						hide: false,
						sound: true,
						styling: 'bootstrap3'
						});">Registrar Habitación</a></li>
				  <li><a href="admin-room.php">Editar Habitación</a></li>
				  <li><a href="reg-room-carac.php">Registrar Características</a></li>
				  <li><a href="admin-room-carac.php">Administrar Características</a></li>
				  <li><a href="iconos.php">Banco de Íconos</a></li>
				</ul>
			</li>
			<li>
				<a>
				<i class="fa fa-bullhorn"></i> Promociones <span class="fa fa-chevron-right"></span>
				</a>
				<ul class="nav child_menu">
				  <li><a href="reg-promo.php">Registrar Promoción</a></li>
				  <li><a href="tabla-promociones.php">Administrar Promociones</a></li>
				  <li><a href="admin-promo.php">Editar Promoción</a></li>
				</ul>
			</li>
			<li>
				<a>
				<i class="fa fa-briefcase"></i> Servicios <span class="fa fa-chevron-right"></span>
				</a>
				<ul class="nav child_menu">
				  <li><a href="#" onclick="new PNotify({
			title: 'No Disponible',
			text: 'Si quiere acceder a este beneficio contacte con su proveedor de servicios.',
			type: 'info',
			hide: false,
			sound: true,
			styling: 'bootstrap3'
			});">Registrar Servicio</a></li>
				  <li><a href="#" onclick="new PNotify({
			title: 'No Disponible',
			text: 'Si quiere acceder a este beneficio contacte con su proveedor de servicios.',
			type: 'info',
			hide: false,
			sound: true,
			styling: 'bootstrap3'
			});">Administrar Servicios</a></li>
				</ul>
			</li>
			<li>
				<a>
				<i class="fa fa-coffee"></i> Cafetería <span class="fa fa-chevron-right"></span>
				</a>
				<ul class="nav child_menu">
				  <li><a href="#" onclick="new PNotify({
			title: 'No Disponible',
			text: 'Si quiere acceder a este beneficio contacte con su proveedor de servicios.',
			type: 'info',
			hide: false,
			sound: true,
			styling: 'bootstrap3'
			});">Registrar Carta</a></li>
				  <li><a href="#" onclick="new PNotify({
			title: 'No Disponible',
			text: 'Si quiere acceder a este beneficio contacte con su proveedor de servicios.',
			type: 'info',
			hide: false,
			sound: true,
			styling: 'bootstrap3'
			});">Administrar Cafetería</a></li>
				</ul>
			</li>
			<li>
				<a>
				<i class="fa fa-cutlery"></i> Restaurant <span class="fa fa-chevron-right"></span>
				</a>
				<ul class="nav child_menu">
				  <li><a href="#" onclick="new PNotify({
			title: 'No Disponible',
			text: 'Si quiere acceder a este beneficio contacte con su proveedor de servicios.',
			type: 'info',
			hide: false,
			sound: true,
			styling: 'bootstrap3'
			});">Registrar Carta</a></li>
				  <li><a href="#" onclick="new PNotify({
			title: 'No Disponible',
			text: 'Si quiere acceder a este beneficio contacte con su proveedor de servicios.',
			type: 'info',
			hide: false,
			sound: true,
			styling: 'bootstrap3'
			});">Administrar Restaurant</a></li>
				</ul>
			</li>

			

		</ul>

	</div>
	<div class="menu_section">
        <h3>Mejoras</h3>
        <ul class="nav side-menu">
        <li>
        	<a href="#" onclick="new PNotify({
			title: 'No Disponible',
			text: 'Si quiere acceder a este beneficio contacte con su proveedor de servicios.',
			type: 'info',
			hide: false,
			sound: true,
			styling: 'bootstrap3'
			});"><i class="fa fa-line-chart"></i> Analytics <span class="label label-success pull-right">Solo PRO</span></a></a>
		</li>
		<li><a href="#" onclick="new PNotify({
			title: 'No Disponible',
			text: 'Si quiere acceder a este beneficio contacte con su proveedor de servicios.',
			type: 'info',
			hide: false,
			sound: true,
			styling: 'bootstrap3'
			});"><i class="fa fa-shopping-cart"></i> Novedades <span class="label label-success pull-right">Solo PRO</span></a></span></a>
		</li>
		<li><a href="#" onclick="new PNotify({
			title: 'No Disponible',
			text: 'Si quiere acceder a este beneficio contacte con su proveedor de servicios.',
			type: 'info',
			hide: false,
			sound: true,
			styling: 'bootstrap3'
			});"><i class="fa fa-cut"></i> Editor Gráfico <span class="label label-success pull-right">Solo PRO</span></a></span></a>
		</li>
		<li><a href="#" onclick="new PNotify({
			title: 'Próximamente',
			text: 'Lo sentimos, este beneficio aún no se encuentra disponible.',
			type: 'info',
			hide: false,
			sound: true,
			styling: 'bootstrap3'
			});"><i class="fa fa-plane"></i> Tour <span class="label label-success pull-right">Próximamente</span></a></span></a>
		</li>
        <!-- <li><a href="javascript:void(0)"><i class="fa fa-laptop"></i> Ver cambios <span class="fa fa-chevron-right"></span></a> -->
        </li>
        </ul>
      </div>
</div>
<!-- /sidebar menu -->
<!-- /menu footer buttons -->
<div class="sidebar-footer hidden-small">

<a data-toggle="tooltip" data-placement="top" title="Salir">
<span class="glyphicon glyphicon-off" aria-hidden="true"></span>
</a>
</div>
<!-- /menu footer buttons -->
</div>
</div>
<?php include("soporte.php"); ?>