<?php
	
	require_once("Conexion.php");
    header('Content-type: text/html; charset=utf-8');

	session_start();

	
	$username = $_POST['username'];
	$password = $_POST['password'];
	  
	$sql = "SELECT * FROM usuarios WHERE username = '$username'";
	$result = $conexion->query($sql);
	 
	if ($result->num_rows > 0) {     
	}
	
	$row = $result->fetch_array(MYSQLI_ASSOC);
	
	if (password_verify($password, $row['password'])) { 
	  
	    $_SESSION['loggedin'] = true;
	    $_SESSION['username'] = $username;
	    $_SESSION['start'] = time();
	    //$_SESSION['expire'] = $_SESSION['start'] + (5 * 60);
	 	
	 	header('Location: index.php');
	 
	 } else { 
	   	echo "Username o Password estan incorrectos.";
   		echo "<br><a href='login.php'>Volver a Intentarlo</a>";
	 }
	 mysqli_close($conexion);
	 ?>
