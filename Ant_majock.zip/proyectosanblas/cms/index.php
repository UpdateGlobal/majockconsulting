<?php
    
    session_start();
    if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true) { }
    else{
        header('Location: login.php');
        exit;
    }
    // Consulta de Conexion
    require_once("Conexion.php");
    header('Content-type: text/html; charset=utf-8');
    
    // GET ELEMENTOS ESPAÑOL
    $sql="SELECT * FROM Promociones WHERE idioma=1";
    $Promociones = mysqli_query($conexion,$sql);

    $sql="SELECT * FROM Habitaciones WHERE idioma=1";
    $Habitaciones = mysqli_query($conexion,$sql);

    $sql="SELECT * FROM Slider WHERE idioma=1";
    $Slider = mysqli_query($conexion,$sql);

    // GET ELEMENTOS ESPAÑOL
    $sql="SELECT * FROM Promociones WHERE idioma=2";
    $PromocionesI = mysqli_query($conexion,$sql);

    $sql="SELECT * FROM Habitaciones WHERE idioma=2";
    $HabitacionesI = mysqli_query($conexion,$sql);

    $sql="SELECT * FROM Slider WHERE idioma=2";
    $SliderI = mysqli_query($conexion,$sql);


?>



<!DOCTYPE html>
<html lang="es">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>GestorPro - Content Management System</title>
    <!-- Bootstrap -->
    <link href="estilos.css" rel="stylesheet">
    <link href="tabs.css" rel="stylesheet">
  </head>

  <body class="nav-md">
    <div class="container body">
      <div class="main_container">
        <?php include("panel-lateral.php"); ?>

        <!-- top navigation -->
        <?php include("menu-top.php"); ?>
        <!-- /top navigation -->
        <!-- CONTENIDO -->
        <div class="right_col" role="main" style="min-height:none !important">
           <!-- <div id="crouton">
              <ul>
                  <li><a href="tabla.php">Inicio</a></li>
              </ul>
            </div> -->
          <div class="">
            
            <div class="page-title">
              <div class="title_left">
                <h3>Tabla de contenidos
                </h3>
                
              </div>
            </div>
            <div class="col-md-12">
              <div id="iconos" class="x_content">
                <!-- start project list -->
                <div class="col-md-2 selector-idioma" style="padding-left:0px">
                  <div class="item form-group">
                    <div class="flecha">
                      <span style="float:left;"><h5>Seleccionar idioma del sitio:</h5></span>
                      <select id="idioma" class="select2_single form-control" >
                        <!-- <option value="0" selected hidden inactive>Idioma</option> -->
                        <option value="1" selected>Sitio en Español</option>
                        <option value="2">Sitio en Inglés</option>
                      </select>
                    </div>
                  </div>
                </div>
                    
                    <div id="tabla-es">
                      <table id="datatable3" class="table table-striped projects">
                      <thead>
                        <tr>
                          <th style="width: 1%">#</th>
                          <th style="width: 20%">Nombre del ítem</th>
                          <th>Contenido global</th>
                          <!-- <th>Progreso</th> -->
                          <th>Administrador</th>
                          <th style="width: 20%">Acciones</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td>1</td>
                          <td>
                            <a href="tabla-banners.php">Banners</a>
                            <br />
                            <small></small>
                          </td>
                          <td>
                            <ul class="list-inline">
                              
                            <?php while ($h=mysqli_fetch_array($Slider)) {?>

                              <li>
                                <a href="../img/slider/<?php echo $h['img']?>" class="with-caption image-link" title="Caption text" data-group="1">
                                  <img src="../img/slider/<?php echo $h['img']?>" class="avatar" />  
                                </a>
                              </li>

                            <?php } ?>

                            </ul>
                          </td>
                          <!-- <td class="project_progress">
                            <div class="progress progress_sm">
                              <div class="progress-bar bg-green" role="progressbar" data-transitiongoal="57"></div>
                            </div>
                            <small>57% Complete</small>
                          </td> -->
                          <td>
                            Administrador
                          </td>
                          <td>
                            <a href="tabla-banners.php" class="btn btn-info btn-xs"><i class="fa fa-pencil"></i> Editar </a>
                            <!--<a href="#" class="btn btn-danger btn-xs"><i class="fa fa-trash-o"></i> Eliminar </a>-->
                          </td>
                        </tr>
                        <tr>
                          <td>2</td>
                          <td>
                            <a href="tabla-habitaciones.php">Habitaciones</a>
                            <br />
                            <small></small>
                          </td>
                          <td>
                            <ul class="list-inline">
                              
                            <?php while ($p=mysqli_fetch_array($Habitaciones)) {?>    
                              <li>
                                <!--<a href="#" class="with-caption image-link" title="Caption text" data-group="2">-->
                                  <img src="images/room.jpg" class="avatar" />  
                                <!--</a>-->
                              </li>
                            <?php } ?> 
                            </ul>
                          </td>

                          <td>
                            Administrador
                          </td>
                          <td>
                            
                            <a href="tabla-habitaciones.php" class="btn btn-info btn-xs"><i class="fa fa-pencil"></i> Editar </a>
                            <!--<a href="#" class="btn btn-danger btn-xs"><i class="fa fa-trash-o"></i> Eliminar </a>-->
                          </td>
                        </tr>
                        <tr>
                          <td>3</td>
                          <td>
                            <a href="tabla-promociones.php">Promociones</a>
                            <br />
                            <small></small>
                          </td>
                          <td>
                            <ul class="list-inline">
                              
                            <?php while ($p=mysqli_fetch_array($Promociones)) {?>  
                              <li>
                                <a href="../img/promociones/<?php echo $p['img']?>" class="with-caption image-link" title="Caption text" data-group="3">
                                  <img src="../img/promociones/<?php echo $p['img']?>" class="avatar" />  
                                </a>
                              </li>
                            <?php } ?>  
                              
                            </ul>
                          </td>
                          <td>
                            Administrador
                          </td>
                          <td>
                            
                            <a href="tabla-promociones.php" class="btn btn-info btn-xs"><i class="fa fa-pencil"></i> Editar </a>
                            <!--<a href="#" class="btn btn-danger btn-xs"><i class="fa fa-trash-o"></i> Eliminar </a>-->
                          </td>
                        </tr>
                        
                      </tbody>
                    </table>
                    

                    </div>
                    

                    <div id="tabla-en">
                      <table id="datatable3" class="table table-striped projects">
                      <thead>
                        <tr>
                          <th style="width: 1%">#</th>
                          <th style="width: 20%">Nombre del ítemm</th>
                          <th>Contenido global</th>
                          <!-- <th>Progreso</th> -->
                          <th>Administrador</th>
                          <th style="width: 20%">Acciones</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td>1</td>
                          <td>
                            <a href="tabla-banners.php">Banners</a>
                            <br />
                            <small></small>
                          </td>
                          <td>
                            <ul class="list-inline">
                              
                            <?php while ($h=mysqli_fetch_array($SliderI)) {?>

                              <li>
                                <a href="../img/slider/<?php echo $h['img']?>" class="with-caption image-link" title="Caption text" data-group="1">
                                  <img src="../img/slider/<?php echo $h['img']?>" class="avatar" />  
                                </a>
                              </li>

                            <?php } ?>

                            </ul>
                          </td>

                          <td>
                            Administrador
                          </td>
                          <td>
                            <a href="tabla-banners.php" class="btn btn-info btn-xs"><i class="fa fa-pencil"></i> Editar </a>
                            <!--<a href="#" class="btn btn-danger btn-xs"><i class="fa fa-trash-o"></i> Eliminar </a>-->
                          </td>
                        </tr>
                        <tr>
                          <td>2</td>
                          <td>
                            <a href="tabla-habitaciones.php">Habitaciones</a>
                            <br />
                            <small></small>
                          </td>
                          <td>
                            <ul class="list-inline">
                              
                            <?php while ($p=mysqli_fetch_array($HabitacionesI)) {?>    
                              <li>
                                <!--<a href="#" class="with-caption image-link" title="Caption text" data-group="2">-->
                                  <img src="images/room.jpg" class="avatar" />  
                                <!--</a>-->
                              </li>
                            <?php } ?> 
                            </ul>
                          </td>

                          <td>
                            Administrador
                          </td>
                          <td>
                            
                            <a href="tabla-habitaciones.php" class="btn btn-info btn-xs"><i class="fa fa-pencil"></i> Editar </a>
                            <!--<a href="#" class="btn btn-danger btn-xs"><i class="fa fa-trash-o"></i> Eliminar </a>-->
                          </td>
                        </tr>
                        <tr>
                          <td>3</td>
                          <td>
                            <a href="tabla-promociones.php">Promociones</a>
                            <br />
                            <small></small>
                          </td>
                          <td>
                            <ul class="list-inline">
                              
                            <?php while ($p=mysqli_fetch_array($PromocionesI)) {?>  
                              <li>
                                <a href="../img/promociones/<?php echo $p['img']?>" class="with-caption image-link" title="Caption text" data-group="3">
                                  <img src="../img/promociones/<?php echo $p['img']?>" class="avatar" />  
                                </a>
                              </li>
                            <?php } ?>  
                              
                            </ul>
                          </td>
                          <td>
                            Administrador
                          </td>
                          <td>
                            
                            <a href="tabla-promociones.php" class="btn btn-info btn-xs"><i class="fa fa-pencil"></i> Editar </a>
                            <!--<a href="#" class="btn btn-danger btn-xs"><i class="fa fa-trash-o"></i> Eliminar </a>-->
                          </td>
                        </tr>
                        
                      </tbody>
                    </table>
                    

                    </div>
                    <!-- end project list -->
               
              </div>
            </div>

            <div class="clearfix"></div>
            <div class="row">
              
            </div>
          </div>

        </div>


       
       <?php include("creditos.php"); ?>
        <!-- CONTENIDO -->

        
      </div>
    </div>
    <div id="myModal2" class="modal fade" role="dialog">
      <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
          <div class="modal-header">
            <h2><i class="fa fa-flash"></i> GestorPro - SUGERENCIAS</h2>
            <button type="button" class="close" data-dismiss="modal">&times;</button>
          </div>
          <div class="modal-body">
            
            <div class="col-md-12">
             <h2>Añadir nueva imagen</h2>
             <p>Para un desempeño óptimo del slider, te recomendamos usar una imagen de <b>999px alto x 999px ancho</b> o superior (manteniendo la proporción) a una resolución de 72dpi. Para mayores dudas por favor consulte con su proveedor o escríbanos a gestorpro@linkreativo.com.</p>
            </div>
          </div>
          <div class="modal-footer">
            <br>
            <div class="col-md-12">
              <button type="submit" class="btn btn-guardarcambios" data-dismiss="modal">Aceptar</button>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- jQuery -->
    <script src="js/jquery.min.js"></script>
    <!-- Bootstrap -->
    <script src="js/bootstrap.min.js"></script>
    <!-- Bootstrap -->
     <!-- Custom Theme Scripts -->
    <script src="js/custom.min.js"></script>
    <script src="js/jquery.magnific-popup.js"></script>
    
    <script>

    var groups = {};
$('.image-link').each(function() {
  var id = parseInt($(this).attr('data-group'), 10);
  
  if(!groups[id]) {
    groups[id] = [];
  } 
  
  groups[id].push( this );
});


$.each(groups, function() {
  
  $(this).magnificPopup({
      type: 'image',
      closeOnContentClick: true,
      closeBtnInside: false,
      gallery: { enabled:true }
  })
  
});

   
    </script>
    <!--x-Editable-->
    <script src="js/bootstrap-editable.min.js"></script>
    <script src="js/main.js"></script>
    <!-- WOW.js -->
    <script src="js/plugins.js"></script>
    <script src="js/scripts.js"></script>

    
    <script src="js/hematobank.js"></script>
    <script src="js/cbpFWTabs.js"></script>
    
    <script>
      (function() {

        [].slice.call( document.querySelectorAll( '.tabs' ) ).forEach( function( el ) {
          new CBPFWTabs( el );
        });

      })();
    </script>
    <script>
    document.getElementById('uno').onclick = duplicar;
    var i = 0;
    var primerbloque = document.getElementById('primerbloque');

    function duplicar() {
        var clone = primerbloque.cloneNode(true); // "deep" clone
        clone.id = "primerbloque" + ++i; // there can only be one element with an ID
        primerbloque.parentNode.appendChild(clone);
        primerbloque.style.display = "block";
    }
    </script>
   
    <!-- WOW.js -->
    <script src="js/wow.js"></script>
    
     <!-- PNotify -->
    <script src="js/pnotify.js"></script>
    <script src="js/pnotify.buttons.js"></script>
    <script src="js/pnotify.nonblock.js"></script>
    
    <!-- Scripts Varios -->
    <script type="text/javascript" src="js/script.js"></script>
    <script type="text/javascript" src="js/tabs.js"></script>

    
  </body>
</html>
