<?php

    // Consulta de Conexion
    require_once("Conexion.php");
    //header('Content-type: text/html; charset=utf-8');
    // GET SLIDER ESPAÑOL
    $sql = "SELECT * FROM Habitaciones where idioma=2 AND act=1";
    $Habitaciones = mysqli_query($conexion,$sql);

    $sql = "SELECT * FROM Promociones where idioma=2 AND act=1";
    $Promociones = mysqli_query($conexion,$sql);



?>




<nav>
	<div class="container">
		<ul class="jetmenu">
			<li class="active"><a href="index.php">Inicio</a>
			</li>
			<li><a href="#">Servicios</a>
				<div class="megamenu full-width">
					<div class="row">
						<div class="col-sm-3">
							<img src="images/junior.jpg" alt="" class="img-responsive" />
							<h4>Eventos</h4>
							<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc eu lacus sed neque auctor cursus.</p>
							<p><a href="eventos.php" class="btn btn-primary">Ver más</a></p>
						</div>
						<div class="col-sm-3">
							<img src="images/junior.jpg" alt="" class="img-responsive" />
							<h4>Salones</h4>
							<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc eu lacus sed neque auctor cursus.</p>
							<p><a href="eventos.php" class="btn btn-primary">Ver más</a></p>
						</div>
						<div class="col-sm-3">
							<img src="images/clasica-simple.jpg" alt="" class="img-responsive" />
							<h4>Lavandería</h4>
							<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc eu lacus sed neque auctor cursus.</p>
							<p><a href="eventos.php" class="btn btn-primary">Ver más</a></p>
						</div>
						<div class="col-sm-3">
							<img src="images/clasica-simple.jpg" alt="" class="img-responsive" />
							<h4>Business Center</h4>
							<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc eu lacus sed neque auctor cursus.</p>
							<p><a href="eventos.php" class="btn btn-primary">Ver más</a></p>
						</div>
					</div>
				</div>
			</li>
			<li><a href="habitaciones.php">Habitaciones</a>
				<div class="megamenu full-width">
					<div class="row">
						




						<?php while ($h=mysqli_fetch_array($Habitaciones)) {  ?>	


							<?php
								$id=$h['id'];
                                $sql="select * from HabitacionesImg where idH='$id'";
                                $img = mysqli_query($conexion,$sql);
                                $miImg=mysqli_fetch_array($img)
	   						?>

							<div class="col-sm-15">
								<img src="../img/room/<?php echo $miImg['img']?>" alt="" class="img-responsive" />
								<h4><?php echo $h['nombre']?></h4>
								<p><?php echo $h['detalles']?></p>
								<p><a href="room.php?id=<?php echo $h['id']?>" class="btn btn-primary">Ver más</a></p>
							</div>

						<?php } ?>	



					</div>
				</div>
			</li>
			<li><a href="#">Restaurant</a>
				<div class="megamenu full-width">
					<div class="row">
						<div class="col-sm-4">
							<img src="images/restaurant-1.jpg" alt="" class="img-responsive" />
							<h4>Cafetería</h4>
							<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc eu lacus sed neque auctor cursus.</p>
							<p><a href="cafeteria.php" class="btn btn-primary">Ver más</a></p>
						</div>
						<div class="col-sm-4">
							<img src="images/restaurant-2.jpg" alt="" class="img-responsive" />
							<h4>Restaurant</h4>
							<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc eu lacus sed neque auctor cursus.</p>
							<p><a href="restaurant.php" class="btn btn-primary">Ver más</a></p>
						</div>
						<div class="col-sm-4">
							<img src="images/terraza.jpg" alt="" class="img-responsive" />
							<h4>Terraza Restaurant</h4>
							<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc eu lacus sed neque auctor cursus.</p>
							<p><a href="terraza.php" class="btn btn-primary">Ver más</a></p>
						</div>
					</div>
				</div>
			</li>

			<li><a href="#">Promociones</a>
				<div class="megamenu full-width">
					<div class="row">

						<?php while ($p=mysqli_fetch_array($Promociones)) {  ?>

							<div class="col-sm-3">
								<h5><?php echo $p['titulo'] ?></h5>
								<a href="promociones.php"><img src="../img/promociones/<?php echo $p['img']?>" alt="Special Offer" class="img-responsive" /></a>
							</div>
						
						<?php } ?>

					</div>
				</div>
			</li>

			
			<li><a href="contacto.php">Contacto</a>
			</li>
		</ul>
	</div>
</nav>