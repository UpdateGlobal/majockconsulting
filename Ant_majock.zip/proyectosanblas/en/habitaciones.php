<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
		<meta name="description" content="Hotel San Blas">
		<meta name="author" content="Jason Gonzales">
		<title>Habitaciones | HOTEL SAN BLAS, Siempre Brindándole lo Mejor | sanblashotel.com</title>
		<link rel="shortcut icon" href="images/favicon.png">

		<!-- Main Stylesheet -->
		<link href="css/style.css" rel="stylesheet">

		<!-- HTML5 shiv and Respond.js IE8 support of HTML5 elements and media queries -->
		<!--[if lt IE 9]>
		<script src="js/html5shiv.js"></script>
		<script src="js/respond.min.js"></script>
		<![endif]-->

	</head>
	<body>

		<!-- ============ LOADER START ============ -->

		<!-- <div id="loader">
			<i class="fa fa-cog fa-4x fa-spin primary-color"></i>
		</div> -->

		<!-- ============ LOADER END ============ -->

		<!-- ============ HEADER START ============ -->

		<header>
			<?php include("header.php"); ?>
			<?php include("nav.php"); ?>
		</header>

		<!-- ============ HEADER END ============ -->

		<!-- ============ CONTENT START ============ -->

		<section id="content">
			<div class="container">
				<div class="row">
					<div class="col-sm-12 text-center">
						<h5>Habitaciones para cada necesidad</h5>
						<h1>Alojamiento</h1>
						<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras nec erat ac orci maximus gravida in vitae nisi. Nam quis dolor eros. Etiam nisi dui, ornare ac maximus id, malesuada eget tellus. Nulla eget dolor cursus, consectetur purus vitae, commodo leo. Aliquam erat volutpat. Suspendisse elementum, risus eu facilisis luctus, lectus velit tempus turpis, et pulvinar nulla sem et nunc. Nunc ultricies erat et ipsum sollicitudin pellentesque. Ut lacinia bibendum posuere. Suspendisse dolor urna, pharetra vel enim et, maximus volutpat mi.</p>
						<hr>
					</div>
				</div>
				<div class="row">

					<!-- Room 1 -->
					<div class="room col-sm-6 col-md-4">
						<img src="images/junior.jpg" alt="" class="img-responsive" />
						<h4>Habitación Simple</h4>
						<ul>
							<li>Camas:<span>1 cama Queen</span></li>
							<li>Capacidad:<span>2 personas</span></li>
							<li>Área:<span>30m<sup>2</sup></span></li>
							<li>Precio:<span>S/.99</span></li>
						</ul>
						<p>
							<a href="suite.html" class="btn btn-default">Details</a>
							<a href="reservation.html" class="btn btn-primary pull-right">Book Now</a>
						</p>
					</div>
					
					<!-- Room 1 -->
					<div class="room col-sm-6 col-md-4">
						<img src="images/junior.jpg" alt="" class="img-responsive" />
						<h4>Clásica Simple</h4>
						<ul>
							<li>Camas:<span>1 cama Queen</span></li>
							<li>Capacidad:<span>2 personas</span></li>
							<li>Área:<span>30m<sup>2</sup></span></li>
							<li>Precio:<span>S/.99</span></li>
						</ul>
						<p>
							<a href="clasica.html" class="btn btn-default">Ver más</a>
							<a href="reservas.php" class="btn btn-primary pull-right">Reservar</a>
						</p>
					</div>
					<!-- Room 1 -->
					<div class="room col-sm-6 col-md-4">
						<img src="images/junior.jpg" alt="" class="img-responsive" />
						<h4>Ejecutiva Simple</h4>
						<ul>
							<li>Camas:<span>1 cama Queen</span></li>
							<li>Capacidad:<span>2 personas</span></li>
							<li>Área:<span>30m<sup>2</sup></span></li>
							<li>Precio:<span>S/.99</span></li>
						</ul>
						<p>
							<a href="ejecutiva.php" class="btn btn-default">Ver más</a>
							<a href="reservas.php" class="btn btn-primary pull-right">Reservar</a>
						</p>
					</div>
					<!-- Room 1 -->
					<div class="room col-sm-6 col-md-4">
						<img src="images/junior.jpg" alt="" class="img-responsive" />
						<h4>Ejecutiva Doble</h4>
						<ul>
							<li>Camas:<span>1 cama Queen</span></li>
							<li>Capacidad:<span>2 personas</span></li>
							<li>Área:<span>30m<sup>2</sup></span></li>
							<li>Precio:<span>S/.99</span></li>
						</ul>
						<p>
							<a href="ejecutiva-doble.php" class="btn btn-default">Ver más</a>
							<a id="reservas.php" class="btn btn-primary pull-right">Reservar</a>
						</p>
					</div>
					<!-- Room 1 -->
					<div class="room col-sm-6 col-md-4">
						<img src="images/junior.jpg" alt="" class="img-responsive" />
						<h4>Junior Suite</h4>
						<ul>
							<li>Camas:<span>1 cama Queen</span></li>
							<li>Capacidad:<span>2 personas</span></li>
							<li>Área:<span>30m<sup>2</sup></span></li>
							<li>Precio:<span>S/.99</span></li>
						</ul>
						<p>
							<a href="junior.php" class="btn btn-default">Ver más</a>
							<a href="reservas.php" class="btn btn-primary pull-right">Reservar</a>
						</p>
					</div>

					
				</div>
			</div>
		</section>

		<!-- ============ CONTENT END ============ -->

		<!-- ============ FOOTER START ============ -->

		<footer>
			<div id="widgets">
				<div class="container">
					<div class="row">

						<!-- About Us Start -->
						<div class="col-sm-3 widget">
							<h4>About us</h4>
							<p>Morbi nec quam sed elit pharetra faucibus. Cras vel massa viverra ligula suscipit interdum eget nec est. Cras nibh mi, faucibus at ligula eu, eleifend tincidunt justo. Nunc porttitor massa at nisi condimentum fringilla. Nullam finibus, nibh eu hendrerit suscipit, tellus mi commodo lectus, sit amet dictum.<br><a href="about.html">Read more...</a></p>
						</div>
						<!-- About Us End -->

						<!-- Quick Links Start -->
						<div class="col-sm-3 widget">
							<h4>Quick links</h4>
							<nav>
								<ul>
									<li><a href="weddings.html"><i class="fa fa-angle-right primary-color"></i>Weddings</a></li>
									<li><a href="conferences.html"><i class="fa fa-angle-right primary-color"></i>Conferences</a></li>
									<li><a href="events.html"><i class="fa fa-angle-right primary-color"></i>Events</a></li>
									<li><a href="vouchers.html"><i class="fa fa-angle-right primary-color"></i>Gift Vouchers</a></li>
									<li><a href="contact.html"><i class="fa fa-angle-right primary-color"></i>Location</a></li>
									<li><a href="gallery.html"><i class="fa fa-angle-right primary-color"></i>Photo Gallery</a></li>
								</ul>
							</nav>
						</div>
						<!-- Quick Links End -->

						<!-- Newsletter Start -->
						<div class="col-sm-3 widget">
							<h4>Newsletter</h4>
							<form role="form" name="newsletter-form" id="newsletter-form" action="process-newsletter.php">
								<div class="form-group" id="newsletter-name-group">
									<label class="sr-only" for="newsletter-name">Name</label>
									<input type="text" class="form-control" id="newsletter-name" placeholder="Name">
								</div>
								<div class="form-group" id="newsletter-surname-group">
									<label class="sr-only" for="newsletter-surname">Surname</label>
									<input type="text" class="form-control" id="newsletter-surname" placeholder="Surname">
								</div>
								<div class="form-group" id="newsletter-email-group">
									<label class="sr-only" for="newsletter-email">Email</label>
									<input type="email" class="form-control" id="newsletter-email" placeholder="Email">
								</div>
								<button type="submit" class="btn btn-primary">Subscribe</button>
							</form>
						</div>
						<!-- Newsletter End -->

						<!-- Contact Start -->
						<div class="col-sm-3 widget">
							<h4>Contact</h4>
							<p>
								The Traveller Hotel<br>
								8699 Santa Monica Blvd<br>
								Los Angeles, CA 90069-4109
							</p>
							<p>
								Phone: 1800-123-456<br>
								Fax:  1800-123-456<br>
								Email: info@smartway.com
							</p>
							<p>
								<a href="contact.html">Get Directions &nbsp; <i class="fa fa-angle-right"></i></a>
							</p>
						</div>
						<!-- Contact End -->

					</div>
				</div>
			</div>
			<div id="credits">
				<div class="container">
					<div class="row">

						<!-- Copyright Start -->
						<div class="col-sm-6">
							&copy; 2014 The Traveller by Coffeecream Themes
						</div>
						<!-- Copyright End -->

						<!-- Social Networks Start -->
						<div class="col-sm-6 text-right">
							<ul>
								<li><a href="#"><i class="fa fa-facebook fa-lg"></i></a></li>
								<li><a href="#"><i class="fa fa-twitter fa-lg"></i></a></li>
								<li><a href="#"><i class="fa fa-youtube fa-lg"></i></a></li>
								<li><a href="#"><i class="fa fa-google-plus fa-lg"></i></a></li>
								<li><a href="#"><i class="fa fa-linkedin fa-lg"></i></a></li>
								<li><a href="#"><i class="fa fa-skype fa-lg"></i></a></li>
							</ul>
						</div>
						<!-- Social Networks End -->

					</div>
				</div>
			</div>
		</footer>

		<!-- ============ FOOTER END ============ -->

		<!-- ============ RESERVATION BAR START ============ -->

		<?php include("reserva-rapida.php"); ?>

		<!-- ============ RESERVATION BAR END ============ -->

		<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
		<script src="js/jquery-1.11.2.min.js"></script>

		<!-- Bootstrap Plugins -->
		<script src="js/bootstrap.min.js"></script>

		<!-- Retina Plugin -->
		<script src="js/retina.min.js"></script>

		<!-- Jetmenu Plugin -->
		<script src="js/jetmenu.js"></script>

		<!-- Superslides Plugin -->
		<script src="js/jquery.superslides.min.js"></script>

		<!-- Flat Weather Plugin -->
		<script src="js/jquery.flatWeatherPlugin.min.js"></script>

		<!-- Owl Carousel Plugin -->
		<script src="js/owl.carousel.min.js"></script>

		<!-- Datepicker Plugin -->
		<script src="js/bootstrap-datepicker.js"></script>

		<!-- Parallax Plugin -->
		<script src="js/parallax.js"></script>

		<!-- Fancybox Plugin -->
		<script src="js/fancybox.pack.js"></script>

		<!-- Magic Form Processing -->
		<script src="js/magic.js"></script>

		<!-- jQuery Settings -->
		<script src="js/settings.js"></script>

	</body>
</html>