
<div id="header">
<div class="container">
<div class="row">
<div id="logo" class="col-xs-8 col-sm-4">
<a href="index.html"><img src="images/logo.jpg" alt="Hotel San Blas" class="img-responsive" /></a>
</div>
<div class="col-xs-4 col-sm-8 text-right" id="hotel-info">
<ul>
<li id="hotel-phone"><a href="#"><i class="fa fa-phone fa-lg primary-color"></i></a></li>
<li id="hotel-email"><a href="#"><i class="fa fa-envelope fa-lg primary-color"></i></a></li>
<li id="hotel-reservation"><a id="reservation-link" class="btn btn-primary"><i class="fa fa-calendar fa-lg primary-color"></i> <span>Reservas</span></a></li>
<li id="">
<a href="../es/index.php" class="page-scroll"><img src="images/es.png" alt=""> <span>EN</span></a>
</li>
</ul>
</div>
</div>
</div>
</div>
