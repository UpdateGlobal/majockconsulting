<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
		<meta name="description" content="Hotel San Blas">
		<meta name="author" content="Jason Gonzales">
		<title>HOTEL SAN BLAS | Siempre Brindándole lo Mejor | Alojamiento | Restaurant | Sala de eventos | sanblashotel.com</title>
		<link rel="shortcut icon" href="images/favicon.png">

		<!-- Main Stylesheet -->
		<link href="css/style.css" rel="stylesheet">

		<!-- HTML5 shiv and Respond.js IE8 support of HTML5 elements and media queries -->
		<!--[if lt IE 9]>
		<script src="js/html5shiv.js"></script>
		<script src="js/respond.min.js"></script>
		<![endif]-->

	</head>
	<body>

		<!-- ============ LOADER START ============ -->

		<!-- <div id="loader">
			<i class="fa fa-cog fa-4x fa-spin primary-color"></i>
		</div> -->

		<!-- ============ LOADER END ============ -->

		<!-- ============ HEADER START ============ -->

		<header>
			<?php include("header.php"); ?>
			<?php include("nav.php"); ?>
		</header>
		<section id="content">
			<div class="container">
				<div class="row">
					<div class="col-sm-12 text-center">
						<h5>Quienes somos</h5>
						<h1>Hotel San Blas</h1>
					</div>
				</div>
				<div class="row">
					<div class="col-sm-12">
						<div role="tabpanel">

							<!-- Nav tabs -->
							<ul class="nav nav-pills" role="tablist">
							<li role="presentation" class="active"><a href="#about" aria-controls="about" role="tab" data-toggle="tab">Historia</a></li>
							<li role="presentation"><a href="#location" aria-controls="location" role="tab" data-toggle="tab">Misión</a></li>
							<li role="presentation"><a href="#mission" aria-controls="mission" role="tab" data-toggle="tab">Visión</a></li>
							</ul>

							<!-- Tab panes -->
							<div class="tab-content">
								<div role="tabpanel" class="tab-pane fade in active" id="about">
									<p>El hotel fue fundado en el año 1998 por importantes empresarios de nuestra ciudad que sintieron la necesidad de ofrecer a los turistas nacionales y extranjeros un lugar cómodo y acogedor con un ambiente de familia, tarea en la cuál estamos inmersos.</p>
									<p>Es así que el hotel abrió sus puertas un 25 de febrero con una edificación pensada en la  comodidad de sus visitantes.</p>
									<p>El hotel San Blas posee una excelente ubicación en el tradicional distrito de Miraflores y a unos pasos del distrito de San Isidro, las zonas financieras y centros comerciales más exclusivos de Lima.</p>
									<img src="images/hotel.jpg" alt="">
								</div>
								<div role="tabpanel" class="tab-pane fade" id="location">
									<p>Cras condimentum, ipsum non ullamcorper auctor, tortor arcu finibus enim, vel malesuada justo est at massa. Sed hendrerit nisl interdum massa viverra bibendum. Aliquam neque ex, fringilla vel velit et, auctor congue nisi. Aliquam mattis orci eu sem dictum bibendum. Donec tristique placerat elit et sagittis. Aenean gravida ligula feugiat nisi auctor, quis elementum augue ornare. Fusce ullamcorper id nisl vel vehicula.</p>
								</div>
								<div role="tabpanel" class="tab-pane fade" id="mission">
									<p>Nulla dignissim justo venenatis, luctus risus quis, blandit dui. Proin tempor vulputate diam, nec sollicitudin ligula aliquam at. Aliquam non ex consectetur, varius tortor in, facilisis velit. Pellentesque metus massa, iaculis sed mollis a, viverra ac ligula. Vestibulum bibendum convallis augue, a fermentum nulla. Nulla facilisi. Nunc quis erat id orci rutrum vestibulum. Suspendisse suscipit purus ac urna scelerisque ullamcorper. Nunc mattis tellus id varius malesuada.</p>
								</div>
								<div role="tabpanel" class="tab-pane fade" id="contact">
									<p>Integer pharetra efficitur varius. In pretium accumsan diam. Maecenas neque nunc, rhoncus congue dictum vehicula, vestibulum ut enim. Sed aliquam bibendum dictum. Nulla facilisis laoreet ante, in porta turpis elementum at. Sed id dolor at purus cursus ultricies.</p>
								</div>
							</div>

						</div>
					</div>
				</div>
		</section>
		<footer>
			<div id="widgets">
				<div class="container">
					<div class="row">
						<div class="col-sm-3 widget">
							<h4>Contactenos</h4>
							<p>
								Hotel San Blas<br>
								Av. Arequipa 3940<br>
								Miraflores, Lima
							</p>
							<p>
								Telf: (511) 222 2601<br>
								Email: reservas@sanblashotel.com
							</p>
							<p>
								<a href="#">Contactar &nbsp; <i class="fa fa-angle-right"></i></a>
							</p>
						</div>
						
						<div class="col-sm-3 widget">
							<h4>HABITACIONES</h4>
							<nav>
								<ul>
									<li><a href="#"><i class="fa fa-angle-right primary-color"></i>Junior Suite</a></li>
									<li><a href="#"><i class="fa fa-angle-right primary-color"></i>Ejecutiva Simple</a></li>
									<li><a href="#"><i class="fa fa-angle-right primary-color"></i>Clásica Simple</a></li>
									<li><a href="#"><i class="fa fa-angle-right primary-color"></i>Ejecutiva Doble</a></li>
									<li><a href="#"><i class="fa fa-angle-right primary-color"></i>Clásica Doble</a></li>
								</ul>
							</nav>
						</div><div class="col-sm-3 widget">
							<h4>EVENTOS</h4>
							<nav>
								<ul>
									<li><a href="#"><i class="fa fa-angle-right primary-color"></i>Recepción de bodas</a></li>
									<li><a href="#"><i class="fa fa-angle-right primary-color"></i>Reuniones de negocio</a></li>
									<li><a href="#"><i class="fa fa-angle-right primary-color"></i>Convenciones</a></li>
									<li><a href="#"><i class="fa fa-angle-right primary-color"></i>Conferencias</a></li>
								</ul>
							</nav>
						</div>
						<div class="col-sm-3 widget">
							<h4>Recibe Nuestras Ofertas</h4>
							<form role="form" name="newsletter-form" id="newsletter-form" action="process-newsletter.php">
								<div class="form-group" id="newsletter-email-group">
									<label class="sr-only" for="newsletter-email">Email</label>
									<input type="email" class="form-control" id="newsletter-email" placeholder="Email">
								</div>
								<button type="submit" class="btn btn-primary">Suscribirme</button>
							</form>
						</div>
						
					</div>
				</div>
			</div>
			<div id="credits">
				<div class="container">
					<div class="row">
						<div class="col-sm-6">
							Hotel San Blas &copy; Todos los derechos reservados 2016
						</div>
						<div class="col-sm-2 text-right">
							<ul>
								<li><a href="#"><i class="fa fa-facebook fa-lg"></i></a></li>
								<li><a href="#"><i class="fa fa-twitter fa-lg"></i></a></li>
								<li><a href="#"><i class="fa fa-youtube fa-lg"></i></a></li>
								<li><a href="#"><i class="fa fa-google-plus fa-lg"></i></a></li>
								<li><a href="#"><i class="fa fa-skype fa-lg"></i></a></li>
							</ul>
						</div>
						<div class="col-sm-4 text-right">
							Powered by <a href="http://linkreativo.com/">Linkreativo</a>
						</div>
					</div>
				</div>
			</div>
		</footer>
		<?php include("reserva-rapida.php"); ?>

		<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
		<script src="js/jquery-1.11.2.min.js"></script>

		<!-- Bootstrap Plugins -->
		<script src="js/bootstrap.min.js"></script>

		<!-- Retina Plugin -->
		<script src="js/retina.min.js"></script>

		<!-- Jetmenu Plugin -->
		<script src="js/jetmenu.js"></script>

		<!-- Superslides Plugin -->
		<script src="js/jquery.superslides.min.js"></script>

		<!-- Flat Weather Plugin -->
		<script src="js/jquery.flatWeatherPlugin.min.js"></script>

		<!-- Owl Carousel Plugin -->
		<script src="js/owl.carousel.min.js"></script>

		<!-- Datepicker Plugin -->
		<script src="js/bootstrap-datepicker.js"></script>

		<!-- Parallax Plugin -->
		<script src="js/parallax.js"></script>

		<!-- Fancybox Plugin -->
		<script src="js/fancybox.pack.js"></script>

		<!-- Magic Form Processing -->
		<script src="js/magic.js"></script>

		<!-- jQuery Settings -->
		<script src="js/settings.js"></script>

	</body>
</html>