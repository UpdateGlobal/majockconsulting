<div class="col-md-9">
<div class="outer-box">
                    <div class="row">
                        <div class="col-md-6 col-sm-6 col-xs-12">
                            <div class="section-title">
                                <h3>RETAIL</h3>
                            </div>
                            <h4>NUESTROS SOFTWARE’S</h4><br>
                            <div class="text">
                                <p>Nuestro software para tiendas, pequeños y medianos comercios minoristas se adapta plenamente a las necesidades de su gestión. El programa le facilita la operativa diaria de su Comercio y le suministra una valiosa información periódica para la eficaz gestión y control de su negocio.</p>
                                <p>Sencillo y fácil de utilizar, no hace falta saber nada de informática ni de contabilidad. El programa está orientado a facilitar toda la labor utilizando procesos sencillos, flexibilidad en las operaciones, impresión de tickets, facturas, Etc.</p>
                                <p>Nuestro software, también está preparado para trabajar como sistemas de punto de venta en tiendas de ropa, moda, calzado, farmacias, ferreterías, Etc. Instalado en cientos de comercios de este tipo, es un software que cubrirá todas sus necesidades.</p>
                                <p>Además de todas las opciones mencionadas, nuestro sistema le ofrece la posibilidad de trabajar con tallas y Colores, resolviendo así toda la problemática generada en una tienda de ropa o zapatería.</p>
                            </div>
                        </div>

                        <div class="col-md-6 col-sm-6 col-xs-12">
                            <div class="img-box"><a href="#"><img src="images/retail.jpg" alt=""></a></div>
                            <div class="content center over-view">
                                <h4>TENEMOS LO QUE BUSCA </h4>
                                <a href="/contacto.php#contacto"><i class="fa fa-long-arrow-right"></i>CONTACTENOS</a>
                            </div>
                        </div>
                    </div><br><br>
                    <div class="border-bottom"></div>
                    <br><br>
                    <div class="section-title">
                        <h3>YA ESTAMOS!</h3>
                    </div>
                    <div class="text">
                        <p>Más de 10.500 instalaciones realizadas en España y Latinoamérica avalan la trayectoria de nuestra aplicación para el pequeño y mediano comercio.</p>
                    </div>
                    <div class="analysis-chart">
                        <div class="row">
                            <div class="col-md-4 col-sm-4 col-xs-6">    
                                <div class="item center">
                                    <img src="images/service/10.jpg" alt="">
                                    <h4>Europa 60%</h4>
                                </div>
                                
                            </div>
                            <div class="col-md-4 col-sm-4 col-xs-6">    
                                <div class="item center">
                                    <img src="images/service/10.jpg" alt="">
                                    <h4>Latinoamerica 40%</h4>
                                </div>
                                
                            </div>
                            <!--<div class="col-md-4 col-sm-4 col-xs-6">    
                                <div class="item center">
                                    <img src="images/service/12.jpg" alt="">
                                    <h4>Norteamrica 15%</h4>
                                </div>
                                
                            </div>-->
                        </div>
                    </div>
                        
                    <div class="section-title">
                        <h3>LA OPERATIVIDAD DE NUESTRO SOFTWARE</h3>
                    </div> 
                    <div class="text">   
                        <p>Nuestro software para tiendas, es el perfecto aliado para la gestión de su comercio. Aquí le mostramos algunas de las posibilidades que le ofrece la aplicación:</p>
                        <p>
                            <span>1.- Gestión de Compras y Ventas.</span><br>
                            <span>2.- Control de Existencias e Inventarios.</span><br>
                            <span>3.- Ventas y márgenes de Beneficio por Productos y Familias.</span><br>
                            <span>4.- Deudas de Clientes y Proveedores.</span><br>
                            <span>5.- La aplicación es mono puesto. En caso de necesidad, se puede migrar a nuestras aplicaciones de gestión de comercial que cuentan con aun más utilidades a explotar para su negocio.</span><br>
                            <span>6.- Libros de Gastos e Ingresos.</span><br>
                            <span>7.- Informes comerciales y rentabilidad.</span><br>
                            <span>8.- Emisión de etiquetas para sus artículos (configurables diversos tipos, incluida impresión de Códigos de Barras.</span><br>
                            <span>9.- Gestión de Rebajas y Ofertas.</span><br>
                            <span>10.- Conexión con lectores de códigos de barras para agilizar el proceso de ventas.</span>
                        </p>
                    </div>
                </div>

</div>