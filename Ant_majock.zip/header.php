<header class="header-area">
    <div class="top-bar">
        <div class="container">
            <div class="clearfix">
                <ul class="top-bar-text float_left">
                    <li><i class="fa fa-map-signs"></i>Calle Manco Segundo 2462 Oficina 401 </li>
                    <li><i class="fa fa-clock-o"></i>Lun - Vie: 9.00 am. a 6.00 pm.</li>
                </ul>
                <ul class="social float_right">
                    <li><a target="_Blank" href="https://www.facebook.com/Majockconsulting/?ref=aymt_homepage_panel"><i class="fa fa-facebook"></i></a></li>
                    <li><a target="_Blank" href="https://twitter.com/MajockC"><i class="fa fa-twitter"></i></a></li>
                    <li><a target="_Blank" href="https://www.linkedin.com/home?trk=nav_responsive_tab_home"><i class="fa fa-linkedin"></i></a></li>
                    <li><a target="_Blank" href="https://plus.google.com/b/108574183967501053837/108574183967501053837"><i class="fa fa-google-plus"></i></a></li>
                    <li><a target="_Blank" href="skype:info.majock?call"><i class="fa fa-skype"></i></a></li>
                </ul>
                <div id="polyglotLanguageSwitcher" class="float_right">
                    <form action="#">
                        <select id="polyglot-language-options">
                            <option id="en" value="en" selected>English</option>
                            <option id="fr" value="fr">French</option>
                            <option id="de" value="de">German</option>
                            <option id="it" value="it">Italian</option>
                            <option id="es" value="es">Spanish</option>
                        </select>
                    </form>
                </div>
            </div>
                

        </div>
    </div>
    <div class="header-bottom">
        <div class="container">
            <div class="header-bottom-bg clearfix">
                <div class="main-logo float_left">
                    <a href="index.php"><img src="images/logo/logo.png" alt="" style="width: 200px;"></a>
                </div>
                <div class="top-info float_right">
                    <ul>
                        <li class="single-info-box">
                            <div class="icon-holder">
                                <span class="icon-technology"></span>
                            </div>
                            <div class="text-holder">
                                <p><span>Telefonos</span><br>7231180 – 3295650</p>
                            </div>
                        </li>
                        <li class="single-info-box">
                            <div class="icon-holder">
                                <span class="icon-multimedia"></span>
                            </div>
                            <div class="text-holder">
                                <p><span>Mail de contacto</span> <br>Info@majockconsulting.com</p>
                            </div>
                        </li>
                        <li class="link_btn">
                           <a href="contacto.php#contacto" class="thm-btn-tr">Contáctenos</a>
                        </li>
                    </ul>    
                </div> 
            </div>
                    
        </div>
    </div>  
        
</header>

<!-- Menu ******************************* -->
<section class="theme_menu stricky">
    <div class="container">
        <div class="menu-bg">
            <div class="row">
                <div class="col-md-9 menu-column">
                    <nav class="menuzord" id="main_menu">
                       <ul class="menuzord-menu">
                            <li class="home"><a href="index.php"><span class="fa fa-home"></span></a></li>

                            <li><a href="quienessomos.php">Quienes somos</a>
                            </li>

                            <li><a href="productos.php">Productos</a>

                                
                            </li>

                            <li><a href="servicios.php">Servicios</a>
                            <!--<ul class="dropdown">
                                <li><a href="blog-default.html">Blog Default</a></li>
                                <li><a href="blog-large.html">Blog Large Image</a></li>
                                <li><a href="blog-details.html">Blog Single Post</a></li>
                             </ul>-->
                            </li>
                            <li><a href="contacto.php#soporte">Soporte</a></li>

                            <li><a href="contacto.php#contacto">Contacto</a></li>




                        </ul><!-- End of .menuzord-menu -->
                    </nav> <!-- End of #main_menu -->
                </div>
                <!--<div class="right-column" st>
                    <div class="right-area">
                        <div class="nav_side_content">
                            <div class="select-box">
                                <select name="branceh" class="selectpicker">
                                    <option>Los Angeles Branch</option>
                                    <option>San Fransisco Branch</option>
                                    <option>Chicago Branch</option>
                                    <option>San Jose Branch</option>
                                    <option>Newyork City Branch</option>
                                </select>
                            </div>
                            <div class="search_option">
                                <button class="search tran3s dropdown-toggle color1_bg" id="searchDropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="fa fa-search" aria-hidden="true"></i></button>
                                <form action="#" class="dropdown-menu" aria-labelledby="searchDropdown">
                                    <input type="text" placeholder="Search...">
                                    <button><i class="fa fa-search" aria-hidden="true"></i></button>
                                </form>
                            </div>
                       </div>

                    </div>
                        
                </div>
            </div>-->
        </div>      

   </div> <!-- End of .conatiner -->
</section> <!-- End of .theme_menu -->