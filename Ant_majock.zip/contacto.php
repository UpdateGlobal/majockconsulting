<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Contacto || Majock Consulting</title> 

    <!-- mobile responsive meta -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">


    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/responsive.css">
    
    <link rel="apple-touch-icon" sizes="180x180" href="images/favicons/apple-touch-icon.png">
    <link rel="icon" type="image/png" href="images/favicons/favicon-32x32.png" sizes="32x32">
    <link rel="icon" type="image/png" href="images/favicons/favicon-16x16.png" sizes="16x16">

</head>
<body>

<div class="boxed_wrapper">



    

<?php include('header.php'); ?>

 

<a name="soporte"></a>
<div class="inner-banner has-base-color-overlay text-center" style="background: url(images/background/1.jpg);">
    <div class="container">
        <div class="box">
            <h3>Contactenos</h3>
        </div>
    </div>
    <div class="breadcumb-wrapper">
        <div class="container">
            <div class="pull-left">
                <ul class="list-inline link-list">
                    <li>
                        <a href="index.php">Inicio</a>
                    </li>
                    <li>
                        Contactenos
                    </li>
                </ul>
            </div>
            <div class="pull-right">
                <a href="#" class="get-qoute"><i class="fa fa-share-alt"></i>share</a>
            </div>
        </div>
    </div>
</div>





<section class="contact_information sec-padd">
    <div class="container">
        <div class="tabs-outer style-two">
            <!--Tabs Box-->
            <div class="tabs-box tabs-style-one">
                <!--Tab Buttons-->
                <div class="center">
                    <ul class="tab-buttons clearfix">
                        <li data-tab="#Lima" class="tab-btn active-btn">Lima</li>
                    </ul>
                </div>
                    
            
                <!--Tabs Content-->
                <div class="tabs-content">
                    <!--Tab / Active Tab-->
                    <div class="tab active-tab" id="Newyork" style="display: block;">
                        <div class="row">
                            <div class="col-md-4 col-sm-6 col-xs-12">
                                <div class="item">
                                    <h5>Visitanos</span></h5>
                                    <ul>
                                        <li>Calle: <span> Manco Segundo 2462 Oficina 401</span></li>
                                        <li>Ciudad / Distrtio:  <span> Lima/Lince</span></li>
                                        <li>Pais: <span>  Perú</span></li>
                                    </ul>
                                    <span class="icon icon-location"></span>
                                </div>
                            </div>
                            <div class="col-md-4 col-sm-6 col-xs-12">
                                <div class="item">
                                    <h5>Soporte Tecnico</h5>
                                    <ul>
                                        <li>Telf: <span> 7231180 </span></li>
                                        <li>Telf: <span> 3295650 </span></li>
                                        <li>Email:  <span> soporte@majockconsulting.com </span></li>
                                    </ul>
                                    <span class="icon icon-technology"></span>
                                </div>
                            </div>
                            <div class="col-md-4 col-sm-6 col-xs-12">
                                <div class="item">
                                    <h5>Horario de trabajo</h5>
                                    <ul>
                                        <li>Lun - Vie: <span> 9.00 am. a 6.00 pm </span></li>
                                        <li>Sabado: <span> Cerrado  </span></li>
                                        <li>Domingo:  <span> Cerrado</span></li>
                                    </ul>
                                    <span class="icon icon-square"></span>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!--Tab-->
                    <div class="tab" id="Angeles" style="display: none;">
                        <div class="row">
                            <div class="col-md-4 col-sm-6 col-xs-12">
                                <div class="item">
                                    <h5>Visit Our Office <span>(Los Angeles)</span></h5>
                                    <ul>
                                        <li>Street: <span> 234, Triumph Street</span></li>
                                        <li>City:  <span> Los Angeles, California City</span></li>
                                        <li>Country: <span>  United States - 90005</span></li>
                                    </ul>
                                    <span class="icon icon-location"></span>
                                </div>
                            </div>
                            <div class="col-md-4 col-sm-6 col-xs-12">
                                <div class="item">
                                    <h5>24/7 Quick Contact</h5>
                                    <ul>
                                        <li>Phone: <span> 1800-45-678-9012 & 8012 </span></li>
                                        <li>Email:  <span> Suportyou@Universal.com</span></li>
                                        <li>Fax: <span>  United States - 90005</span></li>
                                    </ul>
                                    <span class="icon icon-technology"></span>
                                </div>
                            </div>
                            <div class="col-md-4 col-sm-6 col-xs-12">
                                <div class="item">
                                    <h5>Working Hours</h5>
                                    <ul>
                                        <li>Mon - Fri Day: <span> 09.00am to 18.00pm </span></li>
                                        <li>Saturaday: <span> 10.00am to 16.00pm  </span></li>
                                        <li>Sunday:  <span> Closed</span></li>
                                    </ul>
                                    <span class="icon icon-square"></span>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!--Tab-->
                    <div class="tab" id="Fransisco" style="display: none;">
                        <div class="row">
                            <div class="col-md-4 col-sm-6 col-xs-12">
                                <div class="item">
                                    <h5>Visit Our Office <span>(Los Angeles)</span></h5>
                                    <ul>
                                        <li>Street: <span> 234, Triumph Street</span></li>
                                        <li>City:  <span> Los Angeles, California City</span></li>
                                        <li>Country: <span>  United States - 90005</span></li>
                                    </ul>
                                    <span class="icon icon-location"></span>
                                </div>
                            </div>
                            <div class="col-md-4 col-sm-6 col-xs-12">
                                <div class="item">
                                    <h5>24/7 Quick Contact</h5>
                                    <ul>
                                        <li>Phone: <span> 1800-45-678-9012 & 8012 </span></li>
                                        <li>Email:  <span> Suportyou@Universal.com</span></li>
                                        <li>Fax: <span>  United States - 90005</span></li>
                                    </ul>
                                    <span class="icon icon-technology"></span>
                                </div>
                            </div>
                            <div class="col-md-4 col-sm-6 col-xs-12">
                                <div class="item">
                                    <h5>Working Hours</h5>
                                    <ul>
                                        <li>Mon - Fri Day: <span> 09.00am to 18.00pm </span></li>
                                        <li>Saturaday: <span> 10.00am to 16.00pm  </span></li>
                                        <li>Sunday:  <span> Closed</span></li>
                                    </ul>
                                    <span class="icon icon-square"></span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="tab" id="Chicago" style="display: none;">
                        <div class="row">
                            <div class="col-md-4 col-sm-6 col-xs-12">
                                <div class="item">
                                    <h5>Visit Our Office <span>(Los Angeles)</span></h5>
                                    <ul>
                                        <li>Street: <span> 234, Triumph Street</span></li>
                                        <li>City:  <span> Los Angeles, California City</span></li>
                                        <li>Country: <span>  United States - 90005</span></li>
                                    </ul>
                                    <span class="icon icon-location"></span>
                                </div>
                            </div>
                            <div class="col-md-4 col-sm-6 col-xs-12">
                                <div class="item">
                                    <h5>24/7 Quick Contact</h5>
                                    <ul>
                                        <li>Phone: <span> 1800-45-678-9012 & 8012 </span></li>
                                        <li>Email:  <span> Suportyou@Universal.com</span></li>
                                        <li>Fax: <span>  United States - 90005</span></li>
                                    </ul>
                                    <span class="icon icon-technology"></span>
                                </div>
                            </div>
                            <div class="col-md-4 col-sm-6 col-xs-12">
                                <div class="item">
                                    <h5>Working Hours</h5>
                                    <ul>
                                        <li>Mon - Fri Day: <span> 09.00am to 18.00pm </span></li>
                                        <li>Saturaday: <span> 10.00am to 16.00pm  </span></li>
                                        <li>Sunday:  <span> Closed</span></li>
                                    </ul>
                                    <span class="icon icon-square"></span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="tab" id="Jose" style="display: none;">
                        <div class="row">
                            <div class="col-md-4 col-sm-6 col-xs-12">
                                <div class="item">
                                    <h5>Visit Our Office <span>(Los Angeles)</span></h5>
                                    <ul>
                                        <li>Street: <span> 234, Triumph Street</span></li>
                                        <li>City:  <span> Los Angeles, California City</span></li>
                                        <li>Country: <span>  United States - 90005</span></li>
                                    </ul>
                                    <span class="icon icon-location"></span>
                                </div>
                            </div>
                            <div class="col-md-4 col-sm-6 col-xs-12">
                                <div class="item">
                                    <h5>24/7 Quick Contact</h5>
                                    <ul>
                                        <li>Phone: <span> 1800-45-678-9012 & 8012 </span></li>
                                        <li>Email:  <span> Suportyou@Universal.com</span></li>
                                        <li>Fax: <span>  United States - 90005</span></li>
                                    </ul>
                                    <span class="icon icon-technology"></span>
                                </div>
                            </div>
                            <div class="col-md-4 col-sm-6 col-xs-12">
                                <div class="item">
                                    <h5>Working Hours</h5>
                                    <ul>
                                        <li>Mon - Fri Day: <span> 09.00am to 18.00pm </span></li>
                                        <li>Saturaday: <span> 10.00am to 16.00pm  </span></li>
                                        <li>Sunday:  <span> Closed</span></li>
                                    </ul>
                                    <span class="icon icon-square"></span>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                </div>
                
            </div>
        </div>
    </div>
</section>


<div class="container">
    <div class="border-bottom"></div>
</div>

<a name="contacto"></a>
<section class="contact_us sec-padd">
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-sm-12 col-xs-12">
                <div class="section-title">
                    <h3>Envianos un mensaje</h3>
                </div>
                <div class="default-form-area">
                    <form id="contact-form" name="contact_form" class="default-form" action="inc/sendmail.php" method="post">
                        <div class="row clearfix">
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                
                                <div class="form-group">
                                    <input type="text" name="form_name" class="form-control" value="" placeholder="Nombre Completo *" required="">
                                </div>
                            </div>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <div class="form-group">
                                    <input type="email" name="form_email" class="form-control required email" value="" placeholder="Email *" required="">
                                </div>
                            </div>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <div class="form-group">
                                    <input type="text" name="form_phone" class="form-control" value="" placeholder="Teléfono">
                                </div>
                            </div>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <div class="form-group">
                                    <input type="text" name="form_subject" class="form-control" value="" placeholder="Asunto">
                                </div>
                            </div>
                            <div class="col-md-12 col-sm-12 col-xs-12">
                                <div class="form-group">
                                    <textarea name="form_message" class="form-control textarea required" placeholder="Mensaje...."></textarea>
                                </div>
                            </div>   
                            <div class="col-md-12 col-sm-12 col-xs-12">
                                <div class="form-group">
                                    <input id="form_botcheck" name="form_botcheck" class="form-control" type="hidden" value="">
                                    <button class="thm-btn thm-color" type="submit" data-loading-text="Por favor espere...">Enviar</button>
                                </div>
                            </div>   

                        </div>
                    </form>
                </div>
            </div>
            <div class="col-md-4 col-sm-8 col-xs-12">
                <div class="section-title">
                    <h3>Contactanos</h3>
                </div>
                <div class="author-details">
                    <div class="item">
                        <h5>Recursos Humanos:</h5>
                        <div class="img-box">
                            <img src="/images/team/4.jpg" alt="">
                        </div>
                        <div class="content">
                            <h5>Noelia Aquino</h5>
                            <!--<p><i class="fa fa-phone"></i>+123 456 789</p>-->
                            <p><i class="fa fa-envelope"></i>rrhh@majockconsulting.com</p>
                        </div>
                    </div>
                    <div class="item">
                        <h5>Ventas:</h5>
                        <div class="img-box">
                            <img src="/images/team/3.jpg" alt="">
                        </div>
                        <div class="content">
                            <h5>Katia Palomino</h5>
                            <!--<p><i class="fa fa-phone"></i>+123 456 789</p>-->
                            <p><i class="fa fa-envelope"></i>kpalomino@majockconsulting.com</p>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
</section>




<section class="home-google-map">

    <div 
        class="google-map" 
        id="contact-google-map" 
        data-map-lat="-12.086475" 
        data-map-lng="-77.046121" 
        data-icon-path="https://cdn0.iconfinder.com/data/icons/citycons/150/Citycons_building-48.png"
        data-map-title="Majock"
        data-map-zoom="15" >

    </div>

</section>






<?php include('footer.php'); ?>

</div>
    
</body>
</html>